import * as types from '../constant/actiontype';

export default function stockservers(state = [], action = {}) {
  let {
        type, payload, name
    } = action;

  switch (type) {
        case types.FETCH_STOCK_SERVERS:
            return {
                ...state,
                ...payload
            };
        case types.FETCH_STOCK_SERVERS_SUCCESS:
            let successInfo = {};
            successInfo = {
                results : [
                   ...payload.results
                ]
            }

            return {
                ...state,
                ...payload,
                ...successInfo,
                loader : false,
                flag : state.flag + 1
            };
        case types.FETCH_STOCK_SERVERS_FAILURE:
            let loader = false
            if ( 401 === payload.status ) {
                loader = true;
            }
            return {
                ...state,
                ...payload,
                loader : loader
            };
        case types.RESET_STOCK_SERVERS:
            return {
                ...state,
                ...payload,
                flag : 0
            };
        default:
            return state;
    }
}
