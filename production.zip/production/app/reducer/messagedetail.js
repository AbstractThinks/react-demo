import * as types from '../constant/actiontype';

export default function messagedetail(state = [], action = {}) {
  const {
        type, payload
    } = action;

  switch (type) {
        case types.FETCH_MESSAGE:

            return {
                ...state,
                ...payload,
                loader : true
            };
        case types.FETCH_MESSAGE_SUCCESS: 
            return {
                ...state,
                ...payload,
                loader : false
            };
        case types.FETCH_MESSAGE_FAILURE:
            let loader = false
            if ( 401 === payload.status ) {
                loader = true;
            }
            return {
                ...state,
                ...payload,
                loader : loader
            };
        default:
            return state;
    }
}
