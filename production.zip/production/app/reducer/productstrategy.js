import * as types from '../constant/actiontype';

export default function productstrategy(state = [], action = {}) {
  const { type, payload } = action;

  switch(type) {

  	case types.FETCH_PRODUCTS_STRATEGYS:
  		return {
        ...state,
        ...payload,
        status : 1
  		}
  	case types.FETCH_PRODUCTS_STRATEGYS_SUCCESS:
        let successInfo = {};
        if ( 1 === payload.page.pageNo ) {
            successInfo = {
                results : [
                    ...payload.results
                ]
            }
        } else {
            successInfo = {
                results : [
                   ...state.results,
                   ...payload.results
                ]
            }
        }
  		return {
  			...state,
        ...payload,
        ...successInfo,
        status : 2,
        loader:false,
        flag:state.flag + 1
  		}
  	case types.FETCH_PRODUCTS_STRATEGYS_FAILURE:
      let loader = false;
      let status = 3;
      if ( 401 === payload.status ) {
          loader = true;
          status = payload.status;
      }
      return {
          ...state,
          status : status,
          message : payload.message,
          loader : loader
      };
    case types.RESET_PRODUCTS_STRATEGY:
      return {
        ...state,
        ...payload,
        flag:0
      };

  	default:
        return state;
  }

}