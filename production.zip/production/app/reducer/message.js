import * as types from '../constant/actiontype';

// import * as messageData from '../mock/message';
// import * as messageData2 from '../mock/message2';
// import * as messageData3 from '../mock/message3';

export default function message(state = [], action = {}) {
  let {
        type, payload, name
    } = action;

  switch (type) {
        case types.FETCH_MESSAGES:
            return {
                ...state,
                ...payload,
                status : 1
            };
        case types.FETCH_MESSAGES_SUCCESS:
            // payload = messageData.item //test
            let successInfo = {};
            if ( 1 === payload.page.pageNo ) {
                successInfo = {
                    results : [
                        ...payload.results
                    ]
                }
            } else {
                successInfo = {
                    results : [
                       ...state.results,
                       ...payload.results
                    ]
                }
            }

            return {
                ...state,
                ...payload,
                ...successInfo,
                status : 2,
                loader : false,
                flag : state.flag + 1
            };
        case types.FETCH_MESSAGES_FAILURE:
            let loader = false;
            let status = 3;
            if ( 401 === payload.status ) {
                loader = true;
                status = payload.status;
            }
            return {
                ...state,
                status : status,
                message : payload.message,
                loader : loader
            };
        case types.RESET_MESSAGES:
            return {
                ...state,
                ...payload,
                flag : 0
            };
        default:
            return state;
    }
}
