import * as types from '../constant/actiontype';

export default function stockcost(state = [], action = {}) {
  const {
        type, payload, pmid
    } = action;

  let loader = false;
  switch (type) {
        case types.FETCH_STOCK_COST:
            return {
                ...state,
                ...payload
            };
        case types.FETCH_STOCK_COST_SUCCESS:
            let successInfo = {};
            successInfo = {
                results : [
                    ...payload.results
                ]
            }

            return {
                ...state,
                ...payload,
                ...successInfo,
                loader : false
            };
        case types.FETCH_STOCK_COST_FAILURE:
            loader = false;
            if ( 401 === payload.status ) {
                loader = true;
            }
            return {
                ...state,
                ...payload,
                loader : loader
            };
        
        case types.FETCH_STOCK_COST_DETAIL:
            return {
                ...state,
                [pmid] : {
                    ...state[pmid],
                    ...payload,
                    status : 1
                }
            };
        case types.FETCH_STOCK_COST_DETAIL_SUCCESS:
            let successData = {};
            if ( 1 === payload.page.pageNo ) {
                successData = {
                    results : [
                        ...payload.results
                    ]
                }
            } else {
                successData = {
                    results : [
                       ...state[pmid].results,
                       ...payload.results
                    ]
                }
            }

            return {
                ...state,
                [pmid] : {
                    ...state[pmid],
                    ...payload,
                    ...successData,
                    status : 2,
                    loader : false
                }
            };

        case types.FETCH_STOCK_COST_DETAIL_FAILURE:
            loader = false;
            let status = 3;
            if ( 401 === payload.status ) {
                loader = true;
                status = payload.status;
            }
            return {
                ...state,
                [pmid] : {
                    ...state[pmid],
                    status : status,
                    message : payload.message,
                    loader : loader
                }
            };
        default:
            return state;
    }
}
