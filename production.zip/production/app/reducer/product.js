import * as types from '../constant/actiontype';
import { productStatus } from '../config/common';
import { resourceURI } from '../config/api';
// import * as productData from '../mock/product';
// import * as productData2 from '../mock/product2';

function updateProductStatus(products, pid, status, curstatus){
    if(products && products.length && pid && status){
        for(let i = 0, len = products.length; i< len; i++){
            let product = products[i];
            if (product.pmid === pid) {
                product.status = status;
                product.curstatus = curstatus;
            };
        }
    }
}
function updateProduct(products){
    if(products && products.length){
        let len = products.length;
        for(let i = 0; i< len; i++){
            let product = products[i];
            if (product.pmid === "1588015") {
                product.url = `${resourceURI}img/product_price_v3.jpg`;
            }else if(product.pmid === "1588016"){
                product.url = `${resourceURI}img/product_hot_v3.jpg`;
            }else if(product.pmid === "1588020"){
                product.url = `${resourceURI}img/productStrategy_v2.jpg`;
                product.link = "productstrategy";
                product.linkname = "查看";
            }else if(product.pmid === "1588021"){
                product.url = `${resourceURI}img/product4.jpg`;
                product.link = "stocklist";
                product.linkname = "进入";
            };

        }
    }
}


export default function product(state = [], action = {}) {
  const {
        type, payload, pmid
  } = action;
  switch (type) {

        // ==============================================
        // 产品列表
        // ==============================================

        case types.FETCH_PRODUCTS:

            return {
                ...state,
                ...payload
            };
        case types.FETCH_PRODUCTS_SUCCESS:
            let stateCloneSuccess = {};
            Object.assign(stateCloneSuccess, payload);
            updateProduct(stateCloneSuccess.results);
            let fetchSuccessData = {
                status : 1,
                message : "加载成功",
                ...payload,
                results :  [
                    ...payload.results,
                    // ...productData2.items2[0].results, //测试
                    // ...productData.items
                ],
                loader : false
            };

            return {
                ...state,
                ...fetchSuccessData
            };

        case types.FETCH_PRODUCTS_FAILURE:
            let loader = false
            if ( 401 === payload.status) {
                loader = true;
            }
            let fetchFailureData = {
                status : -1,
                message : "加载失败",
                // results : []
                ...payload,
                loader : loader
            };

            return {
                ...state,
                ...fetchFailureData
            };

        // ==============================================
        // 产品签约
        // ==============================================

        case types.SUB_PRODUCT:
            return {
                ...state,
                ...payload,
                [pmid] : {
                  sub_status : 1,
                  message : "签约中"
                }
            };
        case types.SUB_PRODUCT_SUCCESS:

            let subStateClone = {};
            Object.assign(subStateClone, state);

            updateProductStatus(subStateClone.results, pmid, '2', '2');

            let subSuccessData = {
                ...payload,
                results : subStateClone.results,
                [pmid] : {
                  sub_status : 2,
                  message : "恭喜您签约成功"
                }
            };
            return {
                ...state,
                ...subSuccessData
            };
            

        case types.SUB_PRODUCT_FAILURE:
            let subFailureData = {
                ...payload,
                [pmid] : {
                  sub_status : 3,
                  message : "产品签约失败"
                }
            };

            return {
                ...state,
                ...subFailureData
            };
            //测试
            // productData2.items2[0].results[0].status = "2";
            // productData2.items2[0].results[0].curstatus = "2";
            // return {
            //     ...productData2.items2[0]
            // };

        // ==============================================
        // 产品退约
        // ==============================================

        case types.UNSUB_PRODUCT:
            return {
                ...state,
                ...payload,
                [pmid] : {
                  unsub_status : 1,
                  message : "正在退签"
                }
            };
        case types.UNSUB_PRODUCT_SUCCESS:

            let unsubStateCloneSuccess = {};
            Object.assign(unsubStateCloneSuccess, state);

            updateProductStatus(unsubStateCloneSuccess.results, pmid, '2', '4');

            let unsubSuccessData = {
                ...payload,
                results : unsubStateCloneSuccess.results,
                [pmid] : {
                  unsub_status : 2,
                  message : "退签申请成功，正在审核"
                }
                
            };

            return {
                ...state,
                ...unsubSuccessData
            };
        case types.UNSUB_PRODUCT_FAILURE:
            let unsubStateCloneFailure = {};
            Object.assign(unsubStateCloneFailure, state);

            let unsubFailureData = {
                ...payload,
                results : unsubStateCloneFailure.results,
                [pmid] : {
                  unsub_status : 3,
                  message : "退签申请失败"
                }
            };

            return {
                ...state,
                ...unsubFailureData
            };

        default:
            return state;
    }
}
