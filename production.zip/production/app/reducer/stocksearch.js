import * as types from '../constant/actiontype';

function updateStockStatus(stocks, pid, status, type){
    if(stocks && stocks.length && pid){
        for(let i = 0, len = stocks.length; i< len; i++){
            let stock = stocks[i];
            if (stock.id == pid) {
                stock.issubscribe = status;
                if(type==="SUB") {
                    stock.subscribenum = parseInt(stock.subscribenum) + 1;
                } else if(type==="UNSUB") {
                    stock.subscribenum = parseInt(stock.subscribenum) - 1;
                }
            };
        }
    }
}
export default function stock(state = [], action = {}) {
  let {
        type, payload, pmid
    } = action;
  switch (type) {
        case types.FETCH_SEARCH_STOCKS:
            return {
                ...state,
                ...payload
            };
        case types.FETCH_SEARCH_STOCKS_SUCCESS:
            let successSearchInfo = {};
            if ( 1 === payload.page.pageNo ) {
                successSearchInfo = {
                    results : [
                        ...payload.results
                    ]
                }
            } else {
                successSearchInfo = {
                    results : [
                       ...state.results,
                       ...payload.results
                    ]
                }
            }

            return {
                ...state,
                ...payload,
                ...successSearchInfo,
                loader : false,
                searchFlag : true
            };
        case types.FETCH_SEARCH_STOCKS_FAILURE:
            let loader = false;
            if ( 401 === payload.status ) {
                loader = true;
            }
            return {
                ...state,
                ...payload,
                loader : loader,
                searchFlag : true
            };
        case types.RESET_SEARCH_STOCKS:
            return {
            };
        case types.SUB_SEARCH_STOCK:
            return {
                ...state,
                ...payload,
                [pmid] : {
                  sub_status : 1,
                  message : "签约中"
                }
            };
        case types.SUB_SEARCH_STOCK_SUCCESS:
            let subStateClone = {};
            Object.assign(subStateClone, state);

            updateStockStatus(subStateClone.results, pmid, 1, "SUB");
            let subSuccessData = {
                ...payload,
                results : subStateClone.results,
                [pmid] : {
                  sub_status : 2,
                  message : "恭喜您签约成功"
                }
            };
            return {
                ...state,
                ...subSuccessData
            };
            

        case types.SUB_SEARCH_STOCK_FAILURE:
            let subFailureData = {
                ...payload,
                results : state.results,
                [pmid] : {
                  sub_status : 3,
                  message : "产品签约失败"
                }
            };
        // ==============================================
        // 股票列表签约，保证状态统一
        // ==============================================

        case types.SUB_STOCK:
            return {
                ...state,
                ...payload,
                [pmid] : {
                  sub_status : 1,
                  message : "签约中"
                }
            };
        case types.SUB_STOCK_SUCCESS:
            let subListStateClone = {};
            // console.log("list:",pmid);
            Object.assign(subListStateClone, state);

            updateStockStatus(subListStateClone.results, pmid, 1, "SUB");

            let subListSuccessData = {
                ...payload,
                results : subListStateClone.results,
                [pmid] : {
                  sub_status : 2,
                  message : "恭喜您签约成功"
                }
            };
            return {
                ...state,
                ...subListSuccessData
            };
            

        case types.SUB_STOCK_FAILURE:
            let subListFailureData = {
                ...payload,
                results : state.results,
                [pmid] : {
                  sub_status : 3,
                  message : "产品签约失败"
                }
            };

            return {
                ...state,
                ...subListFailureData
            };    
        // ==============================================
        // 股票签约修改
        // ==============================================

        case types.MODIFY_STOCK:
            return {
                ...state,
                ...payload,
                [pmid] : {
                  modify_status : 1,
                  message : "修改中"
                }
            };
        case types.MODIFY_STOCK_SUCCESS:

            let modifyStateClone = {};
            Object.assign(modifyStateClone, state);

            updateStockStatus(modifyStateClone.results, pmid, 1, "MODIFY");

            let modifySuccessData = {
                ...payload,
                results : modifyStateClone.results,
                [pmid] : {
                  modify_status : 2,
                  message : "修改成功"
                }
            };
            return {
                ...state,
                ...modifySuccessData
            };
            

        case types.MODIFY_STOCK_FAILURE:
            let modifyFailureData = {
                ...payload,
                results : state.results,
                [pmid] : {
                  modify_status : 3,
                  message : payload.message
                }
            };

            return {
                ...state,
                ...modifyFailureData
            };
        // ==============================================
        // 股票退签
        // ==============================================

        case types.UNSUB_STOCK:
            return {
                ...state,
                ...payload,
                [pmid] : {
                  unsub_status : 1,
                  message : "退签中"
                }
            };
        case types.UNSUB_STOCK_SUCCESS:

            let unsubStateClone = {};
            Object.assign(unsubStateClone, state);

            updateStockStatus(unsubStateClone.results, pmid, 0, "UNSUB");

            let unsubSuccessData = {
                ...payload,
                results : unsubStateClone.results,
                [pmid] : {
                  unsub_status : 2,
                  message : "退签成功"
                }
            };
            return {
                ...state,
                ...unsubSuccessData
            };

        case types.UNSUB_STOCK_FAILURE:
            let unsubFailureData = {
                ...payload,
                results : state.results,
                [pmid] : {
                  unsub_status : 3,
                  message : payload.message
                }
            };

            return {
                ...state,
                ...unsubFailureData
            };

        default:
            return state;
    }
}
