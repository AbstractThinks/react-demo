import * as types from '../constant/actiontype';

export default function user(state = [], action = {}) {
  const {
        type, payload
    } = action;

  switch (type) {
        case types.USER_LOGIN:

            return {
                ...state,
                ...payload
            };
        case types.USER_LOGIN_SUCCESS:
            return {
                ...state,
                ...payload
            };
        case types.USER_LOGIN_FAILURE:
            let failureInfo = {
                status: -1,
                message: payload.message || '网络连接失败'
            };
            return {
                ...state,
                ...failureInfo
            };
        default:
            return state;
    }
}
