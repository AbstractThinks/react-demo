import * as types from '../constant/actiontype';


export default function stockreportdetail(state = [], action = {}) {
  const { type, payload } = action;
  let loader = false;
  switch(type) {

    case types.FETCH_STOCK_REPORT:
      return {
        ...state,
        ...payload
      }
    case types.FETCH_STOCK_REPORT_SUCCESS:
      let successResult = [{
        ...payload.results[0],
        btnenable : "1"
      }];
      return {
        ...state,
        ...payload,
        loader : false,
        results : successResult
      }
    case types.FETCH_STOCK_REPORT_FAILURE:
      if ( 401 === payload.status ) {
        loader = true;
      }
      return {
        ...state,
        ...payload,
        loader : loader
      }
  	case types.SUB_STOCK_REPORT:
      return {
        ...state,
        ...payload
  		}
  	case types.SUB_STOCK_REPORT_SUCCESS:
      let subSuccessResult = [{
        ...state.results[0],
        ...payload.results[0],
        islock : "1",
        btnenable : "0"
      }];
  		return {
  			...state,
        ...payload,
        loader: false,
        unlockStatus : 2,
        results : subSuccessResult
  		}
      
  	case types.SUB_STOCK_REPORT_FAILURE:
      
      if ( 401 === payload.status ) {
          loader = true;
      }
      let subFailureResult = [{
        ...state.results[0],
        ...payload.results[0]
      }];
  		return {
  			...state,
        ...payload,
        loader : loader,
        unlockStatus : 3,
        results : subFailureResult
  		}
  		
  	default:
        return state;
  }

}