import * as types from '../constant/actiontype';

export default function userinfo(state = [], action = {}) {
  const {
        type, payload
    } = action;

  switch (type) {
        case types.USER_INFO:
            return {
                ...state,
                ...payload
            };
        case types.USER_INFO_SUCCESS:
            return {
                ...state,
                ...payload,
                loader:false,
                flag : state.flag + 1
            };
        case types.USER_INFO_FAILURE:
            let loader = false;
            if ( 401 === payload.status ) {
                loader = true;
            }
            let failureInfo = {
                status: -1,
                message: payload.message || '网络连接失败'
            };
            return {
                ...state,
                ...failureInfo,
                loader:loader
            };
         case types.RESET_USER_INFO:
            return {
                ...state,
                ...payload,
                flag : 0
            };
        default:
            return state;
    }
}