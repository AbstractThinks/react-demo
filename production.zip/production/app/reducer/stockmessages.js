import * as types from '../constant/actiontype';

export default function stockmessages(state = [], action = {}) {
  let {
        type, payload, pmid
    } = action;

  switch (type) {
        case types.FETCH_STOCK_MESSAGES:
            return {
                ...state,
                [pmid]: {
                    ...state[pmid],
                    ...payload,
                    status : 1
                }
            };
        case types.FETCH_STOCK_MESSAGES_SUCCESS:
            let successInfo = {};
            if ( 1 === payload.page.pageNo ) {
                successInfo = {
                    results : [
                        ...payload.results
                    ]
                }
            } else {
                successInfo = {
                    results : [
                       ...state[pmid].results,
                       ...payload.results
                    ]
                }
            }

            return {
                ...state,
                [pmid] : {
                    ...state[pmid],
                    ...payload,
                    ...successInfo,
                    status : 2,
                    loader : false,
                    flag : state[pmid].flag + 1
                }
            };
        case types.FETCH_STOCK_MESSAGES_FAILURE:
            let loader = false;
            let status = 3;
            if ( 401 === payload.status ) {
                loader = true;
                status = payload.status;
            }
            return {
                ...state,
                [pmid] : {
                    ...state[pmid],
                    status : status,
                    message : payload.message,
                    loader : loader
                }
            };
        case types.RESET_STOCK_MESSAGES:
            return {
                ...state,
                [pmid] : {
                    ...state[pmid],
                    ...payload,
                    flag : 0
                }
            };
        default:
            return state;
    }
}
