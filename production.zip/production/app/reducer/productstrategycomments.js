import * as types from '../constant/actiontype';
//import {items} from '../mock/productstrategy';
//import {unlockitems} from '../mock/strategydetailunlock';


export default function productstrategycomments(state = [], action = {}) {
  const { type, payload } = action;
  let loader = false;
  switch(type) {
    case types.FETCH_PRODUCTS_STRATEGY_COMMENTS:
      return {
        ...state,
        ...payload
      }
    case types.FETCH_PRODUCTS_STRATEGY_COMMENTS_SUCCESS:
      // return {
      //   ...state,
      //   ...items,
      //   loader: false,
      // }
      return {
        ...state,
        ...payload,
        loader:false
      }
    case types.FETCH_PRODUCTS_STRATEGY_COMMENTS_FAILURE:
      if ( 401 === payload.status ) {
        loader = true;
      }
      return {
        ...state,
        ...payload,
        loader : loader
      }
  		
  	default:
        return state;
  }

}