import * as types from '../constant/actiontype';

import * as reVisitData from '../mock/revisit';

export default function revisit(state = [], action = {}) {
  let {
        type, payload, name
    } = action;

  switch (type) {
        case types.FETCH_REVISIT_INFO:
            return {
                ...state,
                ...payload
            };
        case types.FETCH_REVISIT_INFO_SUCCESS:
            payload = reVisitData.items;

            return {
                ...state,
                ...payload,
                loader : false
            };
        case types.FETCH_REVISIT_INFO_FAILURE:
            let loader = false;
            if ( 401 === payload.status ) {
                loader = true;
            }
            return {
                ...state,
                ...payload,
                loader : loader
            };
        case types.COMMIT_REVISIT_INFO:
            return {
                ...state,
                status : 0,
                ...payload
            };
        case types.COMMIT_REVISIT_INFO_SUCCESS:
            return {
                ...state,
                status : 1,
                message : "回访结果提交成功",
                loader : false
            };
        case types.COMMIT_REVISIT_INFO_FAILURE:
            loader = false;
            let status = -1;
            if ( 401 === payload.status ) {
                loader = true;
                status = 401;
            }
            return {
                ...state,
                status : status,
                message : "回访结果提交失败",
                loader : loader
            };
        default:
            return state;
    }
}
