import * as types from '../constant/actiontype';

function updateStockStatus(stocks, pid, status, type){
    if(stocks && stocks.length && pid){
        for(let i = 0, len = stocks.length; i< len; i++){
            let stock = stocks[i];
            if (stock.id == pid) {
                stock.issubscribe = status;
                if(type==="SUB") {
                    stock.subscribenum = parseInt(stock.subscribenum) + 1;
                } else if(type==="UNSUB") {
                    stock.subscribenum = parseInt(stock.subscribenum) - 1;
                }
            };
        }
    }
}
export default function stock(state = [], action = {}) {
  const {
        type, payload, pmid
    } = action;
  switch (type) {
        case types.FETCH_STOCKS:
            return {
                ...state,
                ...payload,
                status : 1
            };
        case types.FETCH_STOCKS_SUCCESS:
            let successInfo = {};
            if ( 1 === payload.page.pageNo ) {
                successInfo = {
                    results : [
                        ...payload.results
                    ]
                }
            } else {
                successInfo = {
                    results : [
                       ...state.results,
                       ...payload.results
                    ]
                }
            }

            return {
                ...state,
                ...payload,
                ...successInfo,
                status : 2,
                loader : false,
                flag : state.flag + 1
            };
        case types.FETCH_STOCKS_FAILURE:
            let loader = false;
            let status = 3;
            if ( 401 === payload.status ) {
                loader = true;
                status = payload.status;
            }
            return {
                ...state,
                status : status,
                message : payload.message,
                loader : loader
            };
        case types.RESET_STOCKS:
            return {
                ...state,
                ...payload,
                flag : 0
            };
        // ==============================================
        // 股票签约
        // ==============================================

        case types.SUB_STOCK:
            return {
                ...state,
                ...payload,
                [pmid] : {
                  sub_status : 1,
                  message : "签约中"
                }
            };
        case types.SUB_STOCK_SUCCESS:
            let subStateClone = {};
            // console.log("list:",pmid);
            Object.assign(subStateClone, state);

            updateStockStatus(subStateClone.results, pmid, 1, "SUB");

            let subSuccessData = {
                ...payload,
                results : subStateClone.results,
                [pmid] : {
                  sub_status : 2,
                  message : "恭喜您签约成功"
                }
            };
            return {
                ...state,
                ...subSuccessData
            };
            

        case types.SUB_STOCK_FAILURE:
            let subFailureData = {
                ...payload,
                results : state.results,
                [pmid] : {
                  sub_status : 3,
                  message : "产品签约失败"
                }
            };

            return {
                ...state,
                ...subFailureData
            };
        // ==============================================
        // 股票搜索页签约，保证状态统一
        // ==============================================

        case types.SUB_SEARCH_STOCK:
            return {
                ...state,
                ...payload,
                [pmid] : {
                  sub_status : 1,
                  message : "签约中"
                }
            };
        case types.SUB_SEARCH_STOCK_SUCCESS:
            let subSearchStateClone = {};
            Object.assign(subSearchStateClone, state);

            updateStockStatus(subSearchStateClone.results, pmid, 1, "SUB");

            let subSearchSuccessData = {
                ...payload,
                results : subSearchStateClone.results,
                [pmid] : {
                  sub_status : 2,
                  message : "恭喜您签约成功"
                }
            };
            return {
                ...state,
                ...subSearchSuccessData
            };
            

        case types.SUB_SEARCH_STOCK_FAILURE:
            let subSearchFailureData = {
                ...payload,
                results : state.results,
                [pmid] : {
                  sub_status : 3,
                  message : "产品签约失败"
                }
            };

            return {
                ...state,
                ...subSearchFailureData
            };
        // ==============================================
        // 股票签约修改
        // ==============================================

        case types.MODIFY_STOCK:
            return {
                ...state,
                ...payload,
                [pmid] : {
                  modify_status : 1,
                  message : "修改中"
                }
            };
        case types.MODIFY_STOCK_SUCCESS:

            let modifyStateClone = {};
            Object.assign(modifyStateClone, state);

            updateStockStatus(modifyStateClone.results, pmid, 1, "MODIFY");

            let modifySuccessData = {
                ...payload,
                results : modifyStateClone.results,
                [pmid] : {
                  modify_status : 2,
                  message : "修改成功"
                }
            };
            return {
                ...state,
                ...modifySuccessData
            };
            

        case types.MODIFY_STOCK_FAILURE:
            let modifyFailureData = {
                ...payload,
                results : state.results,
                [pmid] : {
                  modify_status : 3,
                  message : payload.message
                }
            };

            return {
                ...state,
                ...modifyFailureData
            };
        // ==============================================
        // 股票退签
        // ==============================================

        case types.UNSUB_STOCK:
            return {
                ...state,
                ...payload,
                [pmid] : {
                  unsub_status : 1,
                  message : "退签中"
                }
            };
        case types.UNSUB_STOCK_SUCCESS:

            let unsubStateClone = {};
            Object.assign(unsubStateClone, state);

            updateStockStatus(unsubStateClone.results, pmid, 0, "UNSUB");

            let unsubSuccessData = {
                ...payload,
                results : unsubStateClone.results,
                [pmid] : {
                  unsub_status : 2,
                  message : "退签成功"
                }
            };
            return {
                ...state,
                ...unsubSuccessData
            };
            

        case types.UNSUB_STOCK_FAILURE:
            let unsubFailureData = {
                ...payload,
                results : state.results,
                [pmid] : {
                  unsub_status : 3,
                  message : payload.message
                }
            };

            return {
                ...state,
                ...unsubFailureData
            };
        default:
            return state;
    }
}
