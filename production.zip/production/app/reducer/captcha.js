import * as types from '../constant/actiontype';

export default function captcha(state = [], action = {}) {
  const {
        type, payload
    } = action;

  switch (type) {
        case types.FETCH_CAPTCHA:

            return {
                ...state,
                ...payload
            };
        case types.FETCH_CAPTCHA_SUCCESS:
            let captchaData = payload.results[0].img;
            captchaData = "data:image/png;base64," + captchaData
            return {
                ...state,
                results:captchaData
            };
        case types.FETCH_CAPTCHA_FAILURE:

            return {
                ...state,
                ...payload
            };
        default:
            return state;
    }
}
