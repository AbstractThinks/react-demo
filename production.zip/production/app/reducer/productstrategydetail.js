import * as types from '../constant/actiontype';
//import {items} from '../mock/productstrategy';
//import {unlockitems} from '../mock/strategydetailunlock';


export default function productstrategydetail(state = [], action = {}) {
  const { type, payload } = action;
  let loader = false;
  switch(type) {

    case types.FETCH_PRODUCTS_STRATEGY:
      return {
        ...state,
        ...payload
      }
    case types.FETCH_PRODUCTS_STRATEGY_SUCCESS:
      // return {
      //   ...state,
      //   ...items,
      //   loader: false,
      // }
      return {
        ...state,
        ...payload,
        loader: false
      }
    case types.FETCH_PRODUCTS_STRATEGY_FAILURE:
      if ( 401 === payload.status ) {
        loader = true;
      }
      return {
        ...state,
        ...payload,
        loader : loader
      }


  	case types.SUB_PRODUCT_STRATEGY:
      return {
        ...state,
        ...payload
  		}
  	case types.SUB_PRODUCT_STRATEGY_SUCCESS:
      let successResult = [{
        ...state.results[0],
        ...payload.results[0],
        islock : "1",
        btnenable : "0"
      }];
  		return {
  			...state,
        ...payload,
        loader: false,
        unlockStatus : 2,
        results : successResult
  		}
      // return {
      //   ...state,
      //   ...unlockitems,
      //   loader: false,
      // }
      
  	case types.SUB_PRODUCT_STRATEGY_FAILURE:
      
      if ( 401 === payload.status ) {
          loader = true;
      }
      let failureResult = [{
        ...state.results[0]
      }];
  		return {
  			...state,
        ...payload,
        loader : loader,
        unlockStatus : 3,
        results : failureResult
  		}
  		
  	default:
        return state;
  }

}