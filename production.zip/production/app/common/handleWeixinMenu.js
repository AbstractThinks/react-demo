export function handleWeixinMenu() {
	wx.hideAllNonBaseMenuItem();
	console.log(wx.hideAllNonBaseMenuItem);
}