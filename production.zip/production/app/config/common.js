import { siteDomain } from '../config/api';

export const VERSION = "3.0.8";

export const checkRiskLevel = true;

export const reVisit = true;

//产品状态
export const productStatus = {
	hasSubscribe : "2",
	noSubscribe : "1",
	unSubscribing : "4"
}

//消息类型
export const messageType = {
	dianping : "1",
	diaochu : "2",
	diaoru : "3"
}



// export const appId = "4e36e8bc025562ddd0369f2d6b55b4b06784cd75"; //测试
export const appId = "0639916c4be53a5dfaab38884b602d5b01eb2a40"; //生产

export const wxDefaultConfig = { 
	link : siteDomain + "ycf/m/#/share",
	// msgImg : siteDomain + "ycf/m/asset/img/share-logo.jpg",
	msgImg : "http://cdn1.hx168.com.cn/ycf/img/share-logo.jpg",
	msgTitle : "赢财富：专注者，赢！",
	msgContent : "一次仅推荐一只股的证券服务工具",
	msgCallBack : "",
	// lineImg : siteDomain + "ycf/m/asset/img/share-logo.jpg",
	lineImg : "http://cdn1.hx168.com.cn/ycf/img/share-logo.jpg",
	lineTitle : "赢财富：专注者，赢！",
	lineCallBack : "",
	hideAll : true
};
