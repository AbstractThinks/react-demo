// export const siteDomain = "http://wxtest.hx168.com.cn/"; //测试
export const siteDomain = "http://wx.hx168.com.cn/"; //生产

//数据接口地址
// export const api = 'http://127.0.0.1:8080/HUAXI/code/m/hxfinance/index.php/coxcombry/index/';
// export const api = 'http://192.168.2.101:8080/HUAXI/code/m/hxfinance/index.php/coxcombry/index/';
// export const api = 'http://wx.hx168.com.cn/ycf/api/v1.0/';
export const api = siteDomain + 'ycf/api/v1.0/'; 
// export const api = 'http://10.33.4.203:7080/ycf/api/v1.0/'; 
// export const api = 'http://10.33.4.49:7080/ycf/api/v1.0/'; 
// export const api = 'http://10.33.95.30:9080/ycf/api/v1.0/';
// export const api = 'http://127.0.0.1:9080/ycf/api/v1.0/'; 

//股票在线行情接口
export const stock_info_api = 'https://trade.hx168.com.cn/v2/m/hq/#!/hq/ggStockInfo.html?channel=1&stockcode={0}&market={1}&source=ycf';

//股票买入接口
export const stock_buy_api = 'https://trade.hx168.com.cn/v2/m/trade/index.html#!/stock/stockBuy.html?source=ycf&code={0}&market={1}';

//股票卖出接口
export const stock_sell_api = 'https://trade.hx168.com.cn/v2/m/trade/index.html#!/stock/stockSell.html?source=ycf&code={0}&market={1}';

export const hxaccount_download_ios_url = 'https://itunes.apple.com/cn/app/hua-xi-zheng-quan-shou-ji-kai-hu/id819894901?mt=8';

export const hxaccount_download_android_url = 'http://o2o.hx168.com.cn/m/o2o/download/account/apk/ycf/hxaccount.apk';

//resourceURI
export const resourceURI = 'http://cdn1.hx168.com.cn/ycf/';
// export const resourceURI = '../asset/';
// export const resourceURI = '../';
// export const resourceURI = siteDomain + 'ycf/m/asset/';

//公众号跳转链接
export const official_account_url = 'http://mp.weixin.qq.com/s?__biz=MzIyNzA0OTAxOA==&mid=409010318&idx=1&sn=b709ca1fa6207cb3653bd6ed2efab990&scene=0&previewkey=A%2BM2t%2BvtvR4dL6lTIMgCT51iJUUG%2F7eLf7OA%2FVEtaJE%3D#wechat_redirect';

//验权链接
export const authUrl =  siteDomain + 'ycf/authorize?'