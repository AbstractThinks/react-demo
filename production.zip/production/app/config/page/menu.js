export const items = [{
    icon: "ion-ios-toggle-outline",
    activeIcon: "ion-ios-toggle",
    text: "签约服务",
    link: "/Product"
}, {
    icon: "ion-ios-clock-outline",
    activeIcon: "ion-ios-clock",
    text: "历史操作",
    link: "/Message"
}]