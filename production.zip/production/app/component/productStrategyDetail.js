import React from 'react';
import Notify from '../common/notification';
import StrategyFooter from './footer';
import Modal from 'boron/ScaleModal';
import StrategyLock from './modal/strategylock';
import ProtocalUse from './modal/protocalUse';
import {
    formatDate
} from '../common/formater';



class ProductStrategyDetail extends React.Component {

    constructor(props) {
        super(props);
        this.displayName = 'ProductStrategy';
        this.showMessage = false;
        this.state = {
            modalBackdrop: true,
            modalClass: "modal-container",
            modalContent: null,
            modalProtocalBackdrop: false,
            modalProtocalContent: null,
            modalProtocalClass: "modal-container-full modal-protocal"
        };
        this.subProtocolStatus = true;
        this.enabledClick = true;
    }
    componentDidMount() {
        document.body.scrollTop = 0;
        let {
            productStrategyDetail
        } = this.props;
        if(this.refs.privateContent && productStrategyDetail.unlockStatus === 2) {
            this.refs.privateContent.scrollIntoView();
        }
    }

    /**
     * 真实的DOM被渲染出来后调用
     * @return {[type]}
     */
    componentDidUpdate() {
        let {
            productStrategyDetail
        } = this.props;
        if (productStrategyDetail.unlockStatus !== 0 && productStrategyDetail.unlockStatus !== 1 && this.showMessage) {
            //this.refs.privateContent.scrollIntoView();
            Notify.makeNotify(productStrategyDetail.message);
            this.showMessage = false;
        }
        if(productStrategyDetail.unlockStatus === 0 || productStrategyDetail.unlockStatus === 3) {
            this.enabledClick = true;
        }
    }

    /**
     * 策略文章解锁
     * @param  {[type]}
     * @return {[type]}
     */
    handleUnlock(e) {
        if(this.enabledClick) {
            e.preventDefault();
            e.stopPropagation();
            let modalContent = < StrategyLock
            onProtocolChange = {
                this.onProtocolChange.bind(this)
            }
            onSureClick = {
                this.onSubscribeClick.bind(this)
            }
            onCloseClick = {
                this.onModalClose.bind(this)
            }
            onOpenProtocal = {
                this.handleOpenProtocal.bind(this)
            }
            productStrategyDetail = {
                this.props.productStrategyDetail
            } /> 

            this.setState({
                modalBackdrop: true,
                modalClass: "modal-container",
                modalContent: modalContent
            });

            this.refs.modalStrategy.show();
        }
    }
    /**
     * 协议详情弹出框
     * @return {[type]}
     */
    handleOpenProtocal() {
        let { productStrategyDetail } = this.props; 
        let userinfo = productStrategyDetail.results[0].user;
        let modalContent = < ProtocalUse 
                              onCloseClick = {
                                this.handleCloseProtocal.bind(this)
                              } 
                              userinfo = { userinfo }/> 
        this.setState({
            modalProtocalContent: modalContent
        });
        this.refs.modalStrategy.hide();
        this.refs.modalProtocal.show();
    }
    /**
     * 关闭协议详情弹出框
     * @return {[type]}
     */
    handleCloseProtocal() {
        this.refs.modalProtocal.hide();
        this.refs.modalStrategy.show();
    }
    /**
     * 修改确认协议信息
     * @param  {[type]}
     * @return {[type]}
     */
    onProtocolChange(status) {
        this.subProtocolStatus = status;
    }
    /**
     * 确认解锁
     * @return {[type]}
     */
    onSubscribeClick() {
        if (this.subProtocolStatus && this.enabledClick) {
            this.props.subProductStrategy({pid : this.props.id,
                resolved: ()=>{
                  this.props.fetchProductsStrategyComments(this.props.articleid);
                }});

            this.enabledClick = false;
            this.showMessage = true;
            this.refs.modalStrategy.hide();
        }

    }
    /**
     * 关闭modal
     * @return {[type]}
     */
    onModalClose() {
        this.refs.modalStrategy.hide();
    }
    /**
     * 是否显示隐藏内容
     * @return {[type]}
     */
    handleUnlockStatus() {
        let { productStrategyDetail } = this.props;
        let isprivate = productStrategyDetail.results[0].isprivate,
            islock = productStrategyDetail.results[0].islock,
            isend = productStrategyDetail.results[0].isend;

        if(isend === '1' || (isprivate === '1' && islock === '1')) {
            return 'show';
        } else if(isprivate === '1' && islock !== '1') {
            return 'hide';
        }
        return 'none';
    }
    /**
     * 点评更新时间渲染
     * @return {[type]}
     */
    renderUpdateTime(updatetime = "") {
        let renderUpdateTime = formatDate(updatetime, "yyyy年MM月dd hh:mm") || "";
        renderUpdateTime = `-${renderUpdateTime} 更新-`;
        return renderUpdateTime;
    }
    /**
     * 页面渲染
     * @return {[type]}
     */
    render() {

        let {
            productStrategyDetail,
            productStrategyComments
        } = this.props;
        let unlockStatus = this.handleUnlockStatus();
        let shcreatetime = productStrategyDetail.results[0].shcreatetime.substring(0, productStrategyDetail.results[0].shcreatetime.length-3)
        // let updatetime = formatDate(productStrategyDetail.results[0].shcreatetime, "yyyy年MM月dd HH:mm");
        // let shcreatetime = productStrategyDetail.results[0].shcreatetime;
        return ( 
            <div className = "strategy-product" >
                <div className = "blank30"></div> 
                <div className = "card content-strategy-detail">
                    <div className = "strategy-header" >

                        <h5 > 
                            <b > {
                                productStrategyDetail.results[0].name
                            } </b>
                        </h5 >

                    </div> 
                    <div className = "strategy-shcreatetime" >

                        <small className = 'text-muted' > {
                            `${shcreatetime} 发布`
                        } </small>     

                    </div> 
                    <div className = "strategy-abstract" >

                        摘 要: {
                            productStrategyDetail.results[0].abstract
                        } 

                    </div>
                    {
                        unlockStatus === 'show' ?

                            productStrategyComments.results && productStrategyComments.results.length > 0 ?  
                                productStrategyComments.results.map((productStrategyComment, i) =>  
                                <div className = 'strategy-content' >
                                    <div className = 'strategy-update-title' > 
                                        <div className = 'strategy-update-title-text text-center' >{this.renderUpdateTime(productStrategyComment.createtime)}</div> 
                                    </div>
                                    <div className = "" dangerouslySetInnerHTML = {{__html: productStrategyComment.content}}></div> 
                                </div>)
                                :
                                null 
                            :
                            null
                    }

                    {
                        unlockStatus === 'show' ?

                            productStrategyComments.results && productStrategyComments.results.length > 0 ?  
                                <div className = 'strategy-unlock-title' >
                                    <div className = 'strategy-unlock-title-line'> </div> 
                                    <div className = 'strategy-unlock-title-text text-center' >以下为原文内容</div> 
                                </div>
                                :
                                null 
                            :
                            null
                    }
                    
                    <div className = "strategy-content" dangerouslySetInnerHTML = {{__html: productStrategyDetail.results[0].descript}}></div>

                    {
                        unlockStatus === 'show' ?

                            <div className = 'strategy-content' ref="privateContent">
                                <div className = 'strategy-unlock-title' >
                                    <div className = 'strategy-unlock-title-line'> </div> 
                                    <div className = 'strategy-unlock-title-text text-center' >以下为解锁内容</div> 
                                </div>
                                <div className = "" dangerouslySetInnerHTML = {{__html: productStrategyDetail.results[0].private}}></div>
                            </div>
                            :
                            unlockStatus === 'hide' ?
                                <div className = "strategy-lock card card-strategy text-center" >

                                    <p> -更多核心内容， 需要解锁后查看 - </p> 
                                    <p> 
                                        {
                                           productStrategyDetail.results[0].btnenable === "1"?
                                            <button className = {"btn btn-dark btn-strategy"}
                                                href = "javascript:void(0);"
                                                onClick = {
                                                        this.handleUnlock.bind(this)
                                                    } > 点击解锁 
                                            </button>
                                            :
                                            <a className = {"btn btn-dark btn-strategy disabled"}
                                                href = "javascript:void(0);"
                                                > 不在解锁时间范围内 
                                            </a> 
                                        }
                                    
                                    </p>
                                    <p> 

                                        <small className = 'text-muted'> 
                                        {
                                                productStrategyDetail.results[0].unlocknum
                                            }
                                        人已解锁 </small>

                                    </p>

                                </div>
                                : 
                                null
                    } 
                </div> 
                <div className = "blank30" > </div> 
                <div className = "blank100" > </div> 
                <StrategyFooter />

                <Modal ref = "modalStrategy"
                    backdrop = {
                        this.state.modalBackdrop
                    }
                    className = {
                        this.state.modalClass
                    } > {
                        this.state.modalContent
                    } 
                    </Modal> 
                    <Modal ref = "modalProtocal"
                    backdrop = {
                        this.state.modalProtocalBackdrop
                    }
                    className = {
                        this.state.modalProtocalClass
                    } > {
                        this.state.modalProtocalContent
                    } 
                </Modal> 
            </div>
        );
    }
}

export default ProductStrategyDetail;