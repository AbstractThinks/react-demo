import React from 'react';
import {
	Link
} from 'react-router';
import {
    localStorageService
} from '../common/Storage';

class ProductStrategyItem extends React.Component {
	constructor(props) {
		super(props);
		this.displayName = 'ProductStrategyItem';
	}


  	/**
   * 渲染更新、完结标识
   * @return {[type]}
   */
    renderMark(isend=0, id=0, seedItemVal="") {
    	if(seedItemVal && (seedItemVal.trim()!="")) {
    		let seedItemStorageKey = `NOTIFY_LINK_${id}`;
			let currentCacheVal = localStorageService.get(seedItemStorageKey);
			if((!currentCacheVal) || (seedItemVal && (seedItemVal.trim()!="") && (seedItemVal > currentCacheVal))){
	        	return(
	        		<span className = "product-Strategy-update"> [有更新]</span>
	        	);
	        }
    	}
    	if(isend === "1") {
        	return(
        		<span className = "product-Strategy-end"> [已完结]</span>
        	);
        }
        return null;
    }
	/**
	 * 页面渲染
	 * @return {[type]}
	 */
	render() {
		let {
			productStrategyInfo
		} = this.props;
		// let shcreatetime = formatDate(productStrategyInfo.shcreatetime, "yyyy-MM-dd HH:mm");
		let shcreatetime = productStrategyInfo.shcreatetime.substring(0, productStrategyInfo.shcreatetime.length-3)

		return (

			<div>
			<div className = "blank5" > < /div> 
			<div className = "blank10" > < /div> 
				<Link 
					to = { `productstrategydetail` }
					query = {{ id: productStrategyInfo.id, articleid: productStrategyInfo.articleid }}
					className = "link-normal" >

					<div className = "card card-message animated zoomIn card-list-strategy" >
						
						<div className = "card-header" >
							<div className = "card-header-title">
								<p>{ productStrategyInfo.name }</p>
							</div> 
							 
							<small className = "pull-right" > 
								{ shcreatetime } 
							</small>
						</div>

						<div className = "card-block" >
							<p 
								className = "card-text"
								dangerouslySetInnerHTML = {{__html: productStrategyInfo.abstract}} > 

							</p> 
							<div className = "card-footer text-muted product-strategy-check">
								点击查看 
								{
									this.renderMark(productStrategyInfo.isend, productStrategyInfo.id, productStrategyInfo.latestcommenttime)
								} 
								<span className = "pull-right">
									>
								</span> 
							</div> 

						</div>

					</div> 
				</Link> 
			</div>

		)
	}
}

export default ProductStrategyItem;