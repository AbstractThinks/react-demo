import React from 'react';

class ChoiceItem extends React.Component {

  constructor() {
    super();
  }
  componentWillMount() {
  }
  /**
   * @param  {[type]}
   * @return {[type]}
   */
  _preventDefualtEvent(event) {
    event.stopPropagation();
  }
  
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {
    let { isChoiced, isMustChoice, text } = this.props;
    return(
        <div className="push-choice choice-option">
          {
            isMustChoice || isChoiced ? 
              <span className="push-choice-img-choiced"><i className="ion-ios-circle-filled"></i></span>
              : 
              <span className="push-choice-img"><i className="ion-ios-circle-outline"></i></span>
          }
          <span className="push-choice-text">{text}</span>
        </div>
    )
  }
}

export default ChoiceItem;
