import React from 'react';

class ServerItem extends React.Component {

  constructor() {
    super();
  }
  /**
   * @param  {[type]}
   * @return {[type]}
   */
  _preventDefualtEvent(event) {
    event.stopPropagation();
  }

  renderHead() {
    let { serverItem, index, active } = this.props;
    return(
        <div className={ index == active ? "server-item-choiced-head" : "server-item-head" }>
          <span>{ serverItem.pkgname }</span>
        </div>
      );
    
  }
  renderBody() {
    let { serverItem, single, opt } = this.props;
    return(
        <div className="server-item-body">
          <div className="server-item-body-title">
            <span></span>
          </div>
          <ul className={ single && opt === "sub" ? "server-item-single-ul" : "" }>
            {
              serverItem.freegives && serverItem.freegives.length > 0 ?
                serverItem.freegives.map((item, i) =>
                  <li key = {i}>
                    <span>{item}</span>
                  </li>)
                  :
                  null
            }
          </ul>
        </div>
      );
    
  }
  renderFoot() {
    let { index, active, choiced, single } = this.props;
    return(
        index == active && !single ? 
          <div className="server-item-choiced-foot">
            <div className="triangle-bottomright">
              <span>
                <i className="ion-checkmark"></i>
              </span>
            </div>
          </div>
          : 
          <div></div>
      );
    
  }
  
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {
    let { index, active, choiced } = this.props;
    return(
        <div className={ index == active ? "server-item-choiced" : "server-item" }>
          { this.renderHead() }
          { this.renderBody() }
          { this.renderFoot() }
        </div>
    )
  }
}

export default ServerItem;
