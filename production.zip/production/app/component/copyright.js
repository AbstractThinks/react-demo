import React from 'react';
import Modal from 'boron/ScaleModal';
import ModalPhone from '../component/modal/phonecall';
import ModalCertification from '../component/modal/certification';

class CopyRight extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          modalBackdrop : true,
          modalClass : "modal-container",
          modalContent : null
        };
    }
     handlePhoneModal(e){
        e.preventDefault();
        e.stopPropagation();
        
        let modalContent = null;
        
        modalContent = <ModalPhone 
            onCloseClick = { this.onModalClose.bind(this) }/>

        this.setState({
            modalBackdrop : true,
            modalClass : "modal-container",
            modalContent : modalContent
        });

        this.refs.modalPhone.show();
    }
    onModalClose(){
        this.refs.modalPhone.hide();
    }

    handleCertModal(e){
      e.preventDefault();
      e.stopPropagation();
      
      let modalContent = null;
      
      modalContent = <ModalCertification 
        onCloseClick = { this.onModalCertClose.bind(this) }/>

      this.setState({
        modalBackdrop : false,
        modalClass : "modal-container-full",
        modalContent : modalContent
      });

      this.refs.modalCert.show();
    }
    onModalCertClose(){
      this.refs.modalCert.hide();
    }
    /**
     * 页面渲染
     * @return {[type]}
     */
    render() {
        return (
        	<div className = {'product-foot text-muted'}>
            <div className="inline-block pull-left"> <span className='copyright-underline' onClick = { this.handleCertModal.bind(this) } >赢财富专家团队信息公示</span></div>
            <div className = 'inline-block pull-right' onClick={ this.handlePhoneModal.bind(this)} ><span className='copyright-underline'>客服及投诉电话：95584</span></div>
            <Modal ref="modalPhone"
              backdrop = { this.state.modalBa }
              className= { this.state.modalClass }>
                { this.state.modalContent }
            </Modal>
            <Modal ref="modalCert" 
              backdrop = { this.state.modalBa}
              className= { this.state.modalClass }>
                { this.state.modalContent }
            </Modal> 
          </div>
        )
    }
}

export default CopyRight;
