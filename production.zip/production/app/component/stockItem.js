import React from 'react';
import { Link } from 'react-router';
import Notify from '../common/notification';
import Modal from 'boron/ScaleModal';
import StockSubscribe from './modal/stocksubscribe';
import ProtocalUse from './modal/protocalUse';
import ProtocolSF from './modal/protocolsf';
import ProtocolRisk from './modal/protocolrisk';

import ModalRiskNotMatch from '../component/modal/risknotmatch';
import ModalReVisit from '../view/revisit';

import { checkRiskLevel,reVisit } from '../config/common';

class StockItem extends React.Component {
	constructor(props) {
		super(props);
		this.showMessage = false;
    this.state = {
      modalBackdrop: true,
      modalClass: "modal-container",
      modalContent: null,
      modalProtocalBackdrop: false,
      modalProtocalContent: null,
      modalProtocalClass: "modal-container-full modal-protocal"
    };
    this.subProtocolStatus = true;
    this.enabledClick = true;
	}

  componentDidUpdate() {
    let { stockId } = this.props;  
    if (stockId) {
        let { sub_status = 0, message = "" } = stockId;
        if (sub_status && sub_status !== 1 && this.showMessage) {
          Notify.makeNotify(message, 1.5);
          this.showMessage = false;
        }
        if(sub_status === 3) {
          this.enabledClick = true;
        }
      }    
  }

	  /**
     * 订阅股票
     * @param  {[type]}
     * @return {[type]}
     */
    handleSubscribe(e) {
      if(this.enabledClick) {
          e.preventDefault();
          e.stopPropagation();
          let { stockservers,userinfo } = this.props;
          if(checkRiskLevel){
            let clientrisklevel = userinfo.clientrisklevel;
            let rinklevel = stockservers.extraInfo.rinklevel;
            let riskMatch = clientrisklevel >= rinklevel ? true : false;
            if(!riskMatch) {
              modalContent = 
              <ModalRiskNotMatch 
                onCloseClick = { this.onModalClose.bind(this) } />;
              this.setState({
                modalBackdrop : true,
                modalClass : "modal-container",
                modalContent : modalContent
              });
              this.refs.modalStockSubscribe.show();
              return;
            }
          }
          let modalContent = <StockSubscribe
          onProtocolChange = {
              this.onProtocolChange.bind(this)
          }
          onSureClick = {
              this.onSubscribeClick.bind(this)
          }
          onOpenProtocal = {
              this.handleOpenProtocal.bind(this)
          }
          stockservers = { stockservers.results } /> 

          this.setState({
              modalBackdrop: true,
              modalClass: "modal-container",
              modalContent: modalContent
          });

          this.refs.modalStockSubscribe.show();
      }
    }
    /**
     * 协议详情弹出框
     * @return {[type]}
     */
    handleOpenProtocal({protocolType, showDate=true, btnText="确认并同意以上规则"}={}) {
      let { userinfo } = this.props;
      let modalContent = 
          protocolType === "use" ? 
              <ProtocalUse 
                  onCloseClick = { this.handleCloseProtocal.bind(this) } 
                  userinfo = { userinfo } 
                  showDate = { showDate }
                  btnText = { btnText }/> 
              : 
              protocolType === "sf" ? 
                  <ProtocolSF 
                      onCloseClick = { this.handleCloseProtocal.bind(this) } 
                      userinfo = { userinfo } 
                      showDate = { showDate }
                      btnText = { btnText }/>
                  : 
                  protocolType === "risk" ? 
                      <ProtocolRisk 
                          onCloseClick = { this.handleCloseProtocal.bind(this) } 
                          userinfo = { userinfo } 
                          showDate = { showDate }
                          btnText = { btnText }/>
                      : 
                      null
      this.setState({
          modalProtocalContent: modalContent
      });
      this.refs.modalStockSubscribe.hide();
      this.refs.modalProtocal.show();
    }
    /**
     * 关闭协议详情弹出框
     * @return {[type]}
     */
    handleCloseProtocal() {
      this.refs.modalProtocal.hide();
      this.refs.modalStockSubscribe.show();
    }
     /**
     * 关闭弹出框
     * @return {[type]}
     */
    onModalClose(){
      this.refs.modalStockSubscribe.hide();
    }
    /**
     * 修改确认协议信息
     * @param  {[type]}
     * @return {[type]}
     */
    onProtocolChange(status) {
      this.subProtocolStatus = status;
    }
    /**
     * 确认订阅
     * @return {[type]}
     */
    onSubscribeClick(active, isSendSMS) {
      if (this.subProtocolStatus && this.enabledClick) {
          // this.props.subProductStrategy({pid : this.props.id,
          //     resolved: ()=>{
          //       this.props.fetchProductsStrategyComments(this.props.articleid);
          //     }});
          let {stockservers} = this.props;
          let isrevisit = stockservers.extraInfo.isrevisit;
          if(reVisit && isrevisit!=1){
            let modalContent = null;
            modalContent = <ModalReVisit 
              onSuccessHandler = { this.onSuccessHandler.bind(this,active,isSendSMS) }
              isNewUser = { true }
              pmid = {"1588021"}/> 
            
            this.setState({
              modalProtocalContent : modalContent
            });

            this.refs.modalStockSubscribe.hide();
            this.refs.modalProtocal.show();

            return;
          } else {
            this.enabledClick = false;
            let { stockItem } = this.props;
            this.props.subStock(stockItem.id, active, isSendSMS);
            this.showMessage = true;
            this.refs.modalStockSubscribe.hide();
          }
      }
    }

    //回访成功后的操作
    onSuccessHandler(active,isSendSMS) {
        this.enabledClick = false;
        let { stockItem } = this.props;
        this.props.subStock(stockItem.id, active, isSendSMS);
        this.showMessage = true;
        this.refs.modalProtocal.hide();
    }

	renderBody() {
    let { stockItem } = this.props;
		return(
			<div className="card-stock-body">
				<div className="card-stock-baseinfo">
					<span className="card-stock-name">{`${ stockItem.stockname }(${ stockItem.stockcode })`}</span>
					<span className="card-stock-blank"></span>
					<span className="card-stock-industry">{`行业：${ stockItem.trades }`}</span>
				</div>
        { 
          stockItem.issubscribe == "1" ? 
            <div className="card-stock-operator pull-right">
              <Link to={ `stockmessage` } query={{ stockId : stockItem.id }} >
                  <button className="btn btn-view" href="javascript:void(0);" >
                    <span>查看</span>
                  </button>
              </Link>
              <span className="card-stock-blank"></span>
              <span>{`${ stockItem.subscribenum }人使用`}</span>
            </div>
            : 
            <div className="card-stock-operator pull-right">
              <button className="btn btn-sub" href="javascript:void(0);" 
                onClick = { this.handleSubscribe.bind(this) } >
                <span>订阅</span>
              </button>
              <span className="card-stock-blank"></span>
              <span>{`${ stockItem.subscribenum }人使用`}</span>
            </div> 
        }
			</div>
			);
	}

	_preventDefualtEvent(event) {
	    event.stopPropagation();
  	}

	/**
	 * 页面渲染
	 * @return {[type]}
	 */
	render() {
		let { stockItem } = this.props;
		return (
			<div>
				<div className = "blank5"> </div> 
        <div className = "blank10"> </div> 
				<div className = "card card-message animated zoomIn card-list-strategy">
					
					<div className = "card-header">
						<div className = "card-header-title">
							<Link to={ `stockreport` } query={{ stockId: stockItem.id }} onTouchEnd={this._preventDefualtEvent.bind(this)}>
                	<p className = "display-inherit color-gold"><span className = "text-underline">企业调研报告</span></p>
            	</Link>
						</div> 
						 
						<div className = "pull-right"> 
							<Link to={ `serverinfo` } state={{stockItem: stockItem}} onTouchEnd={this._preventDefualtEvent.bind(this)}>
              	<p className = "text-underline color-gold">服务人员信息</p>
            	</Link>
						</div>
					</div>

					<div className = "card-block">
						{ this.renderBody() }
					</div>

				</div>
				<Modal ref = "modalStockSubscribe"
          backdrop = {
              this.state.modalBackdrop
          }
          className = {
              this.state.modalClass
          } > {
              this.state.modalContent
          } 
          </Modal> 
          <Modal ref = "modalProtocal"
          backdrop = {
              this.state.modalProtocalBackdrop
          }
          className = {
              this.state.modalProtocalClass
          } > {
              this.state.modalProtocalContent
          } 
        </Modal>
			</div>

		)
	}
}

export default StockItem;