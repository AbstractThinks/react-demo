import React from 'react';

import * as Menu from '../config/page/menu';
import { resourceURI } from '../config/api';
import { VERSION } from '../config/common';

import {
  Link,
  History
} from 'react-router';
class Menubar extends React.Component {

  constructor() {
    super();
  }
  /**
   * @param  {[type]}
   * @return {[type]}
   */
  _preventDefualtEvent(event) {
    event.stopPropagation();
  }
  /**
   * 菜单结构
   * @param  {[type]}
   * @param  {[type]}
   * @return {[type]}
   */
  renderMenuItem (menuItem, index){
    let {
      menuIndex
    } = this.props;

    let menuIcon = (menuIndex == index ? menuItem.activeIcon : menuItem.icon);
    let menuStatus = (menuIndex == index ? "active" : "");

    return (

       <li data-nav="index" className={ menuStatus } key={index} >
          <Link to={ menuItem.link } onTouchEnd={this._preventDefualtEvent.bind(this)}>
              <i className={ menuIcon }></i>
              <span>{ menuItem.text }</span>
          </Link>
       </li>

    )
  }
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {
    return(
        <footer className="navigation">
            <div className="nav-point-bar nav-point-wrap">
                <img className="nav-point" src={`${resourceURI}img/point2.png`} />
                <span className="version">V&nbsp;{VERSION}</span>
            </div>
            <div className="nav-point-bar nav-point-fixed"></div>
          <ul>
            { Menu.items && Menu.items.map((menuItem, i) =>  
              this.renderMenuItem(menuItem, i)
            )}
          </ul>
        </footer>
    )
  }
}

Menubar.propTypes = {
  menuIndex : React.PropTypes.number
}

Menubar.defaultProps = {
  menuIndex : 0
}

export default Menubar;
