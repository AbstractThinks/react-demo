import React from 'react';
import Modal from 'boron/ScaleModal';
import ReportLock from './modal/reportlock';
import StrategyLock from './modal/strategylock';
import ProtocalUse from './modal/protocalUse';
import ProtocolSF from './modal/protocolsf';
import ProtocolRisk from './modal/protocolrisk';
import ProtocolST from './modal/protocolst';

import ModalRiskNotMatch from '../component/modal/risknotmatch';
import ModalReVisit from '../view/revisit';

import { checkRiskLevel,reVisit } from '../config/common';



class UnlockBox extends React.Component {

    constructor(props) {
        super(props);
        this.displayName = 'UnlockBox';
        this.state = {
            modalBackdrop: true,
            modalClass: "modal-container",
            modalContent: null,
            modalProtocalBackdrop: false,
            modalProtocalContent: null,
            modalProtocalClass: "modal-container-full modal-protocal"
        };
        this.subProtocolStatus = true;
    }

    /**
     * 策略文章解锁
     * @param  {[type]}
     * @return {[type]}
     */
    handleUnlock(e) {
        let { enabledClick = false, lockType = "Strategy" } = this.props;
        if(enabledClick) {
            e.preventDefault();
            e.stopPropagation();
            let {detail,userinfo} = this.props;
            if(checkRiskLevel){
                let clientrisklevel = userinfo.clientrisklevel;
                let rinklevel = detail.results[0].rinklevel;
                let riskMatch = clientrisklevel >= rinklevel ? true : false;
                if(!riskMatch) {
                    modalContent = 
                    <ModalRiskNotMatch 
                      onCloseClick = { this.onModalClose.bind(this) } />;
                    this.setState({
                      modalBackdrop : true,
                      modalClass : "modal-container",
                      modalContent : modalContent
                    });
                    this.refs.modalStrategy.show();
                    return;
                }
            }
            let modalContent = 
                lockType === "Strategy" ? 
                    <StrategyLock
                        onProtocolChange = { this.onProtocolChange.bind(this) }
                        onSureClick = { this.onSubscribeClick.bind(this,"1588020") }
                        onCloseClick = { this.onModalClose.bind(this) }
                        onOpenProtocal = { this.handleOpenProtocal.bind(this) }
                        productStrategyDetail = { detail } /> 
                    : 
                    lockType === "Report" ? 
                        <ReportLock
                            onProtocolChange = { this.onProtocolChange.bind(this) }
                            onSureClick = { this.onSubscribeClick.bind(this,"1588021") }
                            onCloseClick = { this.onModalClose.bind(this) }
                            onOpenProtocal = { this.handleOpenProtocal.bind(this) }
                            StockReportDetail = { detail } /> 
                        : 
                        null
                

            this.setState({
                modalBackdrop: true,
                modalClass: "modal-container",
                modalContent: modalContent
            });

            this.refs.modalStrategy.show();
        } 
    }
    /**
     * 协议详情弹出框
     * @return {[type]}
     */
    handleOpenProtocal({protocolType, showDate=true, btnText="确认并同意以上规则"}={}) {
        // let { detail } = this.props; 
        let { userinfo } = this.props;
        //let userinfo = {name: 'sss', num: '123456'};
        let modalContent = 
            protocolType === "use" ? 
                <ProtocalUse 
                    onCloseClick = { this.handleCloseProtocal.bind(this) } 
                    userinfo = { userinfo } 
                    showDate = { showDate }
                    btnText = { btnText }/> 
                : 
                protocolType === "sf" ? 
                    <ProtocolSF 
                        onCloseClick = { this.handleCloseProtocal.bind(this) } 
                        userinfo = { userinfo } 
                        showDate = { showDate }
                        btnText = { btnText }/>
                    : 
                    protocolType === "st" ? 
                        <ProtocolST 
                            onCloseClick = { this.handleCloseProtocal.bind(this) } 
                            userinfo = { userinfo } 
                            showDate = { showDate }
                            btnText = { btnText }/>
                        : 
                        protocolType === "risk" ? 
                            <ProtocolRisk 
                                onCloseClick = { this.handleCloseProtocal.bind(this) } 
                                userinfo = { userinfo } 
                                showDate = { showDate }
                                btnText = { btnText }/>
                            : 
                            null
        this.setState({
            modalProtocalContent: modalContent
        });
        this.refs.modalStrategy.hide();
        this.refs.modalProtocal.show();
    }
    /**
     * 关闭协议详情弹出框
     * @return {[type]}
     */
    handleCloseProtocal() {
        this.refs.modalProtocal.hide();
        this.refs.modalStrategy.show();
    }
    /**
     * 修改确认协议信息
     * @param  {[type]}
     * @return {[type]}
     */
    onProtocolChange(status) {
        this.subProtocolStatus = status;
    }
    /**
     * 确认解锁
     * @return {[type]}
     */
    onSubscribeClick(pmid) {
        let detail = this.props.detail;
        let isrevisit = detail.results[0].isrevisit;
        if(reVisit && isrevisit!=1){
            let modalContent = null;
            modalContent = <ModalReVisit 
              onSuccessHandler = { this.onSuccessHandler.bind(this) }
              isNewUser = { true }
              pmid = { pmid }/> 
            
            this.setState({
              modalProtocalContent : modalContent
            });

            this.refs.modalStrategy.hide();
            this.refs.modalProtocal.show();

            return;
        } else {
            this.props.onSubscribeClick();
            this.refs.modalStrategy.hide();
        }

    }
    //回访成功后的操作
    onSuccessHandler() {
        this.props.onSubscribeClick();
        this.refs.modalProtocal.hide();
    }
    /**
     * 关闭modal
     * @return {[type]}
     */
    onModalClose() {
        this.refs.modalStrategy.hide();
    }
    /**
     * 页面渲染
     * @return {[type]}
     */
    render() {

        let { detail } = this.props;
        return ( 
            <div>
                <div className = "strategy-lock card card-strategy text-center" >

                    <p> {this.props.noticeText}  </p> 
                    <p> 
                        {
                           detail.results[0].btnenable === "1"?
                            <button className = {"btn btn-strategy"}
                                href = "javascript:void(0);"
                                onClick = { this.handleUnlock.bind(this) }> 
                                    {this.props.btnText} 
                            </button>
                            :
                            <a className = {"btn btn-dark btn-strategy disabled"}
                                href = "javascript:void(0);"> 
                                不在解锁时间范围内 
                            </a> 
                        }
                    
                    </p>
                    <p> 

                        <small className = 'text-muted'> 
                            { this.props.unlockNum } 
                        </small>

                    </p>

                </div>

                <Modal ref = "modalStrategy"
                    backdrop = { this.state.modalBackdrop }
                    className = { this.state.modalClass } > 
                    { this.state.modalContent } 
                </Modal> 
                <Modal ref = "modalProtocal"
                    backdrop = { this.state.modalProtocalBackdrop }
                    className = { this.state.modalProtocalClass }> 
                    { this.state.modalProtocalContent } 
                </Modal> 
            </div>
        );
    }
}

export default UnlockBox;