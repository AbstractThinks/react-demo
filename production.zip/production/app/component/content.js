import React from 'react';

import {
  connect
} from 'react-redux';
import {
  Link,
  History
} from 'react-router';

import Menubar from '../component/menubar';

class Content extends React.Component {
  
  constructor() {
    super();
  }
  componentWillMount() {
    document.body.scrollTop = 0;     
  }
  getMessegeData() {
    let AJAX_STATUS = true;

  }
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {
    let { isMenubar, children, className, menuIndex } = this.props;
    return (
      <div>
        <div className={ className }>
          { children }
        </div>
        {
          isMenubar === true?
          <Menubar menuIndex = { menuIndex }/>
          :
          null
        }
      </div>
    );
  }
}

export default connect(state => ({
}), dispatch => ({

}))(Content);