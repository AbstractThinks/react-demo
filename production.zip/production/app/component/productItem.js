import React from 'react';
import { Link } from 'react-router';
import { productStatus,checkRiskLevel,reVisit } from '../config/common';
import Notify from '../common/notification';

import Modal from 'boron/ScaleModal';

import ModalProductSubscribe from '../component/modal/productsubscribe';
import ModalProductUnSubscribe from '../component/modal/productunsubscribe';
import ModalProductUnSubscribing from '../component/modal/productunsubscribing';

import ModalProtocolList from '../component/modal/protocollist';

import ModalRiskNotMatch from '../component/modal/risknotmatch';
import ModalReVisit from '../view/revisit';

import ModalProductDetail1 from '../component/modal/productdetail1';
import ModalProductDetail2 from '../component/modal/productdetail2';
import ModalProductDetail3 from '../component/modal/productdetail3';
import ModalProductDetail4 from '../component/modal/productdetail4';

import Protocal from './modal/protocol';
import ProductUse from './modal/protocalUse';
import ProtocolRisk from './modal/protocolrisk';

import {
    localStorageService
} from '../common/Storage';

class ProductItem extends React.Component {

  constructor() {
    super();

    this.showSubMessage = false;
    this.showUnSubMessage = false;
    this.btnEnable = true;

    this.state = {
      modalBackdrop : true,
      modalClass : "modal-container",
      modalContent : null,
      modalProtocalClass : "modal-container-full modal-protocal"
    };
  }

  static contextTypes = {
    router: React.PropTypes.object.isRequired
  }
  /**
   * 完成渲染新的props或者state后调用
   * @return {[type]}
   */
  componentDidUpdate(){
   let { pmid } = this.props;
      if (pmid) {
        let { sub_status = 0, unsub_status = 0, message = "" } = pmid;
        if (sub_status && sub_status !== 1 && this.showSubMessage) {
          Notify.makeNotify(message, 1.5);
          this.showSubMessage = false;
          if(sub_status === 3) {
            this.btnEnabled = true;
          }
        } else if (unsub_status && unsub_status !== 1 && this.showUnSubMessage) {
          Notify.makeNotify(message, 1.5);
          this.showUnSubMessage = false;
          if(unsub_status === 3) {
            this.btnEnabled = true;
          }
        }
      }
    
  }
  handleProductOperate(e){
    
    e.preventDefault();
    e.stopPropagation();
    if(this.btnEnabled) {

      let { productItem, userinfo } = this.props;
      let modalContent = null;
      //已签约
      if(productItem.status == productStatus.hasSubscribe && productItem.curstatus == "2"){
        modalContent = 
           <ModalProductUnSubscribe 
            productItem = { this.props.productItem }
            onSureClick = { this.onUnSubcribeClick.bind(this) }
            onCloseClick = { this.onModalClose.bind(this) } />
      }
      //退签中
      else if(productItem.status == productStatus.hasSubscribe && productItem.curstatus == "4"){
        modalContent = 
          <ModalProductUnSubscribing 
            onCloseClick = { this.onModalClose.bind(this) }/>
      }
      //未签约
      else{
        if(checkRiskLevel){
          let riskMatch = userinfo.clientrisklevel >= productItem.rinklevel ? true : false;
          if(!riskMatch) {
            modalContent = 
            <ModalRiskNotMatch 
              onCloseClick = { this.onModalClose.bind(this) } />;
            this.setState({
              modalBackdrop : true,
              modalClass : "modal-container",
              modalContent : modalContent
            });
            this.refs.modalProduct.show();
            return;
          }
        }
      
        this.subProtocolStatus = true;

         modalContent = 
          <ModalProductSubscribe 
            productItem = { this.props.productItem }
            onProtocolChange = { this.onProtocolChange.bind(this) }
            onProtocolModalOpen = {this.onProtocolModalOpen.bind(this)}
            onProtocolUseModalOpen = {this.onProtocolUseModalOpen.bind(this)}
            onProtocolRiskModalOpen = {this.onProtocolRiskModalOpen.bind(this)}
            onSureClick = { this.onSubscribeClick.bind(this) }
            onCloseClick = { this.onModalClose.bind(this) } /> 
      }

      this.setState({
        modalBackdrop : true,
        modalClass : "modal-container",
        modalContent : modalContent
      });

      this.refs.modalProduct.show();
    }
  }
  showProtocolList(e){
    
      e.preventDefault();
      e.stopPropagation();

      let { productItem } = this.props;

      let modalContent = null;

         modalContent = 
          <ModalProtocolList 
            productItem = { this.props.productItem }
            onProtocolModalOpen = {this.onProtocolModalOpen.bind(this)}
            onProtocolUseModalOpen = {this.onProtocolUseModalOpen.bind(this)}
            onProtocolRiskModalOpen = {this.onProtocolRiskModalOpen.bind(this)}
            onCloseClick = { this.onModalClose.bind(this) } /> 

      this.setState({
        modalBackdrop : true,
        modalClass : "modal-container",
        modalContent : modalContent
      });

      this.refs.modalProduct.show();
  }
  /**
   * 产品详情弹出框
   * @param  {[type]}
   * @return {[type]}
   */
  handleProductDetail(e){
    e.preventDefault();
    e.stopPropagation();

    let { productItem } = this.props;

    let modalContent = null;

    if (productItem.pmid === '1588015') {
      modalContent = <ModalProductDetail1 
        productItem = { this.props.productItem }
        onCloseClick = { this.onModalClose.bind(this) }/> 
    }else if(productItem.pmid === '1588016'){
      modalContent = <ModalProductDetail2 
        productItem = { this.props.productItem }
        onCloseClick = { this.onModalClose.bind(this) }/> 
    }else if(productItem.pmid === '1588020'){
      modalContent = <ModalProductDetail3 
        productItem = { this.props.productItem }
        onCloseClick = { this.onModalClose.bind(this) }/> 
    }else if(productItem.pmid === '1588021'){
      modalContent = <ModalProductDetail4 
        productItem = { this.props.productItem }
        onCloseClick = { this.onModalClose.bind(this) }/> 
    }

    this.setState({
      modalBackdrop : false,
      modalClass : "modal-container-full",
      modalContent : modalContent
    });

    this.refs.modalProduct.show();
  }
  /**
   * 退签
   * @return {[type]}
   */
  onUnSubcribeClick(){
    let { productItem,  productUnSubHandle } = this.props;
    productUnSubHandle(productItem);
    this.refs.modalProduct.hide();
    this.showUnSubMessage = true;
  }
  /**
   * 签约
   * @return {[type]}
   */
  onSubscribeClick(){
    if(this.subProtocolStatus === true){
      if(reVisit){
        this.sureVisitClick();
        return;
      }else {
        this.sureSubscribe();
      }
    }
  }
  /**
   * 协议确认修改
   * @param  {[type]}
   * @return {[type]}
   */
  onProtocolChange(status){
     this.subProtocolStatus = status;
  }
  /**
   * 关闭弹出框
   * @return {[type]}
   */
  onModalClose(){
    this.refs.modalProduct.hide();
  }
  /**
   * 打开协议弹出框
   * @return {[type]}
   */
  onProtocolModalOpen({showDate=true, btnText="确认并同意以上规则"}={}) {
     let {userinfo} = this.props;
     let modalContent = < Protocal 
        onCloseClick = {
          this.onProtocolModalClose.bind(this)
        } 
        userinfo = { userinfo } 
        showDate = { 
          showDate
        }
        btnText = { 
          btnText
        }/> 
        this.setState({
            modalProtocalContent: modalContent
        });
        this.refs.modalProduct.hide();
        this.refs.modalProtocal.show();
  }
  /**
   * 打开协议弹出框
   * @return {[type]}
   */
  onProtocolUseModalOpen({showDate=true, btnText="确认并同意以上规则"}={}) {
     let {userinfo} = this.props;
     let modalContent = < ProductUse 
                          onCloseClick = {
                            this.onProtocolModalClose.bind(this)
                          } 
                          userinfo = { userinfo } 
                          showDate = { showDate }
                          btnText = { btnText }/> 
        this.setState({
            modalProtocalContent: modalContent
        });
        this.refs.modalProduct.hide();
        this.refs.modalProtocal.show();
  }
  /**
   * 打开协议弹出框
   * @return {[type]}
   */
  onProtocolRiskModalOpen({showDate=true, btnText="确认并同意以上规则"}={}) {
     let {userinfo} = this.props;
     let modalContent = < ProtocolRisk 
                          onCloseClick = {
                            this.onProtocolModalClose.bind(this)
                          } 
                          userinfo = { userinfo } 
                          showDate = { showDate }
                          btnText = { btnText }/> 
        this.setState({
            modalProtocalContent: modalContent
        });
        this.refs.modalProduct.hide();
        this.refs.modalProtocal.show();
  }
  /**
    * 关闭协议弹出框
    * @return {[type]}
    */
  onProtocolModalClose() {
     this.refs.modalProtocal.hide();
     this.refs.modalProduct.show();
  }
  /**
    * 跳转到客户回访页
    * @return {[type]}
    */
  sureVisitClick() {
    let modalContent = null;
    let { productItem } = this.props;
    modalContent = <ModalReVisit 
      onSuccessHandler = { this.onSuccessHandler.bind(this) }
      isNewUser = { true }
      pmid = {productItem.pmid}/> 
    
    this.setState({
      modalProtocalContent : modalContent
    });

    this.refs.modalProduct.hide();
    this.refs.modalProtocal.show();
  }
  //回访成功后的操作
  onSuccessHandler() {
    this.sureSubscribe();
    this.refs.modalProtocal.hide();
  }
  /**
   * 确认签约
   * @return {[type]}
   */
  sureSubscribe(){
    let { productItem,  productSubHandle } = this.props;
    productSubHandle(productItem);
    this.refs.modalProduct.hide();
    this.showSubMessage = true;
  }
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {
    let { productItem, index, length } = this.props;
    let currentUserSubCount = localStorageService.get("subcount");
    let subStatus = "unSubscribe";
    if(productItem.subscribecount) {
      if(productItem.status == productStatus.hasSubscribe && productItem.curstatus == "2") {
        subStatus = "hasSubscribe";
      } else if(productItem.status == productStatus.hasSubscribe && productItem.curstatus == "4") {
        subStatus = "preUnsubscribe";
      }else {
        subStatus = "unSubscribe";
      }
      if(subStatus === "hasSubscribe" && this.showUnSubMessage) {
        this.btnEnabled = false;
      } else if(subStatus === "unSubscribe" && this.showSubMessage){
        this.btnEnabled = false;
      } else {
        this.btnEnabled = true;
      }
    }
    return (
        <div>
            <div className="card animated zoomIn">
                {
                  productItem.pmid==="1588015" || productItem.pmid==="1588016" ?
                  <div className="card-wrap product-content" 
                  onClick = { this.handleProductDetail.bind(this) }>
                    <img className="card-bg" src={ productItem.url }/>
                    <div className="card-title"></div>
                    <div className={productItem.subscribecount?"card-content":"card-content card-content-strategy"}>
                        <h3>{ productItem.name }</h3>
                        <p>{`${ productItem.subscribecount } 人正在使用`}</p>
                    </div>
                    <div className="card-op">
                      <a className={ 
                        subStatus === "hasSubscribe" ? 
                          "btn btn-bordered btn-unsubscribe" 
                            : subStatus === "preUnsubscribe" ? 
                            "btn btn-bordered btn-preunsubscribe" 
                              : 
                              "btn btn-bordered btn-subscribe"
                          }
                        href="javascript:void(0);"
                        onClick = { this.handleProductOperate.bind(this) }>
                        {
                          subStatus === "hasSubscribe" ?
                          `已签约`
                          :
                          subStatus === "preUnsubscribe" ?  
                          `退签中`
                          :
                          `立即签约`
                        }
                      </a>
                    </div>
                  </div>
                  :
                  <div className="card-wrap product-content" 
                  onClick = { this.handleProductDetail.bind(this) }>
                    <img className="card-bg" src={ productItem.url }/>
                    <div className="card-title"></div>
                    <div className={productItem.subscribecount?"card-content":"card-content card-content-strategy"}>
                        <h3>{ productItem.name }</h3>
                    </div>
                    
                    <div className="card-op">
                      <Link className="btn btn-bordered product-strategy-btn" 
                        href="javascript:void(0);" to={ productItem.link }>
                        { productItem.linkname }
                      </Link>
                    </div>
                  </div>
                }
                
            </div>
            {
              index === length - 1 && currentUserSubCount > 0 ? 
              <div className="text-center">
                <div className="blank10"/>
                <span 
                   className="text-muted copyright-underline"
                   onClick={this.showProtocolList.bind(this)}>
                  赢财富产品协议
                </span>
              </div> 
              : 
              null
            }
            <Modal ref="modalProduct" 
              backdrop = { this.state.modalBa}
              className= { this.state.modalClass }>
                { this.state.modalContent }
            </Modal>
            < Modal ref = "modalProtocal"
                backdrop = {
                    this.state.modalProtocalBackdrop
                }
                className = {
                    this.state.modalProtocalClass
                } > {
                    this.state.modalProtocalContent
                } 
            < /Modal> 
        </div>
    );
  }
}

ProductItem.propTypes = {
  productItem : React.PropTypes.object
}

ProductItem.defaultProps = {
  productItem : null
}

export default ProductItem;
