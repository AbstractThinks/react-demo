import React from 'react';

class StrategyFooter extends React.Component {
    constructor(props) {
        super(props);
        this.displayName = 'StrategyFooter';
    }
    render() {
        return (
        	<div className="text-center warn-strategy">
                <p>仅供参考，不构成具体投资建议</p>
                <p className="text-danger">股市有风险  投资需谨慎</p>
                <p><small className="text-muted">华西证券股份有限公司</small></p>
            </div>
        )
    }
}

export default StrategyFooter;
