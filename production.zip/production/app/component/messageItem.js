import React from 'react';

import { Link } from 'react-router';
import * as apis from '../config/api';

class MessageItem extends React.Component {

  constructor() {
    super();
  }
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {

    let { messageItem } = this.props;
    let createtime = messageItem.createtime.substring(0, messageItem.createtime.length-3);
    let stockInfoApi = String.format(apis.stock_info_api, messageItem.stockcode, messageItem.stockarea);
    return (
        <div>
            <div className="blank30"></div>
            <div className="card card-message animated zoomIn">
                <div className="card-header">
                    { messageItem.name }
                    <small className="pull-right">
                        { createtime }
                    </small>
                </div>

                <Link to={`MessageDetail`} query={{id:messageItem.id, type:messageItem.type}}
                  className = "link-normal">

                  <div className="card-block">
                      <p className="card-text" dangerouslySetInnerHTML={{__html: messageItem.content}}></p>
                  </div>
                    <div className="card-footer text-muted">
                        <p>仅供参考，不构成具体投资建议</p>
                        <p>股市有风险  投资需谨慎</p>
                    </div>
                </Link>
                {
                  messageItem.stockcode!=='' ? 
                    <div className="card-op">
                        <a href={stockInfoApi} >
                            行情/交易
                        </a>
                    </div> 
                    : 
                    null
                }

                <Link to={`MessageDetail`} query={{id:messageItem.id, type:messageItem.type}}
                  className="link-normal">


                  <div className="card-extra">
                      <span className="card-extra-title">详情</span>
                      <span className="card-extra-popup">&gt;</span>
                  </div>

                </Link>
            </div>
        </div>
    );
  }
}

MessageItem.propTypes = {
  messageItem : React.PropTypes.object
}

MessageItem.defaultProps = {
  messageItem : null
}

export default MessageItem;
