import React from 'react';

class StrategyProduct extends React.Component {
    constructor(props) {
        super(props);
        this.displayName = 'StrategyProduct';
    }
    render() {
        return <div>StrategyProduct</div>;
    }
}

export default StrategyProduct;
