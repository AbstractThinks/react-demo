// import React from 'react';
// 
// import { Link, History } from 'react-router';
// import ReactCSSTransitionGroup from 'react-addons-css-transition-group';

// function Container ({ children }) {
//   return (
//     <ReactCSSTransitionGroup
// 	      component="div"
// 	      transitionName="main"
// 	      transitionEnterTimeout={500}
// 	      transitionLeaveTimeout={500} >
// 	      {
// 	      	React.cloneElement(children, {
// 		        key: children.props.location.pathname
// 		    })
// 	      }
// 	</ReactCSSTransitionGroup>
//   )
// }

// Container.propTypes = {
//   children: React.PropTypes.element
// }

// export default Container