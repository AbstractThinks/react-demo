import React from 'react';
import {
	Link
} from 'react-router';

class CardItem extends React.Component {
	constructor(props) {
		super(props);
	}

	/**
	 * 页面渲染
	 * @return {[type]}
	 */
	render() {
		let { headLeft, headRight, contentBody, bottomLeft, bottomRemark, bottomRemarkClass,  bottomRight } = this.props;
		return (

			<div>
			<div className = "blank5" > </div> 
			<div className = "blank10" > </div> 
				<div className = "card card-message animated zoomIn card-list-strategy" >
					
					<div className = "card-header" >
						<div className = "card-header-title">
							<p>{ headLeft }</p>
						</div> 
						 
						<small className = "pull-right" > 
							{ headRight } 
						</small>
					</div>

					<div className = "card-block" >
						<p 
							className = { bottomLeft || bottomRight ? "card-text" : "card-text-nobottom" }
							dangerouslySetInnerHTML = {{__html: contentBody}} > 

						</p> 
						{ 
							bottomLeft || bottomRight ? 
								<div className = "card-footer text-muted product-strategy-check">
									{ bottomLeft } 
									<span className = { bottomRemarkClass }> { bottomRemark }</span>
									<span className = "pull-right">
										{ bottomRight }
									</span> 
								</div>
								: 
								null

						}

					</div>

				</div>
			</div>

		)
	}
}

export default CardItem;