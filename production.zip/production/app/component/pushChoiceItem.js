import React from 'react';

class PushChoiceItem extends React.Component {

  constructor() {
    super();
    this.state = {
      isChoiced : false
    }
  }
  componentWillMount() {
    let { isChoiced } = this.props;
    this.state = {
      isChoiced : isChoiced
    } 
  }
  /**
   * @param  {[type]}
   * @return {[type]}
   */
  _preventDefualtEvent(event) {
    event.stopPropagation();
  }
  handleClick() {
    let { isMustChoice } = this.props;
    if(!isMustChoice) {
      this.setState({
        isChoiced : !this.state.isChoiced
      });
    }
  }
  
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {
    let { index, isMustChoice, text } = this.props;
    return(
        <div className="push-choice" onClick={ this.handleClick.bind(this) }>
          {
            isMustChoice || this.state.isChoiced ? 
              <span className="push-choice-img-choiced"><i className="ion-ios-circle-filled"></i></span>
              : 
              <span className="push-choice-img"><i className="ion-ios-circle-outline"></i></span>
          }
          <span className="push-choice-text">{text}</span>
        </div>
    )
  }
}

export default PushChoiceItem;
