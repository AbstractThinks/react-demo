import React from 'react';

class ShadowFollowFooter extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
        	<div className="text-center warn-strategy">
                <p><small className="text-muted">-华西证券股份有限公司-</small></p>
            </div>
        )
    }
}

export default ShadowFollowFooter;
