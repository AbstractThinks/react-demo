import React from 'react';
import {
    formatDate
} from '../../common/formater';
class ProtocolSF extends React.Component {
    constructor(props) {
        super(props);
    }
    /**
     * 真实的DOM被渲染出来后调用
     * @return {[type]}
     */
	componentDidMount(){
		document.getElementsByTagName('body')[0].style.overflow = 'hidden';
	}
	/**
     * 组件被移除之前被调用
     * @return {[type]}
     */
	
	componentWillUnmount(){
    	document.getElementsByTagName('body')[0].style.overflow = 'auto';
    }
	/**
	 * 关闭modal
	 * @return {[type]}
	 */
    handleClose(){
    	let { onCloseClick }  = this.props;
    	onCloseClick();
    }
    
    render() {
    	let {userinfo,showDate,btnText} = this.props;
    	let date = new Date();
    	let currentDate = formatDate(date, "yyyy年MM月dd日");
        return (
        	<div>
        		<div className={'modal-content'}>
	        		<div className={'popup protocol'}> 
		        		<div className="popup-content"> 
		        			<h4>“赢财富如影随形” <br/> 投资咨询产品服务协议 </h4>
		        			<h5>甲方： {userinfo.name}</h5> 
							<h5>乙方： 华西证券股份有限公司 </h5>  
							<div className="blank10"></div> 
							<p>鉴于，甲方同意购买乙方提供的“赢财富如影随行”投资咨询产品服务（以下简称“该产品或本产品”），为明确双方的权利和义务，甲方已充分阅读了解并同意以下各项条款：</p> 
							<h5>1、产品服务内容 < /h5> 
							<p>该产品项下各套餐以具体介绍内容为准。</p> 
							<h5>2、产品的计费</h5 >
							<p><b>2.1 计费单价：</b>该产品的各项套餐按【包月】进行计费。具体单价以套餐的标价为准。套餐中的研究报告单独按篇收费，解锁前提示收费标准。<b>乙方有权根据业务的发展情况对各套餐的单价进行调整，并在乙方微信公众号或交易软件等平台通知甲方。甲方若对调整后的单价有异议，可以在单价调整生效前单方面退订服务，终止本协议，甲方未及时退订的，视为接受乙方对各套餐单价进行的调整。</b></p> 
							<p><b>2.2 计费区间：</b>乙方从甲方订阅套餐的下一交易日作为第一个计费日开始根据套餐的单价按月计费，计费日为第一个计费日开始直至退订套餐生效日期间每月的对日，如当月没有计费日对日的，则当月最后一日为计费日。甲方于当日17：00之前退订的，退订当日为退订套餐生效日，甲方于当日17：00之后退订的，退订当日的下一个交易日为退订套餐生效日。计费日按整月进行计费，如因甲方退订等原因导致最后一个计费日后实际服务期限不足一个月的，所计费用不予扣除，仍按整月进行计费。</p> 
							<h5>3、扣费方式</h5 > 
							<p>3.1 乙方通过提高甲方普通证券账户和信用账户的交易佣金的方式收取本协议第2条约定的费用（以下简称“服务费用”）。乙方有权将甲方的交易佣金在现有的基础上提高（最高提高至3‰（含）），已扣取的提高佣金部分视为甲方支付的服务费用，直至服务费用扣取完毕，则恢复甲方的交易佣金至原有比例。</p> 
							<p>3.2 上条所述的交易佣金包括但不限于甲方进行股票、ETF、LOF、场内基金的交易。</p> 
							<h5>4、限制措施</h5> 
							<p>4.1 当甲方存在未支付的服务费用时，乙方有权以未扣除服务费用为上限，限制甲方普通证券账户以及信用账户的资金转出。</p> 
							<p>4.2 当甲方未支付的服务费用达到100元时，乙方有权单方面暂停或终止向甲方提供已订阅的产品服务。</p> 
							<p>4.3 乙方依据本协议的约定单方暂停或终止向甲方提供服务后，仍有权继续按第3条约定的方式向甲方收取未支付的服务费用。</p> 
							<h5>5、其他条款</h5 > 
							<p>5.1 本协议作为甲方同乙方已签署的《华西证券股份有限公司证券投资咨询产品使用协议》的补充协议，同原有协议具有同等的效力，本协议未约定的内容，以《华西证券股份有限公司证券投资咨询产品使用协议》的约定为准。</p> 
							<p>5.2 本协议双方以电子版或其他方式的形式进行签署。当甲方按照乙方微信公众号或交易软件等平台相应提示，对本协议的内容点击并确认后，则视为甲方已对本协议进行充分阅读了解，同意并签署本协议，本协议开始生效。</p> 
							<div className="blank5"></div> 
							{
								showDate ? 
									<p className = "text-right"> 日期：{currentDate}</p> 
									: 
									null
							}
							<a className="btn btn-block btn-dark btn-protocol" onClick = {this.handleClose.bind(this)}>确认并同意以上规则</a>
						</div>
						
					</div>
				</div>
        		
        	</div>
        	
        );
    }
}

export default ProtocolSF;







