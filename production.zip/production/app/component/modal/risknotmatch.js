import React from 'react';


class ModalRiskNotMatch extends React.Component {

  constructor() {
    super();
  }
  
  handleSure(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }

  render() {
    return (
        <div>
          <h2 className = {'modal-header'}>
            系统提示
          </h2>
          <div className = {'modal-content'}>
            <p>
              您的风险承受能力等级和当前产品风险等级不匹配，不能签约该产品。
            </p>
            <p className="text-remark">
              <small className="text-danger">
                注：您可以通过在手机或者PC上的“华彩人生一点通”软件进行风险承受能力等级的重新测评。
              </small>
            </p>
          </div>
          <div className={'modal-footer'}>
            <button onClick={ this.handleSure.bind(this) } className="btn-block">确定</button>
          </div>
        </div>
    );
  }
}

ModalRiskNotMatch.propTypes = {
  
}

ModalRiskNotMatch.defaultProps = {
  
}

export default ModalRiskNotMatch;
