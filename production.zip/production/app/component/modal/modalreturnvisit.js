import React from 'react';


class ModalReturnVisit extends React.Component {

  constructor() {
    super();
  }
  
  handleSure(){
    let { onSureVisitClick }  = this.props;
    onSureVisitClick();
  }

  render() {
    return (
        <div>
          <h2 className = {'modal-header'}>
            系统提示
          </h2>
          <div className = {'modal-content text-center'}>
            您需要填写回访问卷，才能进行签约。
          </div>
          <div className={'modal-footer'}>
            <button onClick={ this.handleSure.bind(this) } className="btn-block">参与回访</button>
          </div>
        </div>
    );
  }
}

ModalReturnVisit.propTypes = {
  
}

ModalReturnVisit.defaultProps = {
  
}

export default ModalReturnVisit;
