import React from 'react';
import {
    formatDate
} from '../../common/formater';
class Protocol extends React.Component {
    constructor(props) {
        super(props);
        this.displayName = 'Protocol';
    }
    /**
     * 真实的DOM被渲染出来后调用
     * @return {[type]}
     */
	componentDidMount(){
		document.getElementsByTagName('body')[0].style.overflow = 'hidden';
	}
	/**
     * 组件被移除之前被调用
     * @return {[type]}
     */
	
	componentWillUnmount(){
    	document.getElementsByTagName('body')[0].style.overflow = 'auto';
    }
	/**
	 * 关闭modal
	 * @return {[type]}
	 */
    handleClose(){
    	let { onCloseClick }  = this.props;
    	onCloseClick();
    }
    
    render() {
    	let {userinfo,showDate,btnText} = this.props;
    	let date = new Date();
    	let currentDate = formatDate(date, "yyyy年MM月dd日");
        return (
        	<div>
        		<div className={'modal-content'}>
	        		<div className={'popup protocol'}> 
		        		<div className="popup-content"> 
		        			<h4> “赢财富•价值型/热点型” <br/> 证券投资咨询产品使用协议 </h4>
		        			<h5> 甲方： {userinfo.name}</h5> 
							<h5> 乙方： 华西证券股份有限公司 </h5>  
							<div className="blank10"></div> 
		        			<p>鉴于，甲方同意购买乙方提供的“赢财富•价值型/热点型”证券投资咨询产品服务（以下简称“该产品或本产品”），为明确双方的权利和义务，甲方已充分阅读了解并同意以下各项条款：</p> 
							<h5>1.产品服务内容</h5> 
							<p> 本产品服务内容包括操作策略送达、持股跟踪服务、重大事项解读。</p> 
							<h5>2.产品仓位控制</h5> 
							<p> 甲方同意按照乙方仓位标准（单只标的仓位≤总仓位25%）进行仓位控制。</p> 
							<h5>3.产品止损原则</h5> 
							<p> 甲方同意按照乙方止损原则（个股亏损超过-20%强行止损）进行控制。</p> 
							<h5>4.客户风险等级</h5> 
							<p>本产品适用的客户风险等级为中高风险承受能力等级、高风险承受能力等级，甲方确认符合该条件。</p> 
							<h5>5.产品的计费和扣费</h5> 
							<p><b>5.1 计费标的</b>：乙方只对本产品推荐的标的向甲方定项收取增值佣金；</p> 
							<p><b>5.2 计费及扣费规则:</b></p> 
							<p>5.2.1 甲方买入本产品推荐标的时，佣金率为原佣金率；</p> 
							<p>5.2.2 甲方卖出本产品推荐标的时，根据甲方买入本产品推荐标的时间，按如下规则进行差异化收取佣金：</p> 
							<p>（1）甲方在产品被乙方调入标的前，已买入产品推荐标的，客户卖出该标的时，该笔交易佣金按原佣金率收取。</p> 
							<p>（2）甲方在产品被乙方调入标的后、未调出标的前，买入该产品推荐标的，对甲方卖出该标的时按如下规则收取产品服务费用：</p> 
							<p>甲方在产品被乙方调出标的前，卖出该标的，则该笔交易佣金按3‰收取。</p>
							<p>产品发出止盈（产品调出价格区间下限＞产品调入价格区间上限）调出指令后，甲方在20个交易日内卖出推荐标的，该笔交易佣金按3‰收取；甲方超出20个交易日卖出推荐标的，则该笔交易佣金按原佣金率收取。</p>
							<p>产品发出止损（产品调出价格区间下限≦产品调入价格区间上限）调出指令后，甲方卖出推荐标的，该笔交易佣金按原佣金率收取。</p> 
							<p>（3）甲方在产品调出推荐标的后，买入推荐标的的，甲方再卖出该标的时的佣金按原佣金率收取。</p>
							<p>5.2.3 非本产品推荐标的的买卖的佣金，按甲方原佣金率收取。</p>
							<p><b>5.3 计费调整：</b>乙方有权根据业务的发展情况对各套餐的单价进行调整，并在乙方微信公众号或交易软件等平台通知甲方。甲方若对调整后的单价有异议，可以在单价调整生效前单方面退订服务，终止本协议，甲方未及时退订的，视为接受乙方对各套餐单价进行的调整。</p> 
							<h5>6.产品周期</h5>
							<p>热点型1个月左右，价值型3个月左右。</p> 
							<h5>7.其他条款</h5> 
							<p>7.1 本协议作为甲方同乙方已签署的《华西证券股份有限公司证券投资咨询产品使用协议》的补充协议，同原有协议具有同等的效力，本协议未约定的内容，仍以《华西证券股份有限公司证券投资咨询产品使用协议》的约定为准。</p> 
							<p>7.2 本协议双方以电子版的形式进行签署。当甲方按照乙方微信公众号或交易软件等平台相应提示，对本协议的内容点击并确认后，则视为甲方已对本协议进行充分阅读了解，并签署，开始生效。</p> 
							<div className="blank5"></div> 
							{
								showDate ? 
									<p className = "text-right"> 日期：{currentDate}</p> 
									: 
									null
							}
							<a className="btn btn-block btn-dark btn-protocol" onClick = {this.handleClose.bind(this)}>{btnText}</a>
						</div>
						
					</div>
				</div>
        		
        	</div>
        	
        );
    }
}

export default Protocol;
