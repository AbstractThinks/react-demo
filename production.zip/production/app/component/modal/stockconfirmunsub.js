import React from 'react';


class ModalStockConfirmUnsub extends React.Component {

  constructor() {
    super();
  }

  handleSure(){
    let { onSureClick }  = this.props;
    onSureClick();
  }

  handleClose(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }

  render() {
    return (
        <div>
            <h2 className = {'modal-header'}>
              你确定退订该服务？
            </h2>
            <div className = {'modal-content'}>
              <p>
                退订该服务后，你将不再收到该服务的任何推送，请知晓。
              </p>
            </div>
            <div className={'modal-footer'}>
              <button onClick={ this.handleSure.bind(this) }>确定</button>
              <button onClick={ this.handleClose.bind(this) }>取消</button>
            </div>
        </div>
    );
  }
}

ModalStockConfirmUnsub.propTypes = {
  
}

ModalStockConfirmUnsub.defaultProps = {
  
}

export default ModalStockConfirmUnsub;
