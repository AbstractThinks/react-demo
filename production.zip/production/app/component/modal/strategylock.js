import React from 'react';
import Modal from 'boron/ScaleModal';

class StrategyLock extends React.Component {
    constructor(props) {
        super(props);
        this.displayName = 'StrategyLock';
        this.state = {
	      protocolStatus : true,
	      tipSureDanger : false,
	      modalBackdrop : false,
	      modalClass : "modal-container-full",
	      modalContent : null

	    };
    }
    /**
     * 确认协议信息修改
     * @return {[type]}
     */
    handleProtocolChange(){
    	let { onProtocolChange } = this.props;
	    let currentStatus = !this.state.protocolStatus;
	    this.setState({
	      protocolStatus:currentStatus
	    });
	    onProtocolChange(currentStatus);
	    if (currentStatus) {
	       this.setState({tipSureDanger:false});
	    }
    }
    /**
     * 确认
     * @return {[type]}
     */
    handleSure(){
    	let { onSureClick }  = this.props;
	    if (this.state.protocolStatus) {
	      onSureClick();
	    } else {
	      this.setState({tipSureDanger:true});
	    }
    }
    /**
     * 关闭modal
     * @return {[type]}
     */
    handleClose(){
    	let { onCloseClick }  = this.props;
    	onCloseClick();
    }
    /**
     * 打开协议modal
     * @return {[type]}
     */
    handleOpenProtocal(type){
     let { onOpenProtocal }  = this.props;
     onOpenProtocal({protocolType: type});    
    }
    /**
     * 页面渲染
     * @return {[type]}
     */
    render() {
    	let { productStrategyDetail } = this.props;
        return (
        	<div className='strategy-modal'>
	            <h2 className = {'modal-header'}>
	                系统提示
	            </h2>
	            <div className = {'modal-content'}>
	                <p>
	                  佣金收取规则：{productStrategyDetail.results[0].proddesc}
	                </p>
	                <p className="text-remark">
	                  <input 
	                    type="checkbox" 
	                    className="check-protocol" 
	                    checked={this.state.protocolStatus}
	                    onChange = { this.handleProtocolChange.bind(this) }/>
	                  <small>
	                    &nbsp;我已阅读并同意
	                  </small>
	                  <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocal.bind(this, "use")}>
	                    《华西证券股份有限公司证券投资咨询产品使用协议》
	                  </a>
	                  &nbsp;<small>、</small>&nbsp;
	                  <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocal.bind(this, "st")}>
	                    《“赢财富•热点追击”证券投资咨询产品服务协议》
	                  </a>
	                  &nbsp;<small>及</small>&nbsp;
	                  <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocal.bind(this, "risk")}>
	                    《“赢财富”风险揭示》
	                  </a>
	                </p>
	                <p ref="tipSureDanger" className={this.state.tipSureDanger?"text-danger":"hide"}>
	                  请先确认阅读并同意
	                </p>
	            </div>
	            <div className={'modal-footer'}>
	              <button onClick={ this.handleSure.bind(this) }>确定</button>
	              <button onClick={ this.handleClose.bind(this) }>取消</button>
	            </div>
	        </div>
        )
    }
}

export default StrategyLock;
