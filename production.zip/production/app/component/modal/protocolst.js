import React from 'react';
import {
    formatDate
} from '../../common/formater';
class ProtocolST extends React.Component {
    constructor(props) {
        super(props);
        this.displayName = 'Protocol';
    }
    /**
     * 真实的DOM被渲染出来后调用
     * @return {[type]}
     */
	componentDidMount(){
		document.getElementsByTagName('body')[0].style.overflow = 'hidden';
	}
	/**
     * 组件被移除之前被调用
     * @return {[type]}
     */
	
	componentWillUnmount(){
    	document.getElementsByTagName('body')[0].style.overflow = 'auto';
    }
	/**
	 * 关闭modal
	 * @return {[type]}
	 */
    handleClose(){
    	let { onCloseClick }  = this.props;
    	onCloseClick();
    }
    
    render() {
    	let {userinfo,showDate,btnText} = this.props;
    	let date = new Date();
    	let currentDate = formatDate(date, "yyyy年MM月dd日");
        return (
        	<div>
        		<div className={'modal-content'}>
	        		<div className={'popup protocol'}> 
		        		<div className="popup-content"> 
		        			<h4> “赢财富•热点追击” <br/> 证券投资咨询产品使用协议 </h4>
		        			<h5> 甲方： {userinfo.name}</h5> 
							<h5> 乙方： 华西证券股份有限公司 </h5>  
							<div className="blank10"></div> 
		        			<p>鉴于，甲方同意购买乙方提供的“赢财富•热点追击”证券投资咨询产品服务（以下简称“该产品或本产品”），为明确双方的权利和义务，甲方已充分阅读了解并同意以下各项条款：</p> 
							<h5>1.产品服务内容</h5> 
							<p> 本产品根据市场情况及板块走势，及时盘中指导，注重波段指导等服务。</p> 
							<h5>2.产品仓位控制</h5> 
							<p> 甲方同意按照乙方仓位标准（单只标的仓位≤总仓位20%，整个板块重点关注标的仓位≤总仓位50%）进行仓位控制。</p> 
							<h5>3.产品止损原则</h5> 
							<p> 甲方同意按照乙方止损原则（个股亏损超过-20%强行止损）进行控制。</p> 
							<h5>4.客户风险等级</h5> 
							<p> 本产品适用的客户风险等级为中高风险承受能力等级、高风险承受能力等级，甲方确认符合该条件。</p> 
							<h5>5.产品的计费和扣费</h5> 
							<p><b>5.1 计费标的</b>：只对本产品推荐的标的定项收取增值佣金；</p> 
							<p><b>5.2 计费及扣费规则:</b>从甲方订阅该产品的T+1日至服务完结当日，对本产品推荐的标的买卖按3‰佣金率收取。</p> 
							<p><b>5.3 计费调整：</b>乙方有权根据业务的发展情况对各套餐的单价进行调整，并在乙方微信公众号或交易软件等平台通知甲方。甲方若对调整后的单价有异议，可以在单价调整生效前单方面退订服务，终止本协议，甲方未及时退订的，视为接受乙方对各套餐单价进行的调整。</p> 
							<h5>6.产品周期</h5>
							<p>从订阅的T+1日至服务完结当日。</p> 
							<h5>7.其他条款</h5>  
							<p>7.1 本协议作为甲方同乙方已签署的《华西证券股份有限公司证券投资咨询产品使用协议》的补充协议，同原有协议具有同等的效力，本协议未约定的内容，仍以《华西证券股份有限公司证券投资咨询产品使用协议》的约定为准。</p> 
							<p>7.2 本协议双方以电子版的形式进行签署。当甲方按照乙方微信公众号或交易软件等平台相应提示，对本协议的内容点击并确认后，则视为甲方已对本协议进行充分阅读了解，并签署，开始生效。</p> 
							<div className="blank5"></div> 
							{
								showDate ? 
									<p className = "text-right"> 日期：{currentDate}</p> 
									: 
									null
							}
							<a className="btn btn-block btn-dark btn-protocol" onClick = {this.handleClose.bind(this)}>{btnText}</a>
						</div>
						
					</div>
				</div>
        		
        	</div>
        	
        );
    }
}

export default ProtocolST;
