import React from 'react';
import ServerItem from '../serverItem';
import PushChoiceItem from '../pushChoiceItem';
import StockItem from '../stockItem';
class StockSubscribe extends React.Component {
    constructor(props) {
        super(props);
        this.pkgIndex = 0;
        this.enableClick = false;
        this.state = {
	      protocolStatus : true,
	      tipSureDanger : false,
	      active : 0,
	      fee : 0,
        isSendSMS : false

	    };
    }

    componentDidMount() {
        let { stockservers } = this.props;
        if(stockservers && stockservers.length > 0) {
        	this.setState({
            active: this.props.stockservers[0].id,
            fee: parseFloat(this.props.stockservers[0].feevalue)
        	});
          this.pkgIndex = 0;
          this.enableClick = true;
        }
    }
    /**
     * 确认协议信息修改
     * @return {[type]}
     */
    handleProtocolChange(){
    	let { onProtocolChange } = this.props;
	    let currentStatus = !this.state.protocolStatus;
	    this.setState({
	      protocolStatus:currentStatus
	    });
	    onProtocolChange(currentStatus);
	    if (currentStatus) {
	       this.setState({tipSureDanger:false});
	    }
    }
    /**
     * 确认
     * @return {[type]}
     */
    handleSure(){
    	let { onSureClick }  = this.props;
	    if (this.state.protocolStatus && this.enableClick) {
        this.enableClick = false;
	      onSureClick(this.state.active, this.state.isSendSMS ? 1 : 0);
	    } 
      if (!this.state.protocolStatus) {
	      this.setState({tipSureDanger:true});
	    }
    }
    /**
     * 关闭modal
     * @return {[type]}
     */
    handleClose(){
    	let { onCloseClick }  = this.props;
    	onCloseClick();
    }
    /**
     * 打开协议modal
     * @return {[type]}
     */
    handleOpenProtocal(type){
     let { onOpenProtocal }  = this.props;
     onOpenProtocal({protocolType: type});    
    }

    handleChoice(i) {
      this.setState(
    		{
    			active: this.props.stockservers[i].id,
          fee: this.state.isSendSMS ? parseFloat(this.props.stockservers[i].feevalue) + parseFloat(this.props.stockservers[i].smsvalue) : parseFloat(this.props.stockservers[i].feevalue)
    		});
      this.pkgIndex = i;
    }
    handlePushChoice(i) {
      this.setState(
        {
          isSendSMS: !this.state.isSendSMS,
          fee: !this.state.isSendSMS ? parseFloat(this.props.stockservers[this.pkgIndex].feevalue) + parseFloat(this.props.stockservers[this.pkgIndex].smsvalue) : parseFloat(this.props.stockservers[this.pkgIndex].feevalue)
        });
    }

    renderStockServer(serverItem, i, length){
    	return (
    		<li key = { i } onClick = { this.handleChoice.bind(this, i) }>
          		<ServerItem 
          			serverItem = { serverItem } 
          			index = { serverItem.id } 
          			active = { this.state.active }
                single = { length === 1 ? true : false } 
                opt = { "sub" } />
          	</li>
    	)
    }

    renderStockServers(){
        let { stockservers } = this.props;
        if (stockservers && stockservers.length > 0) {
            return (
                    <ul className = {stockservers.length === 1 ? "single-server-item-chioces" : "server-item-chioces"}>
                        {
                            stockservers.map((serverItem, i) =>
                                
                                this.renderStockServer(serverItem, i, stockservers.length)
                                
                            )
                        }   
                        <div></div>
                    </ul>
                );
            
        }else {
            return null
        }
    }

    /**
     * 页面渲染
     * @return {[type]}
     */
    render() {
    	let {stockservers} = this.props;
        return (
        	<div className='strategy-modal stocksubscribe-modal'>
	            {/*
                <h2 className = {'modal-header stock-sub-modal-header'}>
                    请选择相关服务包
                </h2>
              */}
	            <div className = {`${stockservers.length === 1 ? 'stocksubscribe-modal-content' : ''} modal-content`}>
                <div className="blank30"></div>
	            	{ this.renderStockServers() }
	            	{/*
                  <ul className = "push-item-chioces">
  		            	<li key = { 0 } >
  		            		<PushChoiceItem text = { `微信推送(必选)` } index = { 0 } isMustChoice = { true }/>
  		            	</li>
  		            	<li key = { 1 } onClick = { this.handlePushChoice.bind(this, 1) } >
  		            		<PushChoiceItem text = { `短信推送(另收费)` } index = { 1 } isMustChoice = { false } isChoiced = { false }/>
  		            	</li>
  		            	<div></div>
  	            	</ul>
                */}
	            	<p className="money-notice">服务费用：<span className="money-number">{`${this.state.fee}元`}</span>/月</p>
	            	<p className="text-center">(微信推送)</p>
                <div className="blank10"></div>
	                <p>
	                  <input 
	                    type="checkbox" 
	                    className="check-protocol" 
	                    checked={this.state.protocolStatus}
	                    onChange = { this.handleProtocolChange.bind(this) }/>
	                  <small>
                      &nbsp;我已阅读并同意
                    </small>
                    <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocal.bind(this, "use")}>
                      《华西证券股份有限公司证券投资咨询产品使用协议》
                    </a>
                    &nbsp;<small>、</small>&nbsp;
                    <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocal.bind(this, "sf")}>
                      《“赢财富如影随形”证券投资咨询产品服务协议》
                    </a>
                    &nbsp;<small>及</small>&nbsp;
                    <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocal.bind(this, "risk")}>
                      《“赢财富”风险揭示》
                    </a>
	                </p>
	                <p ref="tipSureDanger" className={this.state.tipSureDanger?"text-danger":"hide"}>
	                  请先确认阅读并同意
	                </p>
	            </div>
	            <div className={'modal-footer'}>
	              <button className={'btn-block'} onClick={ this.handleSure.bind(this) }>签约使用</button>
	            </div>
	        </div>
        )
    }
}

export default StockSubscribe;

