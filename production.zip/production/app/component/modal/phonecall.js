import React from 'react';


class ModalPhoneCall extends React.Component {

  constructor() {
    super();
  }
  
  handleClose(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }

  render() {
    return (
        <div>
          <h2 className = {'modal-header'}>
            华西证券
          </h2>
          <div className = {'modal-content text-center'}>
            客服及投诉电话：95584
          </div>
            <div className={'modal-footer'}>
              <button onClick={ this.handleClose.bind(this) }><a className="phone-call" href="tel:95584">马上通话</a></button>
              <button onClick={ this.handleClose.bind(this) }>取消</button>
            </div>
        </div>
    );
  }
}

ModalPhoneCall.propTypes = {
  
}

ModalPhoneCall.defaultProps = {
  
}

export default ModalPhoneCall;
