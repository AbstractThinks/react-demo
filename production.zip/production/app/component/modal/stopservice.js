import React from 'react';


class ModalStopService extends React.Component {

  constructor() {
    super();
  }
  
  handleClose(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }

  render() {
    return (
        <div>
          <h2 className = {'modal-header'}>
            系统提示
          </h2>
          <div className = {'modal-content'}>
            您已被暂停服务，如有问题，请致电：95584。
          </div>
          <div className={'modal-footer'}>
            <button onClick={ this.handleClose.bind(this) } className="btn-block">确定</button>
          </div>
        </div>
    );
  }
}

ModalStopService.propTypes = {
  
}

ModalStopService.defaultProps = {
  
}

export default ModalStopService;
