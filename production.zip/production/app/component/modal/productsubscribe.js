import React from 'react';


class ModalProductSubscribe extends React.Component {

  constructor() {
    super();

    this.state = {
      protocolStatus : true
    };
  }

  handleProtocolChange(){
    let { onProtocolChange } = this.props;
    let currentStatus = !this.state.protocolStatus;
    this.setState({
      protocolStatus:currentStatus
    });
    onProtocolChange(currentStatus);
    if (currentStatus) {
       this.refs.tipSureDanger.style.display = "none";
    }
  }

  handleSure(){
    let { onSureClick }  = this.props;
    if (this.state.protocolStatus) {
      onSureClick();
    } else {
      this.refs.tipSureDanger.style.display = "block";
    }
    
  }

  handleClose(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }
  /**
   * 打开协议modal
   * @return {[type]}
   */
  handleOpenProtocal(){
   let { onProtocolModalOpen }  = this.props;
   onProtocolModalOpen();    
  }
  /**
    * 打开协议modal
    * @return {[type]}
    */
  handleOpenProtocalUse(){
   let { onProtocolUseModalOpen }  = this.props;
   onProtocolUseModalOpen();    
  }
  /**
    * 打开协议modal
    * @return {[type]}
    */
  handleOpenProtocolRisk(){
   let { onProtocolRiskModalOpen }  = this.props;
   onProtocolRiskModalOpen();    
  }
  render() {

    let { productItem } = this.props;

    return (
        <div>
            <h2 className = {'modal-header'}>
                系统提示
            </h2>
            <div className = {'modal-content'}>
                <p>
                  { `签约后，我们将通过微信或短信将“${ productItem.name }”的服务内容信息推送至您的手机，请注意查收。`}
                </p>
                <p className="text-remark">
                  <small className="text-danger">
                    注：请确认您已知悉并完全了解该项服务产品的风险特征及佣金收取规则，并确认自愿使用该项服务产品。在作出投资决策时，须谨记“股市有风险，投资需谨慎”，并做好风险控制。
                  </small>
                </p>
                <p className="text-remark">
                  <input 
                    type="checkbox" 
                    className="check-protocol" 
                    checked={this.state.protocolStatus}
                    onChange = { this.handleProtocolChange.bind(this) }/>
                  <small>
                    &nbsp;我已阅读并同意
                  </small>
                  <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocalUse.bind(this)}>
                    《华西证券股份有限公司证券投资咨询产品使用协议》
                  </a>
                  &nbsp;<small>、</small>&nbsp;
                  <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocal.bind(this)}>
                    《“赢财富•价值型/热点型”证券投资咨询产品服务协议》
                  </a>
                  &nbsp;<small>及</small>&nbsp;
                  <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocolRisk.bind(this)}>
                    《“赢财富”风险揭示》
                  </a>
                </p>
                <p ref="tipSureDanger" className="text-danger" style={{display:"none"}}>
                  请先确认阅读并同意
                </p>
            </div>
            <div className={'modal-footer'}>
              <button onClick={ this.handleSure.bind(this) }>确定</button>
              <button onClick={ this.handleClose.bind(this) }>取消</button>
            </div>
        </div>
    );
  }
}

ModalProductSubscribe.propTypes = {
  
}

ModalProductSubscribe.defaultProps = {
  
}

export default ModalProductSubscribe;
