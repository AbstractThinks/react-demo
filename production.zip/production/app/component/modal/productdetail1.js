import React from 'react';


class ModalProductDetail1 extends React.Component {

  constructor() {
    super();
  }

  handleClose(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }

  render() {

    let { productItem } = this.props;

    return (
        <div className = {'modal-body'}>
            <div className={'modal-content'}>
                <h4>
                  { productItem.name }
                </h4>
                <hr/>
                <div>
                  <h5>
                    产品介绍：
                  </h5>
                  <p>
                    侧重于中线，以“精选价值股票”为原则，以基本面、股票池跟踪、上市公司实地调研及估值模型为选股依据，注重公司价值挖掘。
                  </p>
                  <h5>
                    服务内容
                  </h5>
                  <p>
                    1.标的股的调入和调出提醒、每周点评回顾、标的股的重大事项解读等。  
                  </p>
                  <p>
                    2.营业部专属服务人员电话服务；
                  </p>
                  <h5>
                    产品收费规则
                  </h5>
                  <p>仅针对推荐标的收费</p>
                  <p>
                    买入：<br/>
                    -原账户佣金率
                  </p>
                  <p>
                    卖出：<br/>
                  -标的止盈调出，T+20日内卖出按3‰佣金率收取；<br/>
                  -标的止损调出，按原佣金率收取；<br/>
                  -T日+产品未调出期间，卖出按3‰佣金率收取；<br/>
                  -标的调入前已买入，卖出按原佣金率收取；<br/>
                  -标的调出后买入，卖出按原佣金率收取
                  </p>
                  <h5>产品荐股周期</h5>
                  <p> 3个月左右</p>
                  <h5>产品止损原则</h5>
                  <p>
                    个股亏损超过-20%强行止损
                  </p>
                  <h5>产品仓位控制</h5>
                  <p>
                    单只标的仓位≤总仓位25%
                  </p>
                  <h5>适合客户</h5>
                  <p>
                    中高风险、高风险承受能力等级
                  </p>
                  <h5>【风险说明】</h5>
                  <p>
                    本产品荐股建议仅供参考，买卖由投资者自主决策。
                  </p>
                </div>
            </div>
            <div className={'modal-footer'}>
              <a className={'close'} onClick={ this.handleClose.bind(this) }></a>
            </div>
        </div>
    );
  }
}

ModalProductDetail1.propTypes = {
  
}

ModalProductDetail1.defaultProps = {
  
}

export default ModalProductDetail1;
