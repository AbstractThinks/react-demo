import React from 'react';


class ModalProductDetail2 extends React.Component {

  constructor() {
    super();
  }

  handleClose(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }

  render() {

    let { productItem } = this.props;

    return (
        <div className={'modal-body'}>
            <div className={'modal-content'}>
              <h4>
                { productItem.name }
              </h4>
              <hr/>
              <div>
                <h5>
                  产品介绍：
                </h5>
                <p>
                  专注于跟踪市场动向，筛选主力板块，甄别板块龙头，捕捉短线交易机会，侧重动态跟踪，满足追逐短线题材股投资者的投资需求。
                </p>
                <h5>
                  服务内容
                </h5>
                <p>
                  根据市场情况及板块走势，提供每日点评、公告解读、板块新闻及政策解读、及时盘中指导、异动点评等服务，注重板块内重点关注标的的波段指导。 
                </p>
                <h5>
                  产品收费规则
                </h5>
                <p>1.定向收费。从投资者订阅该服务的第二个交易日起至服务完结当日，仅对买卖推荐标的收取0.3%交易手续费。</p>
                <p>2.投资者在订阅前，重点关注标的已持有，买卖按原佣金率收取。</p>
                <h5>产品荐股周期</h5>
                <p>从订阅的T+1日至服务完结当日。</p>
                <h5>产品止损原则</h5>
                <p>
                  个股亏损到达建议止损价自动止损。
                </p>
                <h5>产品仓位控制</h5>
                <p>
                  单只标的仓位≤总仓位20%，整个板块重点关注标的仓位≤总仓位50%。
                </p>
                <h5>适合客户</h5>
                <p>
                  中高风险、高风险承受能力等级
                </p>
                <h5>【风险说明】</h5>
                <p>
                  本产品荐股建议仅供参考，买卖由投资者自主决策。
                </p>
              </div>
            </div>
            <div className={'modal-footer'}>
              <a className={'close'} onClick={ this.handleClose.bind(this) }></a>
            </div>
        </div>
    );
  }
}

ModalProductDetail2.propTypes = {
  
}

ModalProductDetail2.defaultProps = {
  
}

export default ModalProductDetail2;
