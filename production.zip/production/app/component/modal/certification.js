import React from 'react';


class ModalCertification extends React.Component {

  constructor() {
    super();
  }

  handleClose(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }

  render() {

    return (
        <div className = {'modal-body'}>
            <div className={'modal-content'}>
              <h4>
                赢财富专家团队信息公示
              </h4>
              <hr/>
              <div>
                <h5>
                  宏观策略研究专家
                </h5>
                <p className="text-center">
                  毛&#12288;胜:执业证书编号：S1120611010005
                </p>
                <h5>
                  价值研究专家
                </h5>
                <p className="text-center">
                  曹雪峰:执业证书编号：S1120615040002 <br/>
                  刘&#12288;艳:执业证书编号：S1120611040003 <br/>
                  王振虎:执业证书编号：S1120612020017 <br/>
                  冯智勇:执业证书编号：S1120614070006 <br/>
                  李小波:执业证书编号：S1120615080007 <br/>
                  郭宏磊:执业证书编号：S1120615080018 <br/>
                  杨志恒:执业证书编号：S1120615070003  
                </p>
                <h5>
                  交易研究专家
                </h5>
                <p className="text-center">
                  王守杰:执业证书编号：S1120611100001 <br/>
                  林龙辉:执业证书编号：S1120611090004 <br/>
                  李林军:执业证书编号：S1120611010003 <br/>
                  张洞明:执业证书编号：S1120611100003 <br/>
                  尚长虹:执业证书编号：S1120614020008 <br/>
                  张颐哲:执业证书编号：S1120616070001
                </p>
              </div>
            </div>
            <div className={'modal-footer'}>
              <a className={'close'} onClick={ this.handleClose.bind(this) }></a>
            </div>
        </div>
    );
  }
}

ModalCertification.propTypes = {
  
}

ModalCertification.defaultProps = {
  
}

export default ModalCertification;
