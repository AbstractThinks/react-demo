import React from 'react';


class ModalProductDetail2 extends React.Component {

  constructor() {
    super();
  }

  handleClose(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }

  render() {

    let { productItem } = this.props;

    return (
        <div className={'modal-body'}>
            <div className={'modal-content'}>
              <h4>
                { productItem.name }
              </h4>
              <hr/>
              <div>
                <h5>
                  产品介绍：
                </h5>
                <p>
                  单只标的的贴身管家
                </p>
                <h5>
                  服务内容
                </h5>
                <p>
                  服务套餐及研究报告；其中股票类的服务套餐有：异动点评、操作策略、公告解读等服务。 
                </p>
                <h5>
                  产品收费规则
                </h5>
                <p>1.套餐按包月收费（每月18元）。</p>
                <p>2.研究报告按篇收费，解锁前提示收费标准。</p>
                <h5>产品服务周期</h5>
                <p>从订阅的T+1日至服务完结当日 (客户可随时退订下月服务套餐)。</p>
                <h5>适合客户</h5>
                <p>
                  中高风险、高风险承受能力等级
                </p>
                <h5>【风险说明】</h5>
                <p>
                  本产品荐股建议仅供参考，买卖由投资者自主决策。
                </p>
              </div>
            </div>
            <div className={'modal-footer'}>
              <a className={'close'} onClick={ this.handleClose.bind(this) }></a>
            </div>
        </div>
    );
  }
}

ModalProductDetail2.propTypes = {
  
}

ModalProductDetail2.defaultProps = {
  
}

export default ModalProductDetail2;
