import React from 'react';


class ModalProductUnSubscribe extends React.Component {

  constructor() {
    super();
  }

  handleSure(){
    let { onSureClick }  = this.props;
    onSureClick();
  }

  handleClose(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }

  render() {

    let { productItem } = this.props;

    return (
        <div>
            <h2 className = {'modal-header'}>
              系统提示
            </h2>
            <div className = {'modal-content'}>
              <p>
                退签成功后，我们将停止对您进行“{ productItem.name }”的所有服务信息推送。
              </p>
              <p>
                <small className = "text-danger">
                  注：您的退签申请通过后台审核后，我们将通过微信或短信告知您退签结果，请注意查收。
                </small>  
              </p>
              
            </div>
            <div className={'modal-footer'}>
              <button onClick={ this.handleSure.bind(this) }>确定</button>
              <button onClick={ this.handleClose.bind(this) }>取消</button>
            </div>
        </div>
    );
  }
}

ModalProductUnSubscribe.propTypes = {
  
}

ModalProductUnSubscribe.defaultProps = {
  
}

export default ModalProductUnSubscribe;
