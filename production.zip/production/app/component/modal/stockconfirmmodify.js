import React from 'react';


class ModalStockConfirmModify extends React.Component {

  constructor() {
    super();
  }

  handleSure(){
    let { onSureClick }  = this.props;
    onSureClick();
  }

  handleClose(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }

  render() {
      return (
        <div>
            <h2 className = {'modal-header'}>
              确定修改服务套餐
            </h2>
            <div className = {'modal-content'}>
              <p>
                你是否确认修改赢财富-如影随形的套餐内容？
              </p>
              <p>
                <small className = "text-danger">
                  注：本次修改后，将在T+1日执行新套餐服务。（每日仅能修改一次）
                </small>  
              </p>
              
            </div>
            <div className={'modal-footer'}>
              <button onClick={ this.handleSure.bind(this) }>确定</button>
              <button onClick={ this.handleClose.bind(this) }>取消</button>
            </div>
        </div>
    );
  }
}

ModalStockConfirmModify.propTypes = {
  
}

ModalStockConfirmModify.defaultProps = {
  
}

export default ModalStockConfirmModify;
