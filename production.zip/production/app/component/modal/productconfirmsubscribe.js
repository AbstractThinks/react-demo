import React from 'react';



class ModalProductConfirmSubscribe extends React.Component {

  constructor() {
    super();

    this.state = {
      protocolStatus : true
    };
  }
  handleProtocolChange(){
    let { onProtocolChange } = this.props;
    let currentStatus = !this.state.protocolStatus;
    this.setState({
      protocolStatus:currentStatus
    });
    onProtocolChange(currentStatus);
    if (currentStatus) {
       this.refs.tipSureDanger.style.display = "none";
    }
  }
  /**
   * 确认
   * @return {[type]}
   */
  handleSure(){
    let { onSureClick, productItem}  = this.props;
    if (this.state.protocolStatus) {
      onSureClick(productItem);
      this.handleClose();
    } else {
      this.refs.tipSureDanger.style.display = "block";
    }
    
  }
  /**
   * 关闭modal
   * @return {[type]}
   */
  handleClose(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }
  /**
   * 打开协议modal
   * @return {[type]}
   */
  handleOpenProtocolRisk(){
   let { onProtocolRiskModalOpen }  = this.props;
   onProtocolRiskModalOpen();    
  }
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {

    let { productItem } = this.props;

    return (
        <div className="md-content">
            <h3 className = {'modal-header'}>
                系统提示
            </h3>
            <div className = {'modal-content md-content-text'}>
                <p>
                  <span className="text-danger">
                    尊敬的客户，谢谢您定制我公司为您提供的服务，当前的产品和您的风险偏好不匹配，是否确定定制该产品？
                  </span>
                </p>
                <p>
                  <input 
                    type="checkbox" 
                    className="check-protocol" 
                    checked={this.state.protocolStatus}
                    onChange = { this.handleProtocolChange.bind(this) }/>
                  <small>
                    &nbsp;我已阅读并同意
                  </small>
                  <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocolRisk.bind(this)}>
                    《“赢财富”风险揭示》
                  </a>
                </p>
                <p ref="tipSureDanger" className="text-danger" style={{display:"none"}}>
                  请先确认阅读并同意
                </p>
            </div>
            <div className={'modal-footer'}>
              <button  onClick={ this.handleSure.bind(this) }>确定</button>
              <button  onClick={ this.handleClose.bind(this) }>取消</button>
            </div>
        </div>
    );
  }
}

ModalProductConfirmSubscribe.propTypes = {
  
}

ModalProductConfirmSubscribe.defaultProps = {
  
}

export default ModalProductConfirmSubscribe;