import React from 'react';
import {
    formatDate
} from '../../common/formater';
class ProtocolUse extends React.Component {
    constructor(props) {
        super(props);
        this.displayName = 'Protocol';
    }
    /**
     * 真实的DOM被渲染出来后调用
     * @return {[type]}
     */
	componentDidMount(){
		document.getElementsByTagName('body')[0].style.overflow = 'hidden';
	}
	/**
     * 组件被移除之前被调用
     * @return {[type]}
     */
	
	componentWillUnmount(){
    	document.getElementsByTagName('body')[0].style.overflow = 'auto';
    }
	/**
	 * 关闭modal
	 * @return {[type]}
	 */
    handleClose(){
    	let { onCloseClick }  = this.props;
    	onCloseClick();
    }
    
    render() {
    	let {userinfo,showDate,btnText} = this.props;
    	let date = new Date();
    	let currentDate = formatDate(date, "yyyy年MM月dd日");
        return (
        	<div>
        		<div className={'modal-content'}>
	        		<div className={'popup protocol'}> 
		        		<div className="popup-content"> 
		        			<h4> “赢财富”风险揭示 </h4>
		        			<h5> 尊敬的客户</h5>
							<h6>基于证券市场的快速发展、从满足客户的个性化需求出发，公司推出了“赢财富”服务体系。该服务体系以服务产品的形式表现，归属于证券投资咨询产品-增值产品范畴，是辅助投资者做出投资决策的一种咨询建议，仅供投资者决策参考。</h6 > 
							<h6>为确保您的合法权益得到保障，在您决定参考证券投资咨询产品提供的建议时，请详细阅读并了解以下风险提示：</h6 > 
							<p> 1、证券投资咨询产品不能确保投资者获得盈利或本金不受损失。从事证券投资咨询业务的机构及其投资咨询人员证券不得以任何方式向投资者做出本金不受损失或者取得最低收益的承诺。投资者应在充分考虑自己所能承受之风险前提下，自主、谨慎地做出投资决定，一切投资风险自担。 </p> 
							<p>2、在接受证券投资咨询产品前，投资者应先登录网上营业厅详细了解该证券投资咨询增值产品的收费标准、交易规则、风险揭示及仓位控制。</p>
							<p> 3、在接受证券投资咨询产品前，投资者要事先了解从事证券投资咨询业务的机构及其投资咨询人员提供的产品具有针对性和时效性，不能在任何市场环境下长期有效。 </p> 
							<p>4、在接受证券投资咨询产品前，投资者要事先了解产品之前推荐的证券或组合的成绩，不代表今后也会一定成功。</p> 
							<p> 5、在接受证券投资咨询产品前，投资者要清楚的认识到证券市场可能会发生的系统性风险（如宏观经济风险、政策风险、市场风险、利率风险和购买力风险等）和非系统风险（上市公司经营风险、流动性风险、财务风险、信用风险、技术风险、其他风险等）均有可能会带来投资损失的可能性。 </p> 
							<p>6、投资者要充分认识到没有只涨不跌的市场，也没有只赚不赔的投资产品，理解并始终牢记“买者自负”的原则，理性投资，安全第一；结合自身风险承受能力，根据自身的经济状况审慎投资，将证券投资风险控制在可承受的范围内。</p> 
							<p> 7、证券投资咨询产品依据的证券研究报告和投资分析意见等，可能存在不准确、不全面或者被误读的风险。 </p> 
							<p>8、从事证券投资咨询业务的机构,存在因停业、解散、撤销、破产，或者被中国证监会撤销相关业务许可、责令停业整顿等原因导致不能履行提供证券投资咨询产品的风险；存在因工作人员离职、离岗等原因导致向投资者提供证券投资咨询产品服务连续性的风险。</p> 
							<p> 9、投资者未提供有效的联系方式，或联系方式变动未及时通知从事证券投资咨询业务的机构及其投资咨询人员，可能会导致无法及时获取证券投资咨询产品的风险出现。 </p> 
							<p>10、因通讯故障或网络中断原因，可能会导致从事证券投资咨询业务的机构无法及时向投资者传递证券投资咨询产品的风险出现。</p> 
							<p> 11、因证券停牌、退市或市场暴跌等市场因素，可能会导致投资者买入和卖出的价格与投资建议存在巨大差距的风险。 </p> 
							<p>12、投资者如需了解证券投资咨询产品的基本信息及证券投资品种相关知识及风险提示，可查阅公司网站http:/ /www.hx168.com.cn 也可致电95584或当地营业部的相关人员。</p> 
							<h6>证券市场是一个风险无时不在的市场，投资者在进行证券交易时存在赢利的可能，也存在亏损的风险。本风险提示书并不能揭示从事证券交易的全部风险及证券市场的全部情形。投资者务必对此有清醒的认识，认真考虑并谨慎投资。 </h6> 
							<h6>股市有风险、投资需谨慎！ </h6> 
							<h6>以上《风险提示书》本人/机构已阅读并完全理解，愿意承担证券市场的各种风险。 </h6> 
							<div className="blank5"></div> 
							<p className = "text-right" > 客户：{userinfo.name}</p> 
							{
								showDate ? 
									<p className = "text-right"> 日期：{currentDate}</p> 
									: 
									null
							} 
							<a className="btn btn-block btn-dark btn-protocol" onClick = {this.handleClose.bind(this)}>{btnText}</a>
						</div>
						
					</div>
				</div>
        		
        	</div>
        	
        );
    }
}

export default ProtocolUse;







