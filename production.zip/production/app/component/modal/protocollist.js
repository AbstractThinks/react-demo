import React from 'react';


class ModalProductProtocolList extends React.Component {

  constructor() {
    super();
  }

  handleClose(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }
  /**
   * 打开协议modal
   * @return {[type]}
   */
  handleOpenProtocal(){
   let { onProtocolModalOpen }  = this.props;
   onProtocolModalOpen({showDate: false, btnText: "关闭"});    
  }
  /**
    * 打开协议modal
    * @return {[type]}
    */
  handleOpenProtocalUse(){
   let { onProtocolUseModalOpen }  = this.props;
   onProtocolUseModalOpen({showDate: false, btnText: "关闭"});    
  }
  /**
    * 打开协议modal
    * @return {[type]}
    */
  handleOpenProtocolRisk(){
   let { onProtocolRiskModalOpen }  = this.props;
   onProtocolRiskModalOpen({showDate: false, btnText: "关闭"});    
  }
  render() {

    return (
        <div>
            <h2 className = {'modal-header'}>
                赢财富相关协议
            </h2>
            <div className = {'modal-content'}>
                <p>
                  <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocalUse.bind(this)}>
                    《华西证券股份有限公司证券投资咨询产品使用协议》
                  </a>
                </p>
                <p>
                  <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocolRisk.bind(this)}>
                    《“赢财富”风险揭示》
                  </a>
                </p>
            </div>
            <div className={'modal-footer'}>
              <button onClick={ this.handleClose.bind(this) } className="btn-block">确定</button>
            </div>
        </div>
    );
  }
}

ModalProductProtocolList.propTypes = {
  
}

ModalProductProtocolList.defaultProps = {
  
}

export default ModalProductProtocolList;
