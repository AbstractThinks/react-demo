import React from 'react';


class ModalProductUnSubscribing extends React.Component {

  constructor() {
    super();
  }
  
  handleClose(){
    let { onCloseClick }  = this.props;
    onCloseClick();
  }

  render() {
    return (
        <div>
          <h2 className = {'modal-header'}>
            系统提示
          </h2>
          <div className = {'modal-content'}>
            您的退签申请已提交，后台审核成功后将通过微信告知您，请耐心等待。
          </div>
          <div className={'modal-footer'}>
            <button onClick={ this.handleClose.bind(this) } className="btn-block">确定</button>
          </div>
        </div>
    );
  }
}

ModalProductUnSubscribing.propTypes = {
  
}

ModalProductUnSubscribing.defaultProps = {
  
}

export default ModalProductUnSubscribing;
