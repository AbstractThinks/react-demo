import React from 'react';
import ChoiceItem from '../component/choiceItem';

class QuestionItem extends React.Component {

  constructor() {
    super();
    this.state = {
      active : -1
    };
  }

  componentWillMount() { 
  }
  //检查选择的选项是否为必选项，并将选择结果传回
  handleChoice(i) {
    this.setState(
      {
        active: this.props.questionItem.items[i].key
      });
    let {changeChoice,questionItem,warn} = this.props;
    let optionCheck = false;
    if(!warn || (questionItem.mustChoice <= 0) || (questionItem.mustChoice > 0 && questionItem.mustChoice === this.props.questionItem.items[i].key)) {
        optionCheck = true;
    }
    changeChoice(this.props.questionItem.items[i].value, optionCheck);
  }
  
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {
    let { questionItem, warn } = this.props;
    return(
      <div className="text-left question-item">
        <h6>{questionItem.title}</h6>
        {
          // 需要提示，同时有必选项，选择的答案和必选项不同
          warn && questionItem.mustChoice > 0 && questionItem.mustChoice !== this.state.active && this.state.active!==-1 ? 
            <p className="text-remark">
              <small className="text-danger">
                {questionItem.warn}
              </small>
            </p>
            : 
            null 
        }
        {
          questionItem.items && questionItem.items.length > 0 ?
            questionItem.items.map((node, i) => 
              <div key = { i } onClick = { this.handleChoice.bind(this, i) }>
                <ChoiceItem 
                  isChoiced = { node.key === this.state.active } 
                  isMustChoice = { false } 
                  text = { node.title } />
              </div>)
            : 
            null
        } 
      </div>
    )
  }
}

export default QuestionItem;
