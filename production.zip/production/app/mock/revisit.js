export const items = {
    results : [
        {
            id : 0,
            title : "1、请问是您本人签署的“华西证券投资咨询产品使用协议”吗？",
            items : [
                {
                    "description":"A. 是",
                    "title":"A. 是",
                    "value":'A',
                    "key":1
                },
                {
                    "description":"B. 否",
                    "title":"B. 否",
                    "value":'B',
                    "key":0
                }
            ],
            warn :"非本人签署《华西证券投资咨询产品使用协议》无法签约此服务！",
            mustChoice : 1
        },{
            id : 1,
            title : "2、请问您知晓目前签约的投资咨询产品服务内容及收费规则吗？",
            items : [
                {
                    "description":"A. 是",
                    "title":"A. 是",
                    "value":'A',
                    "key":1
                },
                {
                    "description":"B. 否",
                    "title":"B. 否",
                    "value":'B',
                    "key":0
                }
            ],
            warn :"为保障您的权益，请您详细了解投资咨询产品相关服务内容及收费规则后，再进行签约！",
            mustChoice : 1
        },{
            id : 2,
            title : "3、请问华西证券工作人员是否未曾与您私下签署过其他协议，未向您收取额外服务费用且未向您保证收益、未与您约定收益分成？",
            items : [
                {
                    "description":"A. 是",
                    "title":"A. 是",
                    "value":'A',
                    "key":1
                },
                {
                    "description":"B. 否",
                    "title":"B. 否",
                    "value":'B',
                    "key":0
                }
            ],
            warn :"我司工作人员不得与您私下签署其他协议，不得向您收取额外费用，不得向您保证或约定收益分成，如存在上述违规情况，请您及时致电95584反馈！",
            mustChoice : 1
        }
    ],
    "rscode" : "0",
    "rslevel" : "0",
    "totalRow" : 3
}