import { resourceURI } from '../config/api';

export const items = [
	{
	    pmid: "3",
	    url: `${resourceURI}img/product3.jpg`,
	    name: "赢财富 - 热点追击",
	    link: "productstrategy",
	    linkname: "查看" 
	},
	{
	    pmid: "4",
	    url:`${resourceURI}img/product4.jpg`,
	    name:"如影随形",
	    link: "stocklist",
	    linkname: "进入" 
	}]