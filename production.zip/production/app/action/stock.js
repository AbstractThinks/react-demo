import * as types from './../constant/actiontype';

export function fetchStocks({pageIndex = 1, pageSize = 10, loader = false, reset, resetSource} = {}) {
  return  (dispatch) => {

    let { status = 0, message = '加载中', flag = 0 } = {};

    dispatch({
      type: [types.FETCH_STOCKS, types.FETCH_STOCKS_SUCCESS, types.FETCH_STOCKS_FAILURE],
      payload:{
        status,
        message,
        loader,
        pageIndex,
        flag
      },
      meta: {
        fetch: [`sf/stocks?pageIndex=${pageIndex}&pageSize=${pageSize}`, {
            method: 'get'
          }
        ],
        reset: reset,
        resetSource: resetSource
      }
    });
  };
}

export function fetchStockMessages({pageIndex = 1, pageSize = 10, loader = false, stockId = 0, reset, resetSource} = {}) {
  return  (dispatch) => {

    let { status = 0, message = '加载中', flag = 0 } = {};

    dispatch({
      type: [types.FETCH_STOCK_MESSAGES, types.FETCH_STOCK_MESSAGES_SUCCESS, types.FETCH_STOCK_MESSAGES_FAILURE],
      payload:{
        status,
        message,
        loader,
        pageIndex,
        flag,
        pmid : stockId
      },
      meta: {
        fetch: [`sf/info/message/list?pageIndex=${pageIndex}&pageSize=${pageSize}&stockId=${stockId}`, {
            method: 'get'
          }
        ],
        reset: reset,
        resetSource: resetSource,
        pmid: stockId
      }
    });
  };
}
export function fetchStockReports({pageIndex = 1, pageSize = 10, loader = false, stockId, reset, resetSource} = {}) {
  return  (dispatch) => {

    let { status = 0, message = '加载中', flag = 0 } = {};

    dispatch({
      type: [types.FETCH_STOCK_REPORTS, types.FETCH_STOCK_REPORTS_SUCCESS, types.FETCH_STOCK_REPORTS_FAILURE],
      payload:{
        status,
        message,
        loader,
        pageIndex,
        flag,
        pmid : stockId
      },
      meta: {
        fetch: [`sf/info/report/list?pageIndex=${pageIndex}&pageSize=${pageSize}&stockId=${stockId}`, {
            method: 'get'
          }
        ],
        reset: reset,
        resetSource: resetSource,
        pmid: stockId
      }
    });
  };
}

export function fetchStockMessage(id) {
  return  (dispatch, getState) => {
    let { status = 0, message = '加载中', loader = true } = {};

    dispatch({
      type: [types.FETCH_STOCK_MESSAGE, types.FETCH_STOCK_MESSAGE_SUCCESS, types.FETCH_STOCK_MESSAGE_FAILURE],
      payload:{
        status,
        loader,
        message
      },
      meta: {
        fetch: [`sf/info/msg/${id}`, {
            method: 'get'
          }
        ]
      }
    });
  };
}

export function fetchStockReport(id) {
  return  (dispatch, getState) => {
    let { status = 0, message = '加载中', loader = true, unlockStatus = 0 } = {};

    dispatch({
      type: [types.FETCH_STOCK_REPORT, types.FETCH_STOCK_REPORT_SUCCESS, types.FETCH_STOCK_REPORT_FAILURE],
      payload:{
        status,
        loader,
        message,
        unlockStatus
      },
      meta: {
        fetch: [`sf/info/report/${id}`, {
            method: 'get'
          }
        ]
      }
    });
  };
}
export function subStockReport(pid){
  return  (dispatch) => {

    let { status = 0, message = '加载中', loader = false, unlockStatus = 1 } = {};

    dispatch({
      type: [types.SUB_STOCK_REPORT, types.SUB_STOCK_REPORT_SUCCESS, types.SUB_STOCK_REPORT_FAILURE],
      payload:{
        status,
        loader,
        pid : pid,
        message,
        unlockStatus
      },
      meta: {
        fetch: [`sf/info/unlock/${pid}`, {
            method: 'post',
            body: `id=${pid}`
          }
        ]
      }
    });
  };
}
export function fetchSearchStocks({pageIndex = 1, pageSize = 10, loader = false, queryStr = "", searchFlag = false} = {}) {
  return  (dispatch) => {
    let { status = 0, message = '加载中' } = {};

    //需要encode两次，后台才能解析
    let enQueryStr = encodeURIComponent(encodeURIComponent(queryStr));

    dispatch({
      type: [types.FETCH_SEARCH_STOCKS, types.FETCH_SEARCH_STOCKS_SUCCESS, types.FETCH_SEARCH_STOCKS_FAILURE],
      payload:{
        status,
        message,
        loader,
        pageIndex,
        searchFlag,
        queryStr
      },
      meta: {
        fetch: [`sf/info/stock/search?pageIndex=${pageIndex}&pageSize=${pageSize}&str=${enQueryStr}`, {
            method: 'get'
          }
        ]
      }
    });
  };
}
export function resetSearchStocks() {
  return  (dispatch) => {

    dispatch({
      type: types.RESET_SEARCH_STOCKS
    });
  };
}
export function fetchStockServers({stockId, opt = 1, reset, resetSource} = {}) {
  return  (dispatch) => {

    let { status = 0, message = '加载中', loader = true, flag = 0 } = {};

    dispatch({
      type: [types.FETCH_STOCK_SERVERS, types.FETCH_STOCK_SERVERS_SUCCESS, types.FETCH_STOCK_SERVERS_FAILURE],
      payload:{
        status,
        message,
        loader
      },
      meta: {
        fetch: [`sf/info/package/list?stockId=${stockId}&opt=${opt}`, {
            method: 'get'
          }
        ],
        reset: reset,
        resetSource: resetSource
      }
    });
  };
}
export function subStock({stockId, pkgId, isSendSMS} = {}){
  return  (dispatch) => {
    let { loader = false } = {};

    dispatch({
      type: [types.SUB_STOCK, types.SUB_STOCK_SUCCESS, types.SUB_STOCK_FAILURE],
      payload:{
        loader,
        pmid : stockId
      },
      meta: {
        fetch: [`sf/sub`, {
            method: 'post',
            body: `stockId=${stockId}&pkgId=${pkgId}&isSendSms=${isSendSMS}`
          }
        ]
      }  
    });
  };
}

export function subSearchStock({stockId, pkgId, isSendSMS} = {}){
  return  (dispatch) => {
    let { loader = false } = {};

    dispatch({
      type: [types.SUB_SEARCH_STOCK, types.SUB_SEARCH_STOCK_SUCCESS, types.SUB_SEARCH_STOCK_FAILURE],
      payload:{
        loader,
        pmid : stockId
      },
      meta: {
        fetch: [`sf/sub`, {
            method: 'post',
            body: `stockId=${stockId}&pkgId=${pkgId}&isSendSms=${isSendSMS}`
          }
        ]
      }  
    });
  };
}

export function unSubStock(stockId){
  return  (dispatch) => {
    let { loader = false } = {};

    dispatch({
      type: [types.UNSUB_STOCK, types.UNSUB_STOCK_SUCCESS, types.UNSUB_STOCK_FAILURE],
      payload:{
        loader,
        pmid : stockId
      },
      meta: {
        fetch: [`sf/unsub`, {
            method: 'post',
            body: `stockId=${stockId}`
          }
        ]
      }  
    });
  };
}

export function modifyStock({stockId, pkgId, isSendSMS} = {}){
  return  (dispatch) => {
    let { loader = false } = {};

    dispatch({
      type: [types.MODIFY_STOCK, types.MODIFY_STOCK_SUCCESS, types.MODIFY_STOCK_FAILURE],
      payload:{
        loader,
        pmid : stockId
      },
      meta: {
        fetch: [`sf/sub`, {
            method: 'post',
            body: `stockId=${stockId}&pkgId=${pkgId}&isSendSms=${isSendSMS}`
          }
        ]
      }  
    });
  };
}

export function fetchStockCost() {
  return  (dispatch, getState) => {
    let { status = 0, message = '加载中', loader = true } = {};

    dispatch({
      type: [types.FETCH_STOCK_COST, types.FETCH_STOCK_COST_SUCCESS, types.FETCH_STOCK_COST_FAILURE],
      payload:{
        status,
        loader,
        message
      },
      meta: {
        fetch: [`sf/account`, {
            method: 'get'
          }
        ]
      }
    });
  };
}

export function fetchStockCostDetail({pageIndex = 1, pageSize = 20, loader = false, pmid = "deduct"} = {}) {
  return  (dispatch, getState) => {
    let { status = 0, message = '加载中' } = {};

    dispatch({
      type: [types.FETCH_STOCK_COST_DETAIL, types.FETCH_STOCK_COST_DETAIL_SUCCESS, types.FETCH_STOCK_COST_DETAIL_FAILURE],
      payload:{
        status,
        loader,
        message,
        pmid
      },
      meta: {
        fetch: [`sf/account/${pmid}?pageIndex=${pageIndex}&pageSize=${pageSize}`, {
            method: 'get'
          }
        ]
      }
    });
  };
}