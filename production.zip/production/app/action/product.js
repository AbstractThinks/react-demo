import * as types from './../constant/actiontype';

export function fetchProducts() {
  return  (dispatch, getState) => {
    let { status = 0, message = '加载中', loader = true } = {};

    dispatch({
      type: [types.FETCH_PRODUCTS, types.FETCH_PRODUCTS_SUCCESS, types.FETCH_PRODUCTS_FAILURE],
      payload:{
        status,
        loader,
        message
      },
      meta: {
        fetch: [`prod`, {
            method: 'get'
          }
        ]
      }  
    });
  };
}

export function subProduct(productItem){
  let {pmid, name} = productItem;
  return  (dispatch) => {

    let { loader = false } = {};

    dispatch({
      type: [types.SUB_PRODUCT, types.SUB_PRODUCT_SUCCESS, types.SUB_PRODUCT_FAILURE],
      payload:{
        loader,
        pmid : pmid
      },
      meta: {
        fetch: [`prod/subscribe`, {
            method: 'post',
            body: `productId=${pmid}&productName=${name}`
          }
        ]
      }  
    });
  };
}

export function unsubProduct(productItem){
  let {pmid, name} = productItem;
  return  (dispatch) => {

    let { loader = false } = {};

    dispatch({
      type: [types.UNSUB_PRODUCT, types.UNSUB_PRODUCT_SUCCESS, types.UNSUB_PRODUCT_FAILURE],
      payload:{
        loader, 
        pmid : pmid
      },
      meta: {
        fetch: [`prod/cancel`, {
            method: 'post',
            body: `productId=${pmid}&productName=${name}`
          }
        ]
      }  
    });
  };
}

