import * as types from './../constant/actiontype';
import {RSAEncrypt} from '../common/util';

export function login({username, captcha, password, source = 'WX', randKey = '19870627', accountType = '0', rememberMe = false} = {}) {
  return  (dispatch) => {

    let { status = 0, message = '加载中' } = {};

    dispatch({
      type: [types.USER_LOGIN, types.USER_LOGIN_SUCCESS, types.USER_LOGIN_FAILURE],
      payload:{
        status,
        message
      },
      meta: {
        fetch: [`sessions/login`, {
            method: 'post',
            body: `username=${username}&password=${RSAEncrypt(password)}&captcha=${captcha}&source=${source}&randKey=${randKey}&accountType=${accountType}&rememberMe=${rememberMe}`
          }
        ]
      }
    });
  };
}

export function fetchCaptcha() {
  return  (dispatch) => {

    let { status = 0, message = '加载中' } = {};

    dispatch({
      type: [types.FETCH_CAPTCHA, types.FETCH_CAPTCHA_SUCCESS, types.FETCH_CAPTCHA_FAILURE],
      payload:{
        status,
        message
      },
      meta: {
        fetch: [`stream/randimg?randKey=19870627&width=96&height=32`, {
            method: 'get'
          }
        ]
      }
    });
  };
}

export function getUserInfo({ reset, resetSource, loader=false } = {}) {
  return (dispatch) => {
    let { status = 0, message = '加载中', flag = 0 } = {};
    dispatch({
      type: [types.USER_INFO, types.USER_INFO_SUCCESS, types.USER_INFO_FAILURE],
      payload:{
        status,
        message,
        flag
      },
      meta: {
        fetch: [`sessions/user`, {
            method: 'get'
          }
        ],
        reset: reset,
        resetSource: resetSource
      }
    });

  }
}

export function getReVisit() {
  return (dispatch) => {
    let { status = 0, message = '加载中', loader = true } = {};
    dispatch({
      type: [types.FETCH_REVISIT_INFO, types.FETCH_REVISIT_INFO_SUCCESS, types.FETCH_REVISIT_INFO_FAILURE],
      payload:{
        status,
        message,
        loader
      },
      meta: {
        fetch: []
      }
    });

  }
}

export function commitReVisit({pmid="", results=""}={}) {
  return (dispatch) => {
    let { status = 0, message = '加载中' } = {};
    dispatch({
      type: [types.COMMIT_REVISIT_INFO, types.COMMIT_REVISIT_INFO_SUCCESS, types.COMMIT_REVISIT_INFO_FAILURE],
      payload:{
        status,
        message
      },
      meta: {
        fetch: [`prod/revisit`, {
            method: 'post',
            body: `productId=${pmid}&answer=${results}`
          }
        ]
      }
    });

  }
}