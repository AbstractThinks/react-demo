import * as types from './../constant/actiontype';

export function fetchMessages({pageIndex = 1, pageSize = 10, reset, resetSource} = {}) {
  return  (dispatch) => {

    let { status = 0, message = '加载中', loader = true, flag = 0 } = {};

    dispatch({
      type: [types.FETCH_MESSAGES, types.FETCH_MESSAGES_SUCCESS, types.FETCH_MESSAGES_FAILURE],
      payload:{
        status,
        message,
        loader,
        pageIndex,
        flag
      },
      meta: {
        fetch: [`comment?pageIndex=${pageIndex}&pageSize=${pageSize}`, {
            method: 'get'
          }
        ],
        reset: reset,
        resetSource: resetSource
      }
    });
  };
}

export function fetchMessage({id, type} = arguments) {
  return  (dispatch) => {

    let { status = 0, message = '加载中', loader = false } = {};

    dispatch({
      type: [types.FETCH_MESSAGE, types.FETCH_MESSAGE_SUCCESS, types.FETCH_MESSAGE_FAILURE],
      payload:{
        status,
        loader,
        message
      },
      meta: {
        fetch: [`comment/type/${type}?id=${id}`, {
            method: 'get'
          }
        ]
      }
    });
  };
}

