import * as types from './../constant/actiontype';


export function fetchProductsStrategys({pageIndex = 1, pageSize = 10, reset, resetSource} = {}) {
  return  (dispatch, getState) => {
    let { status = 0, message = '加载中', loader = true, flag = 0 } = {};
    dispatch({
      type: [types.FETCH_PRODUCTS_STRATEGYS, types.FETCH_PRODUCTS_STRATEGYS_SUCCESS, types.FETCH_PRODUCTS_STRATEGYS_FAILURE],
      payload:{
        status,
        loader,
        message,
        flag
      },
      meta: {
        fetch: [`prod/info/list?pageIndex=${pageIndex}&pageSize=${pageSize}`, {
            method: 'get'
          }
        ],
        reset: reset, 
        resetSource: resetSource
      }  
    });
  };
}

export function fetchProductsStrategy({ id = 0, preview } = {}) {
  return  (dispatch, getState) => {
    let { status = 0, message = '加载中', loader = true, unlockStatus = 0 } = {};
    let fetchUrl = `prod/info/${id}`;
    if(typeof preview !== 'undefined') {
      fetchUrl = `prod/info/${id}?preview=${preview}`
    }
    dispatch({
      type: [types.FETCH_PRODUCTS_STRATEGY, types.FETCH_PRODUCTS_STRATEGY_SUCCESS, types.FETCH_PRODUCTS_STRATEGY_FAILURE],
      payload:{
        status,
        loader,
        message,
        unlockStatus
      },
      meta: {
        fetch: [fetchUrl, {
            method: 'get'
          }
        ]
      }
    });
  };
}

export function subProductStrategy({pid = 1, resolved} = {}){
  return  (dispatch) => {

    let { status = 0, message = '加载中', loader = false, unlockStatus = 1 } = {};

    dispatch({
      type: [types.SUB_PRODUCT_STRATEGY, types.SUB_PRODUCT_STRATEGY_SUCCESS, types.SUB_PRODUCT_STRATEGY_FAILURE],
      payload:{
        status,
        loader,
        pid : pid,
        message,
        unlockStatus
      },
      meta: {
        fetch: [`prod/info/unlock/${pid}`, {
            method: 'post',
            body: `id=${pid}`
          }
        ]
      },
      resolved :resolved  
    });
  };
}

export function fetchProductsStrategyComments({ articleid = 0, preview } = {}) {
  return  (dispatch, getState) => {
    let { status = 0, message = '加载中', loader = true } = {};
    let fetchUrl = `prod/info/${articleid}/comments`;
    if(typeof preview !== 'undefined') {
      fetchUrl = `prod/info/${articleid}/comments?preview=${preview}`
    }
    dispatch({
      type: [types.FETCH_PRODUCTS_STRATEGY_COMMENTS, types.FETCH_PRODUCTS_STRATEGY_COMMENTS_SUCCESS, types.FETCH_PRODUCTS_STRATEGY_COMMENTS_FAILURE],
      payload:{
        status,
        loader,
        message
      },
      meta: {
        fetch: [fetchUrl, {
            method: 'get'
          }
        ]
      }  
    });
  };
}
