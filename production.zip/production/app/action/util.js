import * as types from './../constant/actiontype';

export function reset({resetSource,pmid}) {
  return  (dispatch) => {

    dispatch({
      type: resetSource,
      pmid: pmid
  	});
  };
}

