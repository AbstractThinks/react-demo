import {
  Provider
} from 'react-redux';
import {
  Router,
  Route,
  IndexRoute
} from 'react-router';
import React from 'react';
import Container from './component/container';
import * as View from './view/index';




class Root extends React.Component {
  constructor(props) {
      super(props);
      this.displayName = 'Root';
  }
  componentWillMount() {
    
  }
  render () {

    let { store, history } = this.props;

    return (
      <Provider store={ store }>
          <Router history={ history }>
            <Route path='/'>
              <IndexRoute component={ View.Product } />
              <Route path='/login' component={ View.Login } />
              <Route path='/Download' component={ View.Download } />
              <Route path='/share' component={ View.Share } />
              <Route path='/product' component={ View.Product } />
              <Route path='/productstrategy' component={ View.ProductStrategy } />
              <Route path='/productstrategydetail' component={ View.ProductStrategyDetail } />
              <Route path='/message' component={ View.Message } />
              <Route path='/messagedetail' component={ View.MessageDetail } />
              <Route path='/serverinfo' component={ View.ServerInfo } />
              <Route path='/shadowfollowintro' component={ View.ShadowFollowIntro } />
              <Route path='/stockmessage' component={ View.StockMessage } />
              <Route path='/stockreport' component={ View.StockReport } />
              <Route path='/stocklist' component={ View.StockList } />
              <Route path='/stocksearch' component={ View.StockSearch } />
              <Route path='/stockmodify' component={ View.StockModify } />
              <Route path='/stockmessagedetail' component={ View.StockMessageDetail} />
              <Route path='/stockreportdetail' component={ View.StockReportDetail} />
              <Route path='/nonactivated' component={ View.NonActiveted } />
              <Route path='/error' component={ View.Error } />
              <Route path='/revisit' component={ View.ReVisit } />
              <Route path='/feerecord' component={ View.FeeRecord } />
            </Route>
          </Router>
      </Provider>
    )
  }
}

export default Root;

