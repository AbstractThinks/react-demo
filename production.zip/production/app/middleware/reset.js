import * as utilAction from '../action/util';

export default function reset({dispatch}) {
	return next => action => {
		const { payload = null, meta = {} } = action;
		const { reset, resetSource, pmid } = meta;
		if (reset && resetSource) {
			setTimeout(()=> {
				utilAction.reset({resetSource, pmid})(dispatch);
			}, reset);
		}

		next(action);
	}
}
