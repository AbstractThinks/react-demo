import thunk from 'redux-thunk';
import logger from './logger';
import request from './request';
import reset from './reset';

export default [
  thunk,
  reset,
  request,
  logger
];
