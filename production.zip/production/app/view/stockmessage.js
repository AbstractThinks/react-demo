import React from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import { Link } from 'react-router';
import Content from '../component/content';
import CardItem from '../component/cardItem';
import Notify from '../common/notification';
import Modal from 'boron/ScaleModal';
import * as StockAction from '../action/stock';
import * as UserAction from '../action/user';
import StockSubscribe from '../component/modal/stocksubscribe';
import ProtocalUse from '../component/modal/protocalUse';
import ProtocolSF from '../component/modal/protocolsf';
import StopSerivice from '../component/modal/stopservice';
import { bindActionCreators } from 'redux';
import * as types from './../constant/actiontype';
import Loader from 'halogen/BounceLoader';
import { formatDate } from '../common/formater';
import ShadowFollowFooter from '../component/shadowFollowFooter';
import { auth, getUrl } from '../common/util';
import { wxshare } from '../common/wxshare';
import { resourceURI } from '../config/api';

import ModalRiskNotMatch from '../component/modal/risknotmatch';
import ModalReVisit from '../view/revisit';

import { checkRiskLevel,reVisit } from '../config/common';

class StockMessageApp extends React.Component {

  constructor() {
    super();
    this.showMessage = false;
    this.state = {
      modalBackdrop: true,
      modalClass: "modal-container",
      modalContent: null,
      modalProtocalBackdrop: false,
      modalProtocalContent: null,
      modalProtocalClass: "modal-container-full modal-protocal",
      msg:"上拉加载更多数据"
    };
    this.subProtocolStatus = true;
    this.enabledClick = true;

    document.body.className = "strategy-bg";
  }
  /**
   * 真实的DOM被渲染出来后调用
   * @return {[type]}
   */
  componentDidMount() {

    let { stockMessages, userinfo, stockservers } = this.props;
    // let extraInfo = stockMessages.extraInfo;
    let { stockId = 0 } = this.props.location.query;
    if (!userinfo.flag || !userinfo.results || (userinfo.results && userinfo.results.length === 0)) {
      this.props.userAction.getUserInfo({reset:300000, resetSource:types.RESET_USER_INFO});
    }
    // this.props.stockMessagesAction.fetchStockMessages({loader:true, stockId:stockId});
    this.props.stockMessagesAction.fetchStockServers({stockId: stockId, opt: 1});
    // this.props.userAction.getUserInfo({});
    if (!stockMessages[stockId] || !stockMessages[stockId].flag || !stockMessages[stockId].results || (stockMessages[stockId].results && stockMessages[stockId].results.length === 0)) {
      this.props.stockMessagesAction.fetchStockMessages({loader:true, stockId:stockId, reset:300000, resetSource:types.RESET_STOCK_MESSAGES});
    }
    // if (!stockservers.flag || !stockservers.results || (stockservers.results && stockservers.results.length === 0)) {
    //   this.props.stockAction.fetchStockServers({stockId: stockId, opt:1, reset:3000, resetSource:types.RESET_STOCK_SERVERS});
    // }
    let node = ReactDOM.findDOMNode(this);
    node.addEventListener('touchend', this._scrollLoad.bind(this), false);
    //node.addEventListener('touchmove', this._scrollMove.bind(this), false);
    this.afterComponentCompleteUpdate = true;
    wxshare();
  }
  componentWillUnmount() {
      let node = ReactDOM.findDOMNode(this);
      node.removeEventListener('touchend', this._scrollLoad.bind(this), false); 
  }
  /**
   * 完成渲染新的props或者state后调用
   * @return {[type]}
   */
  componentDidUpdate() {
    let { stockId = 0 } = this.props.location.query;
    if (this.props.stockMessages[stockId].status === 401) {
      auth({ go: 'stockmessage', stockId: stockId });
    } else {
      let { stock } = this.props;
      let { stockId = 0 } = this.props.location.query;
      let pmid = stock[stockId];
      if (typeof pmid!=='undefined' && pmid.sub_status && this.showMessage) {
        if(pmid.sub_status !== 1) {
          Notify.makeNotify(pmid.message, 1.5);
          this.showMessage = false;
        }
        if(pmid.sub_status === 2) {
          this.props.stockMessagesAction.fetchStockMessages({loader:true, stockId:stockId, reset:300000, resetSource:types.RESET_STOCK_MESSAGES});
        } else if(pmid.sub_status === 3) {
          this.enabledClick = true;
        }
      } 
      this.afterComponentCompleteUpdate = true;
    }

  }
  /**
   * 下拉加载
   * @return {[type]}
   */
  _scrollLoad() {
    let { stockId = 0 } = this.props.location.query;
    let clientHeight = document.body.clientHeight;
    let scrollHeight = document.body.scrollHeight - document.body.scrollTop;
    if (!this.props.stockMessages[stockId].page || ((this.props.stockMessages[stockId].page.nextPage === this.props.stockMessages[stockId].page.pageNo) && (clientHeight >= scrollHeight ))) {
      // Notify.makeNotify('当前已是最后一页');
       this.setState({
          msg:""
        })
       return;
    }
    if (this.afterComponentCompleteUpdate && (clientHeight >= scrollHeight)) {
      this.props.stockMessagesAction.fetchStockMessages({
        stockId: stockId,
        pageIndex: this.props.stockMessages[stockId].page.nextPage
      });
      this.setState({
        msg:"上拉加载更多数据"
      })
      this.afterComponentCompleteUpdate = false;

    }

  }
  /**
   * 订阅股票
   * @param  {[type]}
   * @return {[type]}
   */
  handleSubscribe(e) {
    if(this.enabledClick) {
        e.preventDefault();
        e.stopPropagation();
        let { stockservers,userinfo } = this.props;
        if(checkRiskLevel){
          let clientrisklevel = userinfo.results[0].clientrisklevel;
          let rinklevel = stockservers.extraInfo.rinklevel;
          let riskMatch = clientrisklevel >= rinklevel ? true : false;
          if(!riskMatch) {
            modalContent = 
            <ModalRiskNotMatch 
              onCloseClick = { this.onModalClose.bind(this) } />;
            this.setState({
              modalBackdrop : true,
              modalClass : "modal-container",
              modalContent : modalContent
            });
            this.refs.modalStockSubscribe.show();
            return;
          }
        }
        let modalContent = <StockSubscribe
        onProtocolChange = {
            this.onProtocolChange.bind(this)
        }
        onSureClick = {
            this.onSubscribeClick.bind(this)
        }
        onOpenProtocal = {
            this.handleOpenProtocal.bind(this)
        } 
        stockservers = { stockservers.results } /> 

        this.setState({
            modalBackdrop: true,
            modalClass: "modal-container",
            modalContent: modalContent
        });

        this.refs.modalStockSubscribe.show();
    }
  }
  /**
   * 协议详情弹出框
   * @return {[type]}
   */
  handleOpenProtocal({protocolType, showDate=true, btnText="确认并同意以上规则"}={}) {
    let { userinfo } = this.props;
    let modalContent = 
        protocolType === "use" ? 
            <ProtocalUse 
                onCloseClick = { this.handleCloseProtocal.bind(this) } 
                userinfo = { userinfo.results ? userinfo.results[0] : {} } 
                showDate = { showDate }
                btnText = { btnText }/> 
            : 
            protocolType === "sf" ? 
                <ProtocolSF 
                    onCloseClick = { this.handleCloseProtocal.bind(this) } 
                    userinfo = { userinfo.results ? userinfo.results[0] : {} } 
                    showDate = { showDate }
                    btnText = { btnText }/>
                : 
                null
    this.setState({
        modalProtocalContent: modalContent
    });
    this.refs.modalStockSubscribe.hide();
    this.refs.modalProtocal.show();
  }
  /**
   * 关闭协议详情弹出框
   * @return {[type]}
   */
  handleCloseProtocal() {
    this.refs.modalProtocal.hide();
    this.refs.modalStockSubscribe.show();
  }
  /**
   * 关闭弹出框
   * @return {[type]}
   */
  onModalClose(){
    this.refs.modalStockSubscribe.hide();
  }
  /**
   * 修改确认协议信息
   * @param  {[type]}
   * @return {[type]}
   */
  onProtocolChange(status) {
    this.subProtocolStatus = status;
  }
  /**
   * 确认订阅
   * @return {[type]}
   */
  onSubscribeClick(pkgId, isSendSMS) {
    if (this.subProtocolStatus) {
      let {stockservers} = this.props;
      let isrevisit = stockservers.extraInfo.isrevisit;
      if(reVisit && isrevisit!=1){
        let modalContent = null;
        modalContent = <ModalReVisit 
          onSuccessHandler = { this.onSuccessHandler.bind(this,pkgId, isSendSMS) }
          isNewUser = { true }
          pmid = {"1588021"}/> 
        
        this.setState({
          modalProtocalContent : modalContent
        });

        this.refs.modalStockSubscribe.hide();
        this.refs.modalProtocal.show();

        return;
      } else {
        this.enabledClick = false;
        let { stockId = 0 } = this.props.location.query;
        this.props.stockMessagesAction.subStock({stockId:stockId, pkgId:pkgId, isSendSMS:isSendSMS});
        this.showMessage = true;
        this.refs.modalStockSubscribe.hide();
      }
    }
  }
  //回访成功后的操作
  onSuccessHandler(pkgId, isSendSMS) {
    this.enabledClick = false;
    let { stockId = 0 } = this.props.location.query;
    this.props.stockMessagesAction.subStock({stockId:stockId, pkgId:pkgId, isSendSMS:isSendSMS});
    this.showMessage = true;
    this.refs.modalProtocal.hide();
  }
  handleCloseModal() {
    this.refs.modalStockSubscribe.hide();
  }
  showStopNotice() {
    let modalContent = <StopSerivice 
                          onCloseClick = {
                            this.handleCloseModal.bind(this)}/> 
    this.setState({
        modalContent: modalContent
    });
    this.refs.modalStockSubscribe.show();
  }
  renderReportList(){
    let { stockId = 0 } = this.props.location.query;
    let stockMessages = this.props.stockMessages[stockId] || {};
    let extraInfo = stockMessages.extraInfo;
    return (
      <div>
        <div className = "blank30"> </div> 
        <div className = "blank30"> </div> 
        {
          !stockMessages.loader && typeof extraInfo!=='undefined' && (extraInfo.status === "3" || extraInfo.status === "") ? 
            <div>
              { this.renderUnsubscribeContent(extraInfo) }
            </div>
            :
            stockMessages.loader ? 
              <div className = "loader-container"> 
                { <Loader color = "#e1bf6d" size = "48px" /> } 
              </div>
              : 
              stockMessages.results && stockMessages.results.length > 0 ?
                stockMessages.results.map((stockMessageItem, i) =>
                  <Link to={ `stockmessagedetail` } query={{ id : stockMessageItem.id }} key = { i }>
                    <CardItem 
                      headLeft = { stockMessageItem.tmplname } 
                      headRight = { formatDate(stockMessageItem.updatetime, "yyyy-MM-dd hh:mm") || "" }
                      contentBody = { stockMessageItem.title }
                      bottomLeft = { `点击查看` }
                      bottomRight = { `>` } />
                  </Link>) 
                  :
                  <div className = "text-center padding-lg" >
                    <div className = "blank30" > < /div>
                    暂无消息信息 
                  </div>
        }
        <div 
          className = {
            (!stockMessages.loader && stockMessages.results && stockMessages.results.length > 0) ? "" : "hide"
          } >
          <div className="text-center page-loading">
            {
              (!stockMessages.page || (stockMessages.page && (stockMessages.page.nextPage === stockMessages.page.pageNo))) ? 
              ""
              :
              this.state.msg
            }
          </div>

        </div>
      </div>
    );
  }
  renderUnsubscribeContent(extraInfo){
    return (
      	<div className="shadow-follow-intro-card stock-unsubscibe-info-card">
	        <img src={`${resourceURI}img/shuoming.png`} />
	        <div className = "blank20"> </div>
	        <span className="stockname">{`${ extraInfo.stockname }(${ extraInfo.stockcode })`}</span>
	        <div className="blank10"></div>
	        <span className="tips">您还未订阅该股票的如影随形服务</span>
	        <div className="blank20"></div>
	        <div className = "sub-operator">
		        <button className="btn btn-sub" href="javascript:void(0);"
                onClick = { this.handleSubscribe.bind(this) } >
		          <span>立即订阅</span>
		        </button>
	      	</div>
	      	<div className="blank10"></div>
	      	<span className="sub-number">{`${ extraInfo.subscribenum }人已订阅`}</span>
      	</div>
    );
  }

  renderHeader() {
    let { stockId = 0 } = this.props.location.query;
    let stockMessages = this.props.stockMessages[stockId] || {};
    return(
        stockMessages.loader || (typeof stockMessages.extraInfo!=='undefined' && (stockMessages.extraInfo.status === "3" || stockMessages.extraInfo.status === "")) ? 
          <div>
          </div>
          : 
          typeof stockMessages.extraInfo!=='undefined' && (stockMessages.extraInfo.status === "2" || stockMessages.extraInfo.status === "4") ? 
            <div className = "card-header strategy-title card-stock-message-header" > 
              <div className = "card-header-name pull-left">
                <span>服务股票</span>
              </div>
              <div className = "card-header-detail pull-left">
                <span>{`${ stockMessages.extraInfo.stockname }(${ stockMessages.extraInfo.stockcode })`}</span>
                <div className="span-blank"></div>
                <span>{`行业：${ stockMessages.extraInfo.trades }`}</span>
              </div>
              <div className = "card-header-operator pull-right">
                {
                  stockMessages.extraInfo.status === "4" ? 
                    <span className="stop-service text-underline text-danger" onClick={ this.showStopNotice.bind(this) }>暂停服务</span>
                    : 
                    <Link to={`stockmodify`} query={{ stockId: stockId }}>
                      <button className="btn btn-cancel-modify" href="javascript:void(0);">
                        <span>退订套餐</span>
                      </button>
                    </Link>
                }
              </div>
            </div>
            :
            null
      );
  }

  render() {
    return (
      
      < Content 
        className = { "product-strategy-container" }
        isMenubar = { false } >
          <div>
            { this.renderHeader() }
            { this.renderReportList() }
            <div className="blank30"></div>
            <div className="blank50"></div>
            <ShadowFollowFooter /> 
          </div>
        
        <Modal ref = "modalStockSubscribe"
          backdrop = {
              this.state.modalBackdrop
          }
          className = {
              this.state.modalClass
          } > {
              this.state.modalContent
          } 
          </Modal> 
          <Modal ref = "modalProtocal"
            backdrop = {
                this.state.modalProtocalBackdrop
            }
            className = {
                this.state.modalProtocalClass
            } > {
                this.state.modalProtocalContent
            } 
          </Modal>   
      </Content>
    );
  }
}

export default connect(state => ({
      stockMessages: state.stockmessages,
      stockservers: state.stockservers,
      userinfo: state.userinfo,
      stock: state.stock
    }), dispatch => ({
      stockMessagesAction: bindActionCreators(StockAction, dispatch),
      userAction: bindActionCreators(UserAction, dispatch)
    }))(StockMessageApp);
