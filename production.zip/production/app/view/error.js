import React from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import { Link } from 'react-router';
import { wxshare } from '../common/wxshare';

class ErrorApp extends React.Component {

  constructor () {
    super();
  }

  componentDidMount(){
    this.refreshBodyStyle();
    wxshare();
  }

  refreshBodyStyle( style = 'share-bg'){
    let thisBody = document.body;
    thisBody.className = style;
  }

  renderMainContent(){
      return (
        <div id="content">
            <div className="header">
                &nbsp;
            </div>
            <div className="content">
                <p>
                <small>网络错误，请退出后重试！</small>
                </p>
            </div>
        </div>
      );
  }

  render() {

    return (
         <div>
            { this.renderMainContent() }
        </div>
    );
  }
}

export default connect(state => ({

}), dispatch => ({

}))(ErrorApp);
