import React from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import * as apis from '../config/api';
import { wxshare } from '../common/wxshare';

class ShareApp extends React.Component {

  constructor () {
    super();
  }

  componentDidMount(){
    this.refreshBodyStyle();
    wxshare();
  }

  refreshBodyStyle( style = 'share-bg'){
    let thisBody = document.body;
    thisBody.className = style;
  }

  renderMainContent(){
      return (
        <div id="content">
            <div className="header">
                &nbsp;
            </div>
            <div className="content">
                <p>
                一次推荐一只股
                </p>
            </div>
            <div className="footer">
                <a href={apis.official_account_url} className="btn btn-block btn-dark">立即获取</a>
            </div>
        </div>
      );
  }

  render() {

    return (
         <div>
            { this.renderMainContent() }
        </div>
    );
  }
}

export default connect(state => ({

}), dispatch => ({

}))(ShareApp);
