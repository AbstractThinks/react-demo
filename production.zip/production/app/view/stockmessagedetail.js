import * as StockAction from '../action/stock';
import Loader from 'halogen/BounceLoader';
import React from 'react';
import Notify from '../common/notification';
import StrategyFooter from '../component/footer';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { formatDate } from '../common/formater';
import { auth, getUrl } from '../common/util';
import { wxshare } from '../common/wxshare';

class StockMessageDetailApp extends React.Component {
    constructor(props) {
        super(props);
        this.showNoMessage = false;
        this.firstRender = true;
        document.body.className = "";
    }
    /**
     * 真实的DOM被渲染出来后调用
     * @return {[type]}
     */
    componentDidMount() {
        let { id = 0 } = this.props.location.query;
        this.props.stockAction.fetchStockMessage(id);
        // let { userinfo } = this.props;
        // if (!userinfo.flag || !userinfo.results || (userinfo.results && userinfo.results.length === 0)) {
        //   this.props.userAction.getUserInfo({reset:300000, resetSource:types.RESET_USER_INFO});
        // }
    }

    /**
     * 真实dom更新后被调用
     * @return {[type]}
     */
    componentDidUpdate() {
        if ( 401 === this.props.stockMessageDetail.status ) {
            this.showNoMessage = false;
            let { id = 0 } = this.props.location.query;
            auth({ go: 'stockmessagedetail', id: id });
        } else {
            this.showNoMessage = true;
        }
    }
    componentWillReceiveProps(nextProps) {
        let { stockMessageDetail } = nextProps;
        if(!stockMessageDetail.loader && this.firstRender && typeof stockMessageDetail.results!=='undefined' && typeof stockMessageDetail.results[0]!=='undefined') {
            wxshare({
                link: getUrl({go: 'stockmessagedetail', id: stockMessageDetail.results[0].id}),
                msgContent: stockMessageDetail.results[0].title
            });
            this.firstRender = false;
        }
    }
    renderHeader() {
        let { stockMessageDetail } = this.props;
        let stockMessage = stockMessageDetail.results[0];
        let updatetime = formatDate(stockMessage.updatetime, "yyyy-MM-dd hh:mm") || "";
        
        return(
            <div>
                <div className = "message-header" >
                    <h5 > 
                        <b> { stockMessage.title } </b>
                    </h5 >
                </div> 
                <div className = "message-stock" >
                    <h6> 
                        <span className="point"></span>{ `${stockMessage.stockname} (${stockMessage.stockcode})` } 
                    </h6>
                </div> 
                 <div className = "message-publictime" >
                    <small className = 'text-muted' > 
                        { `${updatetime} 发布` } 
                    </small>  
                </div>
            </div>
            );
    }

    renderContent() {
        let { stockMessageDetail } = this.props;
        return(
            <div>
                <div className = "strategy-content" dangerouslySetInnerHTML = {{__html: stockMessageDetail.results[0].descript}}></div>
            </div>
        );
    }
    /**
     * 页面渲染
     * @return {[type]}
     */
    render() {

        let { stockMessageDetail } = this.props;
        return(
            <div> 
                { 
                    stockMessageDetail.loader ?
                        <div className = "loader-container" > 
                            { <Loader color = "#e1bf6d" size = "48px" /> } 
                        </div>  
                        : 
                        stockMessageDetail.results && stockMessageDetail.results.length > 0 ?
                            <div className = "strategy-product" >
                                <div className = "blank30"></div> 
                                <div className = "card content-strategy-detail">
                                    { this.renderHeader() }
                                    { this.renderContent() }
                                </div> 
                                <div className = "blank30"> </div> 
                                <div className = "blank100"> </div> 
                                <StrategyFooter />
                                
                            </div>
                            :
                            <div>
                                <div className = "blank30"> </div>
                                <div className = "blank30"> </div> 
                                <div className = {this.showNoMessage ? "text-center padding-lg" : "hide"} >
                                    暂无消息详情
                                </div>
                            </div>
                } 
            </div>    
        ) 
    }
}

export default connect(state => ({
    stockMessageDetail: state.stockmessagedetail
}), dispatch => ({
    stockAction: bindActionCreators(StockAction, dispatch)
}))(StockMessageDetailApp);

