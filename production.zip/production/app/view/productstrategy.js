import * as ProductStrategyAction from '../action/productStrategy';
import ProductStrategyItem from '../component/productStrategyItem';
import Loader from 'halogen/BounceLoader';
import Notify from '../common/notification';
import React from 'react';
import ReactDOM from 'react-dom';
import Content from '../component/content';
import StrategyFooter from '../component/footer';
import { auth } from '../common/util';
import { wxshare } from '../common/wxshare';
import { connect
} from 'react-redux';
import {
  bindActionCreators
} from 'redux';
import * as types from './../constant/actiontype';

class ProductStrategyApp extends React.Component {

    constructor(props) {
      super(props);
      this.displayName = 'ProductStrategyApp';
      this.showMessage = false;
      document.body.className = "strategy-bg";
      this.state = {
        msg:'上拉加载更多数据'
      }
    }
    /**
     * 真实的DOM被渲染出来后调用
     * @return {[type]}
     */
    componentDidMount() {

      let { productStrategy } = this.props;

      if (!productStrategy.flag || !productStrategy.results || (productStrategy.results && productStrategy.results.length === 0)) {
        this.props.productStrategyAction.fetchProductsStrategys({reset:300000, resetSource:types.RESET_PRODUCTS_STRATEGY});
      }
      
      let node = ReactDOM.findDOMNode(this);
      node.addEventListener('touchend', this._scrollLoad.bind(this), false);
      //node.addEventListener('touchmove', this._scrollMove.bind(this), false);
      this.afterComponentCompleteUpdate = true;
      wxshare();
    }

    componentWillUnmount() {
      let node = ReactDOM.findDOMNode(this);
      node.removeEventListener('touchend', this._scrollLoad.bind(this), false);
    }

    /**
     * 完成渲染新的props或者state后调用
     * @return {[type]}
     */
    componentDidUpdate() {
      if (this.props.productStrategy.status === 401) {
        auth({ go: 'productstrategy' });
      } else {
        this.afterComponentCompleteUpdate = true;
        this.showMessage = true;
      }
      
    }
    _scrollMove() {
    let clientHeight = document.body.clientHeight;
    let scrollHeight = document.body.scrollHeight - document.body.scrollTop;
    if (clientHeight === scrollHeight) {
      this.setState({
        msg:"松手加载"
      });
    }
  }
    /**
   * 下拉加载
   * @return {[type]}
   */
    _scrollLoad() {
      let clientHeight = document.body.clientHeight;
      let scrollHeight = document.body.scrollHeight - document.body.scrollTop;
      if (!this.props.productStrategy.page || ((this.props.productStrategy.page.nextPage === this.props.productStrategy.page.pageNo) && (clientHeight >= scrollHeight ))) {
        // Notify.makeNotify('当前已是最后一页');
         this.setState({
            msg:""
          })
         return;
      }
      if (this.afterComponentCompleteUpdate && (clientHeight >= scrollHeight)) {

        this.props.productStrategyAction.fetchProductsStrategys({
          pageIndex: this.props.productStrategy.page.nextPage
        });
        this.setState({
          msg:"上拉加载更多数据"
        })
        this.afterComponentCompleteUpdate = false;

      }
    }

    /**页面渲染
     * @return {[type]}
     */
    render() {

      let {
        productStrategy
      } = this.props;

      return (
        < Content 
          className = { "product-strategy-container" }
          isMenubar = { false } > 
          <div className = "card-header strategy-title" >
            赢财富 - 热点追击 < /div> 
            <div >
              <div className = "blank30" > < /div> 
              <div className = "blank30" > < /div>
              {
                productStrategy.loader && !(productStrategy.results && productStrategy.results.length > 0)  ?
                  < div className = "loader-container" > 

                    { <Loader color="#e1bf6d" size="48px" /> } 

                 < /div> 
                :
                productStrategy.results && productStrategy.results.length > 0 ?

                  productStrategy.results.map((node, i) => < ProductStrategyItem key = {
                      i
                    }
                    productStrategyInfo = {
                      node
                    }/>)

                  :

                  <div>
                    <div 
                      className = {
                        this.showMessage ? "text-center padding-lg" : "hide"
                      } >
                      暂无消息信息 
                    </div> 
                  </div>

              } 
              <div 
                className = {
                  (productStrategy.results && productStrategy.results.length > 0) ? "" : "hide"
                } >
                <div className="text-center page-loading">
                  {
                    (!this.props.productStrategy.page || (this.props.productStrategy.page && (this.props.productStrategy.page.nextPage === this.props.productStrategy.page.pageNo))) ? 
                    ""
                    :
                    this.state.msg
                  }
                </div>
                <div className="blank30"></div>
                <div className="blank100"></div>
                <StrategyFooter / >

              </div>

            </div> 
        < /Content> 
        )
      }
    }



    export default connect(state => ({
      productStrategy: state.productstrategy
    }), dispatch => ({
      productStrategyAction: bindActionCreators(ProductStrategyAction, dispatch)
    }))(ProductStrategyApp);