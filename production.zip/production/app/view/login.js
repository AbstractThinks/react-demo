﻿import React from 'react';
import ReactDOM from 'react-dom';
import * as validator from '../common/validator';
import Notify from '../common/notification';
import * as UserAction from '../action/user';
import Content from '../component/content';
import { wxshare } from '../common/wxshare';
import { getDeviceType, auth } from '../common/util';
import {
  bindActionCreators
} from 'redux';
import {
  connect
} from 'react-redux';
import {
  Link
} from 'react-router';



class LoginApp extends React.Component {

  constructor(props) {
    super(props);
    this.displayName = 'LoginApp';
    //提示信息开关
    this.showTips = false;
    //账户默认类型
    this.state = {
      userAccount: 0,
	    textAccount: "资金账户"
    };
  }

  static contextTypes = {
    router: React.PropTypes.object.isRequired
  }
  /**
   * 在完成首次渲染之前调用
   * @return {[type]}
   */
  componentWillMount() {
  	if(this.isWeChat() === false) {
  		auth({ go: 'product' });
  	}
  }
  /**
   * 真实的DOM被渲染出来后调用
   * @return {[type]}
   */
  componentDidMount() {
  	this.refreshBodyStyle();
    this.refreshCaptcha();
    wxshare();
  }
  /**
   * 完成渲染新的props或者state后调用
   * @return {[type]}
   */
  componentDidUpdate() {

    let {
      status = 0, 
      message = "", 
      rscode = ""
    } = this.props.user;
    if (status === -1 && this.showTips) {
      let tips = message.match(/([\u4e00-\u9fa5].*[\u4e00-\u9fa5])+/)[0];
      Notify.makeNotify(tips);
      this.showTips = false;
      if(tips==="资金账号 为空 或者 openid 为空") {
        auth({ go: 'login' });
      } else {
        this.refreshCaptcha();
      }
    } else if (0 === status && "0" === rscode) {

      this.refreshBodyStyle('');

      this.context.router.push("/Product");
    }
    
  }
  /**
   * 验证是否微信打开
   * @return {[type]}
   */
  isWeChat(){
    let deviceInfo = getDeviceType();
    let isWeChat = deviceInfo.isWeChat;
    return isWeChat;
  }
  /**
   * 设置body背景样式
   * @param  {String}
   * @return {[type]}
   */
  refreshBodyStyle(style = 'body-login') {

    let thisBody = document.body;
    thisBody.className = style;

  }
  /**
   * 更新验证码
   * @return {[type]}
   */
  refreshCaptcha() {

    this.props.userAction.fetchCaptcha();

  }
  /**
   * 字段验证
   * @return {[type]}
   */
  validateLoginData() {

    let account = this.refs.txtAccount.value;
    if (account === '') {

      Notify.makeNotify("账号不能为空");
      return false;

    }
    if (!validator.accountValidator(account)) {

      Notify.makeNotify("账号格式不正确");
      return false;

    }
    let password = this.refs.txtPassword.value;
    if (password === '') {

      Notify.makeNotify("密码不能为空");
      return false;

    }
    if (!validator.passwordValidator(password)) {

      Notify.makeNotify("密码格式不正确");
      return false;

    }
    let captcha = this.refs.txtCaptcha.value;
    if (captcha === '') {

      Notify.makeNotify("验证码不能为空");
      return false;

    }
    if (!validator.captchaValidator(captcha)) {

      Notify.makeNotify("验证码格式不正确");
      return false;

    }
    return {
      username: account,
      password: password,
      captcha: captcha,
      accountType: this.state.userAccount
    };
  }
  /**
   * 账户输入框
   * @return {[type]}
   */
  renderAccountField() {
    return ( 
      < fieldset className = "form-group" >
        < label htmlFor = "" > {this.state.textAccount} < /label> 
        < input type = "tel"
        ref = "txtAccount"
        className = "form-control"
        maxLength = "12"
        placeholder = {
          this.state.placeholderTxt ||
          "请输入你的资金账户" 
        } / >
        <i
         className="ion-ios-close text-right"
         onClick={
          this.handleClearAccount.bind(this)
        } ></i>
      < /fieldset>
    );
  }
  /**
   * 密码输入框
   * @return {[type]}
   */
  renderPasswordField() {
    return ( 
      < fieldset className = "form-group" >
        < label htmlFor = "" > 密码 < /label> 
        < input type = "password"
        ref = "txtPassword"
        className = "form-control"
        maxLength = "6"
        placeholder = "请输入你的密码" / >
        <i
         className="ion-ios-close text-right" 
         onClick = { 
          this.handleClearPassword.bind(this)
        } ></i>
      < /fieldset>
    );
  }
  /**
   * 验证码输入框
   * @return {[type]}
   */
  renderCaptchaField() {
    let {
      captcha
    } = this.props;
    let captchaData = captcha.results;
    return ( 
      < fieldset className = "form-group" >
        < label htmlFor = "" > 验证码 < /label> 
        < input type = "tel"
        ref = "txtCaptcha"
        className = "form-control"
        maxLength = "4"
        id = "txtTicket"
        placeholder = "" / >
        < img id = "ticket"
          src = { captchaData }
          className = "img-ticket"
          onClick = {
            this.handleCaptchaClick.bind(this)
          }/> 
      < /fieldset>
    );
  }
  /**
   * 登录按钮
   * @return {[type]}
   */
  renderLoginField() {
    return ( 
      < fieldset className = "form-group login" >
        <div className="blank20"></div>
        < a className = "btn btn-dark btn-block"
          id = "btn-login"
          onClick = {
            this.handleLoginClick.bind(this)
          } >
          安全登录 
        < /a> 
      < /fieldset>
    );
  }
  /**
   * 注册按钮
   * @return {[type]}
   */
  renderRegisterField() {
    return ( 
      < fieldset className = "form-group register" >
        < div className = "text-center" >
          < a href = "javascript:;"
          id = "btn-account"
          onClick = {
            this.handleRegisterClick.bind(this)
          } >
            立即注册 
          < /a> 
        < /div> 
      < /fieldset>
    );
  }
  /**
   * 登陆逻辑
   * @return {[type]}
   */
  handleLoginClick() {

    let loginData = this.validateLoginData();
    if (loginData === false) {
      return;
    }
    this.showTips = true;
    this.props.userAction.login(loginData);
    

  }
  /**
   * 验证码更新逻辑
   * @return {[type]}
   */
  handleCaptchaClick() {

    this.refreshCaptcha();

  }
  /**
   * 注册逻辑
   * @return {[type]}
   */
  handleRegisterClick() {

    this.refreshBodyStyle('');
    setTimeout(function() {
      this.context.router.push("/Download");
    }.bind(this), 50);
    
  }
  /**
   * 切换账户类型逻辑
   * @return {[type]}
   */
  handleChangeAccount0() {
    if (this.state.userAccount === 10) {
      this.setState({
        userAccount: 0,
        textAccount: "资金账户",
        placeholderTxt:"请输入你的资金账户",
        cornerName:'move-r'
      })
    }
  }
  /**
   * 切换账户类型逻辑
   * @return {[type]}
   */
  handleChangeAccount10() {
    if (this.state.userAccount === 0) {
      this.setState({
        userAccount: 10,
        textAccount: "双融账户",
        placeholderTxt:"请输入你的双融账户",
        cornerName:'move-l'
      })
    }
  }
  /**
    清除用户框
   */
  handleClearAccount(){
    this.refs.txtAccount.value = '';
  }
  /**
    清除密码框
   */
  handleClearPassword(){
    this.refs.txtPassword.value = '';
  }
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {

    return ( 
      < Content isMenubar = { false } >
      {<div id="login-bg">
        <div id="login-logo"></div>
        < div className = "text-center btnGather"
                align = "middle" >
              < div 
                className = {
                  this.state.userAccount === 0 ? 
                  " btn-color btn-lt text-left" 
                  : 
                  " btn-trans btn-lt text-left"
                }
                id = "btn-normal"
                onClick = {
                  this.handleChangeAccount0.bind(this)
                } > 
                  普通账户 
                < /div> 
                < div 
                  className = {
                    this.state.userAccount === 10 ? 
                    "btn-color btn-rt text-right" 
                    : 
                    "btn-trans btn-rt text-right"
                  }
                  id = "btn-rzrq"
                  onClick = {
                    this.handleChangeAccount10.bind(this)
                  } > 
                  双融账户 
                < /div> 
                <div 
                className = {
                    this.state.cornerName || 'corner'
                  }
                id="corner" ref="corner"></div>
          < /div> 
      </div>} 
      { < div id = "login-panel" >
          < form >
          {
            this.renderAccountField()
          } 
          {
            this.renderPasswordField()
          } 
          {
            this.renderCaptchaField()
          } 
          {
            this.renderLoginField()
          } 
          {
            this.renderRegisterField()
          } 
        < /form> 
      < /div>
      } 
      < /Content>
    );
  }
}

export default connect(state => ({
  user: state.user,
  captcha: state.captcha
}), dispatch => ({
  userAction: bindActionCreators(UserAction, dispatch)
}))(LoginApp);