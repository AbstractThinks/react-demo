import * as StockAction from '../action/stock';
import * as UserAction from '../action/user';
import Loader from 'halogen/BounceLoader';
import UnlockBox from '../component/unlockBox';
import React from 'react';
import Notify from '../common/notification';
import StrategyFooter from '../component/footer';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { formatDate } from '../common/formater';
import { getUrl, auth } from '../common/util';
import { wxshare } from '../common/wxshare';
import * as types from './../constant/actiontype';

class StockReportDetailApp extends React.Component {
    constructor(props) {
        super(props);
        this.displayName = 'stockReportDetailApp';
        this.showNoMessage = false;
        this.showToastMessage = false;
        this.showLoader = true;
        this.firstRender = true;
        this.clickCount = 0;
        this.closeTimer = null;
        this.canSub = true;
        this.state = {
            enabledClick : true,
            btnText : "确定查看"
        }
        document.body.className = "";
    }
    /**
     * 真实的DOM被渲染出来后调用
     * @return {[type]}
     */
    componentDidMount() {
        let { id = 0 } = this.props.location.query;
        let { userinfo } = this.props;
        if (!userinfo.flag || !userinfo.results || (userinfo.results && userinfo.results.length === 0)) {
          this.props.userAction.getUserInfo({reset:300000, resetSource:types.RESET_USER_INFO});
        }
        // this.props.userAction.getUserInfo({});
        this.props.stockAction.fetchStockReport(id);
    }

    /**
     * 真实dom更新后被调用
     * @return {[type]}
     */
    componentDidUpdate() {
        if ( 401 === this.props.stockReportDetail.status ) {
            this.showNoMessage = false;
            let { id = 0 } = this.props.location.query;
            auth({ go: 'stockreportdetail', id: id });
        } else {
            this.showNoMessage = true;
            let { stockReportDetail } = this.props;
            if (stockReportDetail.unlockStatus !== 0 && stockReportDetail.unlockStatus !== 1 && this.showToastMessage) {
                Notify.makeNotify(stockReportDetail.message);
                this.showToastMessage = false;
            }
        }

    }
    componentWillReceiveProps(nextProps) {
        let { stockReportDetail } = nextProps;
        if(!stockReportDetail.loader && this.firstRender && typeof stockReportDetail.results!=='undefined' && typeof stockReportDetail.results[0]!=='undefined') {
            wxshare({
                link: getUrl({go: 'stockreportdetail', id: stockReportDetail.results[0].id}),
                msgContent: stockReportDetail.results[0].title
            });
            this.firstRender = false;
        }
        if(stockReportDetail.unlockStatus === 3) {
            this.setState({
                enabledClick : true,
                btnText : "确认查看"
            });
            this.canSub = true;
        }
    }
    clickControl() { 
        this.clickCount++;  //记录点击次数
        if(this.clickCount === 1){
            this.setState({
                enabledClick : false,
                btnText : "解锁中"
            });
            this.closeTimer = setTimeout(this.setOut.bind(this), 100);
        }
    }
    setOut() {  //点击执行事件
        clearTimeout(this.closeTimer);  //清除延时函数
        this.closeTimer = null;  //设置延时寄存为null
        this.onSubscribeClick();
        this.clickCount = 0;  //重置点击次数为0
    }
    /**
     * 确认解锁
     * @return {[type]}
     */
    onSubscribeClick() {
        let { id = 0 } = this.props.location.query;
        if (this.canSub) {
            this.props.stockAction.subStockReport(id);
            this.canSub = false;
            this.showToastMessage = true;
        }

    }
    /**
     * 是否显示隐藏内容
     * @return {[type]}
     */
    handleUnlockStatus() {
        let { stockReportDetail } = this.props;
        let isprivate = stockReportDetail.results[0].isprivate,
            islock = stockReportDetail.results[0].islock;

        if(isprivate === '1' && islock === '1') {
            return 'show';
        } else if(isprivate === '1' && islock !== '1') {
            return 'hide';
        }
        return 'none';
    }
    renderHeader() {
        let { stockReportDetail } = this.props;
        let stockReport = stockReportDetail.results[0];
        let updatetime = formatDate(stockReport.updatetime, "yyyy-MM-dd hh:mm") || "";
        
        return(
            <div>
                <div className = "message-header" >
                    <h5 > 
                        <b> { stockReport.title } </b>
                    </h5 >
                </div> 
                <div className = "message-stock" >
                    <h6> 
                        <span className="point"></span>{ `${stockReport.stockname} (${stockReport.stockcode})` } 
                    </h6>
                </div> 
                 <div className = "message-publictime" >
                    <small className = 'text-muted' > 
                        { `${updatetime} 发布` } 
                    </small>  
                </div>
            </div>
            );
    }
    renderFreeContent() {
        let { stockReportDetail } = this.props;
        return(
            <div>
                <div className = "strategy-content" dangerouslySetInnerHTML = {{__html: stockReportDetail.results[0].descript}}></div>
            </div>

        );
    }
    renderPrivateContent() {
        let { stockReportDetail } = this.props;
        let unlockStatus = this.handleUnlockStatus();
        return(
            <div>
                {
                    unlockStatus === 'show' ?

                        <div className = 'strategy-content' ref="privateContent">
                            <div className = 'strategy-unlock-title' >
                                <div className = 'strategy-unlock-title-line'> </div> 
                                <div className = 'strategy-unlock-title-text report-unlock-title-text text-center' >以下为研报精华内容</div> 
                            </div>
                            <div className = "" dangerouslySetInnerHTML = {{__html: stockReportDetail.results[0].private}}></div>
                        </div>
                        :
                        unlockStatus === 'hide' ?
                            <UnlockBox 
                                  detail = { this.props.stockReportDetail } 
                                  userinfo = { this.props.userinfo.results ? this.props.userinfo.results[0] : {} }
                                  onSubscribeClick = { this.clickControl.bind(this) } 
                                  enabledClick = { this.state.enabledClick } 
                                  btnText = { this.state.btnText }
                                  noticeText = { `-研报精华部分， 确定后立即查看-` } 
                                  unlockNum = { `已有${ stockReportDetail.results[0].unlocknum }人查看` } 
                                  lockType = { `Report` }/>
                            : 
                            null
                } 
            </div>
        );
    }
    /**
     * 页面渲染
     * @return {[type]}
     */
    render() {

        let { stockReportDetail } = this.props;

        return(
            <div> 
                { 
                    stockReportDetail.loader ?
                        <div className = "loader-container" > 
                            { 
                                <Loader color = "#e1bf6d"
                                    size = "48px" />
                            } 
                        </div>  
                        : 
                        stockReportDetail.results && stockReportDetail.results.length > 0 ?
                            <div className = "strategy-product" >
                                <div className = "blank30"></div> 
                                <div className = "card content-strategy-detail">
                                    { this.renderHeader() }
                                    { this.renderFreeContent() }
                                    { this.renderPrivateContent() }
                                </div> 
                                <div className = "blank30" > </div> 
                                <div className = "blank100" > </div> 
                                <StrategyFooter />
                                
                            </div>
                            :
                            <div>
                                <div className = "blank30"> </div>
                                <div className = "blank30"> </div> 
                                <div className = {this.showNoMessage ? "text-center padding-lg" : "hide"} >
                                    暂无研报详情
                                </div>
                            </div>
                } 
            < /div>    
        ) 
    }
}

export default connect(state => ({
    stockReportDetail: state.stockreportdetail,
    userinfo: state.userinfo
}), dispatch => ({
    stockAction: bindActionCreators(StockAction, dispatch),
    userAction: bindActionCreators(UserAction, dispatch)
}))(StockReportDetailApp);

