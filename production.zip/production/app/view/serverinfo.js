import React from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import Content from '../component/content';
import CardItem from '../component/cardItem';
import ShadowFollowFooter from '../component/shadowFollowFooter';
import { getUrl } from '../common/util';
import { wxshare } from '../common/wxshare';
import { resourceURI } from '../config/api';

class ServerInfoApp extends React.Component {

  constructor() {
    super();
    document.body.className = "strategy-bg serverinfo-bg";
  }
  componentDidMount(){
    wxshare();
  }
  __onImgLoadError(e){
    e.target.src = resourceURI+'img/photo.jpg';
    return false;
  }
  renderBaseContent(){
    let { stockItem={} } = this.props.location.state;
    return (
      <div className="server-info">
        <div className = "blank40"> </div>
        <div className="base-info">
          <img src={ stockItem.serverheadurl } className="server-photo" onError={ this.__onImgLoadError.bind(this) } />
          <div className = "blank10"> </div>
          <span>{ `姓名：${ stockItem.servername }` }</span> 
        </div>
        <div className="extra-info">
          <ul>
            <li>研究股票</li>
            <div className = "blank10"> </div>
            <li>{ `行业：${ stockItem.trades }` }</li>
            <div className = "blank10"> </div>
            <li>{`${ stockItem.stockname }(${ stockItem.stockcode })`}</li>
            <div className = "blank10"> </div>
            <li>{ `执业资格证书编号：${ stockItem.serverid }` }</li>    
          </ul>
        </div>
      </div>
    );
  }

  renderDescContent(){
    let { stockItem={} } = this.props.location.state;
    return (
      <div>
        <CardItem 
          headLeft = { `投资风格：` } 
          contentBody = { stockItem.serverdesc } />
        <CardItem 
          headLeft = { `专业背景：` } 
          contentBody = { stockItem.serverprof } />
      </div>
    );
  }

  render() {
    let stockItem;
    if(this.props.location.state) {
      stockItem  = this.props.location.state.stockItem;
    }
    return (
      < Content 
          className = { "product-strategy-container" }
          isMenubar = { false } > 
          {
            stockItem && stockItem.stockname ? 
              <div>
                { this.renderBaseContent() }
                { this.renderDescContent() }
                <div className = "blank30"> </div>
                <div className = "blank50"> </div>
                <ShadowFollowFooter />  
              </div>
              : 
              <div>
              </div>
          }
         
      </Content>
    );
  }
}

export default connect(state => ({

}), dispatch => ({

}))(ServerInfoApp);
