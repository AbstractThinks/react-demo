import React from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import * as StockAction from '../action/stock';
import * as UserAction from '../action/user';
import Content from '../component/content';
import StockItem from '../component/stockItem';
import { bindActionCreators } from 'redux';
import * as types from './../constant/actiontype';
import Loader from 'halogen/BounceLoader';
import ShadowFollowFooter from '../component/shadowFollowFooter';
import Notify from '../common/notification';
import { auth, getUrl } from '../common/util';
import { wxshare } from '../common/wxshare';

import { Link } from 'react-router';

class StockListApp extends React.Component {

  constructor() {
    super();
    this.state = {
      msg:"上拉加载更多数据",
      showCostView: false
    }
    document.body.className = "strategy-bg";
  }
  /**
   * 真实的DOM被渲染出来后调用
   * @return {[type]}
   */
  componentDidMount() {
    let { stock, userinfo } = this.props;
    if (!userinfo.flag || !userinfo.results || (userinfo.results && userinfo.results.length === 0)) {
      this.props.userAction.getUserInfo({reset:300000, resetSource:types.RESET_USER_INFO});
    }
    if (!stock.flag || !stock.results || (stock.results && stock.results.length === 0)) {
      this.props.stockAction.fetchStocks({loader:true, reset:300000, resetSource:types.RESET_STOCKS});
    }
    // if (!stockservers.flag || !stockservers.results || (stockservers.results && stockservers.results.length === 0)) {
    //   this.props.stockAction.fetchStockServers({opt:1, reset:3000, resetSource:types.RESET_STOCK_SERVERS});
    // }
    // this.props.stockAction.fetchStocks({loader:true});
    this.props.stockAction.fetchStockServers({opt: 1});
    this.props.stockAction.fetchStockCost();
    // this.props.userAction.getUserInfo({});
    let node = ReactDOM.findDOMNode(this);
    node.addEventListener('touchend', this._scrollLoad.bind(this), false);
    //node.addEventListener('touchmove', this._scrollMove.bind(this), false);
    this.afterComponentCompleteUpdate = true;
    wxshare();
  }
  componentWillUnmount() {
      let node = ReactDOM.findDOMNode(this);
      node.removeEventListener('touchend', this._scrollLoad.bind(this), false);
  }
  /**
   * 完成渲染新的props或者state后调用
   * @return {[type]}
   */
  componentDidUpdate() {
    if (this.props.stock.status === 401) {
      auth({ go: 'stocklist' });
    } else {
      this.afterComponentCompleteUpdate = true;
    }

  }
  /**
   * 下拉加载
   * @return {[type]}
   */
  _scrollLoad() {
    
    let clientHeight = document.body.clientHeight;
    let scrollHeight = document.body.scrollHeight - document.body.scrollTop;
    if (!this.props.stock.page || ((this.props.stock.page.nextPage === this.props.stock.page.pageNo) && (clientHeight >= scrollHeight ))) {
      // Notify.makeNotify('当前已是最后一页');
       this.setState({
          msg:""
        })
       return;
    }
    if (this.afterComponentCompleteUpdate && (clientHeight >= scrollHeight)) {

      this.props.stockAction.fetchStocks({
        pageIndex: this.props.stock.page.nextPage
      });
      this.setState({
        msg:"上拉加载更多数据"
      })
      this.afterComponentCompleteUpdate = false;

    }

  }

  subStock(stockId, pkgId, isSendSMS) {
    this.props.stockAction.subStock({stockId:stockId, pkgId:pkgId, isSendSMS:isSendSMS});
  }

  controlCostView() {
    this.setState(
      {
        showCostView : ! this.state.showCostView
      });
  }

  renderFeeCost(){
    let { stockcost } = this.props;
    return (
      <div>
        <div className="show-cost" onClick={this.controlCostView.bind(this)}>
          <span>{`${this.state.showCostView ? '隐藏' : '查看'}消费情况`}</span>
          <span className={this.state.showCostView ? "triangle-up" : "triangle-down"}></span>
        </div>
        <div className={`${this.state.showCostView ? '' : 'hide'} row fee-grid-container`}> 
          <Link to={ `feerecord` } query={{ recordType : "consume" }}>
            <div className="col-xs-4">
              <div className="row">
                <div className="col-xs-12 fee-number font-16">
                  { 
                    !stockcost.loader && stockcost.results ? 
                      stockcost.results.length > 0 ? 
                        stockcost.results[0].feevalue 
                        : "0.0" 
                    : "***.**" 
                  }
                </div>
                <div className="col-xs-12 fee-name font-14">
                  消费额
                </div>
              </div>
            </div>
          </Link>
          <Link to={ `feerecord` } query={{ recordType : "deduct" }}>
            <div className="col-xs-4 col-xs-border">
              <div className="row">
                <div className="col-xs-12 fee-number font-16">
                  { 
                    !stockcost.loader && stockcost.results ? 
                      stockcost.results.length > 0 ? 
                        stockcost.results[0].feededuct 
                        : "0.0" 
                    : "***.**" 
                  }
                </div>
                <div className="col-xs-12 fee-name font-14">
                  扣费额
                </div>
              </div>
            </div>
          </Link>
          <div className="col-xs-4">
            <div className="row">
              <div className="col-xs-12 fee-number-red font-16">
                { 
                  !stockcost.loader && stockcost.results ? 
                    stockcost.results.length > 0 ? 
                      stockcost.results[0].owevalue 
                      : "0.0" 
                  : "***.**" 
                  }
              </div>
              <div className="col-xs-12 fee-name font-14">
                欠款额
              </div>
            </div>
          </div>
        </div>
      </div>
      
    );
  }

  renderReportList(){
    let { stock, stockservers, userinfo } = this.props;
    return (
      <div> 
        {
          stock.loader ? 
            <div className = "loader-container"> 
              { <Loader color = "#e1bf6d" size = "48px" /> } 
            </div>
            : 
            stock.results && stock.results.length > 0 ?
              stock.results.map((stockItem, i) =>
                <StockItem 
                  stockItem = { stockItem }  
                  stockId = { stock[stockItem.id] }
                  subStock = { this.subStock.bind(this)} 
                  stockservers = { stockservers } 
                  userinfo = { userinfo.results ? userinfo.results[0] : {} }
                  key = { i }/>) 
                :
                <div className = "text-center padding-lg" >
                  <div className = "blank30" > < /div>
                  暂无股票信息 
                </div>
        }
        <div 
          className = {
            (!stock.loader && stock.results && stock.results.length > 0) ? "" : "hide"
          } >
          <div className="text-center page-loading">
            {
              (!this.props.stock.page || (this.props.stock.page && (this.props.stock.page.nextPage === this.props.stock.page.pageNo))) ? 
              ""
              :
              this.state.msg
            }
          </div>

        </div>
      </div>
    );
  }

  _preventDefualtEvent(event) {
    event.stopPropagation();
  }

  render() {
    return (
      < Content 
        className = { "product-strategy-container" }
        isMenubar = { false } >
        <div className = "strategy-title" > 
          <div className = "card-header stock-list-header" >
            <span className = "pull-left card-header-icon">
              <Link to={ `shadowfollowintro` } onTouchEnd={this._preventDefualtEvent.bind(this)}>
                  <i className="ion-ios-information-outline"></i>
              </Link>
            </span>
        		<span>如影随形服务</span>
            <span className = "pull-right card-header-icon">
              <Link to={ `stocksearch` } onTouchEnd={this._preventDefualtEvent.bind(this)}>
                  <i className="ion-ios-search"></i>
              </Link>
            </span>
          </div>
          { this.renderFeeCost() }
        </div>
        <div className = "blank50"> </div> 
        <div className = {this.state.showCostView ? "blank40" : "blank30"}> </div> 
        <div className={`${this.state.showCostView ? "" : "hide"} blank50`} > < /div> 

        { this.renderReportList() }
        <div className="blank30"></div>
        <div className="blank50"></div>
        <ShadowFollowFooter /> 
           
      </Content>
    );
  }
}

export default connect(state => ({
      stock: state.stock,
      stockservers: state.stockservers,
      userinfo: state.userinfo,
      stockcost: state.stockcost
    }), dispatch => ({
      stockAction: bindActionCreators(StockAction, dispatch),
      userAction: bindActionCreators(UserAction, dispatch)
    }))(StockListApp);
