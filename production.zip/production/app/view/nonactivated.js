import React from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import { Link } from 'react-router';
import { wxshare } from '../common/wxshare';

class NonActivatedApp extends React.Component {

  constructor () {
    super();
  }

  componentDidMount(){
    this.refreshBodyStyle();
    wxshare();
  }

  refreshBodyStyle( style = 'share-bg'){
    let thisBody = document.body;
    thisBody.className = style;
  }

  renderMainContent(){
      return (
        <div id="content">
            <div className="header">
                &nbsp;
            </div>
            <div className="content">
                <p>
                  <small>您所在的营业部尚未开通该功能，敬请期待！</small>
                </p>
            </div>
            <div className="footer">
                <Link to={`product`} className="btn btn-block btn-dark">
                  进入赢财富
                </Link>
            </div>
        </div>
      );
  }

  render() {

    return (
         <div>
            { this.renderMainContent() }
        </div>
    );
  }
}

export default connect(state => ({

}), dispatch => ({

}))(NonActivatedApp);
