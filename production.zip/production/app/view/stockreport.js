import React from 'react';
import ReactDOM from 'react-dom';
import { Link } from 'react-router';
import { connect } from 'react-redux';
import Content from '../component/content';
import CardItem from '../component/cardItem';
import Notify from '../common/notification';
import * as StockAction from '../action/stock';
import { bindActionCreators } from 'redux';
import * as types from './../constant/actiontype';
import Loader from 'halogen/BounceLoader';
import { formatDate } from '../common/formater';
import ShadowFollowFooter from '../component/shadowFollowFooter';
import { wxshare } from '../common/wxshare';

import { auth, getUrl } from '../common/util';

class StockReportApp extends React.Component {

  constructor() {
    super();
    document.body.className = "strategy-bg";
    this.state = {
      msg:"上拉加载更多数据"
    };
  }

  /**
   * 真实的DOM被渲染出来后调用
   * @return {[type]}
   */
  componentDidMount() {

    let { stockReports } = this.props;
    let { stockId = 0 } = this.props.location.query;

    // this.props.stockReportsAction.fetchStockReports({loader:true, stockId:stockId});
    if (!stockReports[stockId] || !stockReports[stockId].flag || !stockReports[stockId].results || (stockReports[stockId].results && stockReports[stockId].results.length === 0)) {
      this.props.stockReportsAction.fetchStockReports({loader:true, stockId:stockId, reset:300000, resetSource:types.RESET_STOCK_REPORTS});
    }

    let node = ReactDOM.findDOMNode(this);
    node.addEventListener('touchend', this._scrollLoad.bind(this), false);
    //node.addEventListener('touchmove', this._scrollMove.bind(this), false);
    this.afterComponentCompleteUpdate = true;
    wxshare();
  }
  componentWillUnmount() {
      let node = ReactDOM.findDOMNode(this);
      node.removeEventListener('touchend', this._scrollLoad.bind(this), false);
  }
  /**
   * 完成渲染新的props或者state后调用
   * @return {[type]}
   */
  componentDidUpdate() {
    let { stockId = 0 } = this.props.location.query;
    if (this.props.stockReports[stockId].status === 401) {
      auth({ go: 'stockreport', stockId: stockId });
    } else {
      this.afterComponentCompleteUpdate = true;
    }

  }
  /**
   * 下拉加载
   * @return {[type]}
   */
  _scrollLoad() {
    let { stockId = 0 } = this.props.location.query;
    let clientHeight = document.body.clientHeight;
    let scrollHeight = document.body.scrollHeight - document.body.scrollTop;
    if (!this.props.stockReports[stockId].page || ((this.props.stockReports[stockId].page.nextPage === this.props.stockReports[stockId].page.pageNo) && (clientHeight >= scrollHeight ))) {
      // Notify.makeNotify('当前已是最后一页');
       this.setState({
          msg:""
        })
       return;
    }
    if (this.afterComponentCompleteUpdate && (clientHeight >= scrollHeight)) {
      let { stockId = 0 } = this.props.location.query;
      this.props.stockReportsAction.fetchStockReports({
        stockId: stockId,
        pageIndex: this.props.stockReports[stockId].page.nextPage
      });
      this.setState({
        msg:"上拉加载更多数据"
      })
      this.afterComponentCompleteUpdate = false;

    }

  }

  renderReportList(){
    let { stockId = 0 } = this.props.location.query;
    let stockReports = this.props.stockReports[stockId] || {};
    return (

      <div>
        {
          stockReports.loader ? 
            <div className = "loader-container"> 
              { <Loader color = "#e1bf6d" size = "48px" /> } 
            </div>
            : 
            stockReports.results && stockReports.results.length > 0 ?
              stockReports.results.map((stockReportItem, i) =>
                <Link to={ `stockreportdetail` } query={{ id : stockReportItem.id }} key = { i }>
                  <CardItem 
                    headLeft = { `企业调研报告` } 
                    headRight = { formatDate(stockReportItem.updatetime, "yyyy-MM-dd hh:mm") || "" }
                    contentBody = { stockReportItem.title }
                    bottomLeft = { `点击查看` }
                    bottomRemark = { stockReportItem.islock === 1 ? `[已解锁：${ stockReportItem.unlocknum }人]` : null }
                    bottomRemarkClass = { `product-Strategy-update` }
                    bottomRight = { `>` } />
                </Link>) 
                :
                <div className = "text-center padding-lg" >
                  <div className = "blank30"> < /div>
                  暂无研报信息 
                </div>
        }
        <div 
          className = {
            (!stockReports.loader && stockReports.results && stockReports.results.length > 0) ? "" : "hide"
          } >
          <div className="text-center page-loading">
            {
              (!stockReports.page || (stockReports.page && (stockReports.page.nextPage === stockReports.page.pageNo))) ? 
              ""
              :
              this.state.msg
            }
          </div>

        </div>
      </div>
    );
  }

  renderHeader(){
    let { stockId = 0 } = this.props.location.query;
    let stockReports = this.props.stockReports[stockId] || {};
    return(
      !stockReports.loader && !(typeof stockReports.extraInfo === 'undefined') ? 
        <div className = "card-header strategy-title" > 
          <div className = "card-header-name">
            <span>服务股票</span>
          </div>
          <div className = "card-header-detail">
            <span>{ `${stockReports.extraInfo.stockname}(${stockReports.extraInfo.stockcode})` }</span>
            <div className="span-blank"></div>
            <span>{ `行业：${ stockReports.extraInfo.trades }` }</span>
          </div>
        </div>
        : 
        null  
      );
  }

  render() {
    return (
      
      < Content 
          className = { "product-strategy-container" }
          isMenubar = { false } >
          { this.renderHeader() }
          <div className = "blank30" > < /div> 
          <div className = "blank30" > < /div> 
          { this.renderReportList() }

          <div className="blank30"></div>
          <div className="blank50"></div>
          <ShadowFollowFooter /> 
      </Content>
    );
  }
}

export default connect(state => ({
      stockReports: state.stockreports
    }), dispatch => ({
      stockReportsAction: bindActionCreators(StockAction, dispatch)
    }))(StockReportApp);
