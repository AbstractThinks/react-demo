import React from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import Content from '../component/content';
import ShadowFollowFooter from '../component/shadowFollowFooter';
import { getUrl } from '../common/util';
import { wxshare } from '../common/wxshare';
import { resourceURI } from '../config/api';

class ShadowFollowIntroApp extends React.Component {

  constructor() {
    super();
    document.body.className = "strategy-bg";
  }
  componentDidMount(){
    wxshare();
  }

  renderMainContent(){
    return (
      <div className="shadow-follow-intro-card">
        <div className="intro-item">
          <div className="intro-item-photo">
            <img src={`${resourceURI}img/point.png`} />
          </div>
          <h5 className="intro-item-title">每日点评：</h5>
          <div className="intro-item-desc">
            <p>
              每个交易日（星期五除外）收盘后前对个股进行不限于当日走势，个股新闻，行业政策等内容的点评。
            </p>
          </div>
        </div>
        <div className = "blank20" > </div>
        <div className="intro-item">
          <div className="intro-item-photo">
            <img src={`${resourceURI}img/point.png`} />
          </div>
          <h5 className="intro-item-title">公告解读：</h5>
          <div className="intro-item-desc">
            <p>
              个股公告发布当日对公告内容、公告对上市公司及股价的影响等内容进行点评。
            </p>
          </div>
        </div>
        <div className = "blank20" > </div>
        <div className="intro-item">
          <div className="intro-item-photo">
            <img src={`${resourceURI}img/point.png`} />
          </div>
          <h5 className="intro-item-title">周回顾：</h5>
          <div className="intro-item-desc">
            <p>
              每个星期五收盘后对当周个股走势分析、后期观点等内容进行点评。
            </p>
          </div>
        </div>
      </div>
    );
  }

  render() {

    return (
      < Content 
          className = { "product-strategy-container" }
          isMenubar = { false } >
        <div className = "card-header strategy-title" > 如影随形服务介绍 </div>
        <div className = "blank30"> </div> 
        <div className = "blank30"> </div> 
        <div className = "blank30"> </div>
        { this.renderMainContent() }
        <div className = "blank50"> </div>
        <ShadowFollowFooter />   
      </Content>
    );
  }
}

export default connect(state => ({

}), dispatch => ({

}))(ShadowFollowIntroApp);
