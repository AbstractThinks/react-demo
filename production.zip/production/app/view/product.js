import React from 'react';
import * as ProductAction from '../action/product';
import * as UserinfoAction from '../action/user';
import Content from '../component/content';
import CopyRight from '../component/copyright';
import ProductItem from '../component/productItem';
import Loader from 'halogen/BounceLoader';
import { auth } from '../common/util';
import { wxshare } from '../common/wxshare';
import * as types from './../constant/actiontype';
import {
  bindActionCreators
} from 'redux';
import {
  connect
} from 'react-redux';
import {
  Link
} from 'react-router';
import {
  localStorageService
} from '../common/Storage';

class ProductApp extends React.Component {

  constructor () {
    super(); 
    this.showNoMessage = false;
    this.showFooterMessage = false;
    document.body.className = "";
  }
  componentWillMount() {
    // this.props.userinfoAction.getUserInfo();
  }
  /**
   * 真实的DOM被渲染出来后调用
   * @return {[type]}
   */
  componentDidMount(){
    let { userinfo } = this.props;
    if (!userinfo.flag || !userinfo.results || (userinfo.results && userinfo.results.length === 0)) {
      this.props.userinfoAction.getUserInfo({reset:300000, resetSource:types.RESET_USER_INFO});
    }
    this.props.productAction.fetchProducts();
    wxshare(); 
  }
  /**
   * 完成渲染新的props或者state后调用
   * @return {[type]}
   */
  componentDidUpdate(){
	 let { product } = this.props;
    if (this.props.product.status === 401) {
      auth({ go: 'product' });
    }
  }
  componentWillReceiveProps(nextProps) {
    let { product } = nextProps;
    if (product) {
      //存储签约数
      if(product.results && product.results.length > 0) {
        this.saveSubCount(product.results);
      }
    }
  }
  /**
   * 签约
   * @param  {[productItem]产品信息} 
   * @return {[type]}
   */
  productSubHandle(productItem){
    if(productItem && productItem.pmid){
      this.props.productAction.subProduct(productItem);
    }
  }
  /**
   * 退签
   * @param  {[productItem]chan}
   * @return {[type]}
   */
  productUnSubHandle(productItem){
    if(productItem && productItem.pmid){
      this.props.productAction.unsubProduct(productItem);
    }
  }
  /**
   * 存储用户签约数
   * @param  {[products]chan}
   * @return {[type]}
   */
  saveSubCount(products) {
    let currentUserSubCount = 0;
    for(let i = 0, len = products.length; i< len; i++){
      let item = products[i];
      //已签约 && 退签中
      if (item.status == "2") {
        currentUserSubCount++;
      }
    }
    localStorageService.set("subcount", currentUserSubCount);
  }
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {

    let { product, userinfo } = this.props;
    return (

        <Content menuIndex = { 0 } 
          className = { "product-container" }
          isMenubar = { true }>
          {
            product.loader ?
              <div className="loader-container">
                {
                  <Loader color="#e1bf6d" size="48px" /> 
                }
              </div> 
              :
              product.results && product.results.length > 0 ?
                product.results.map((productItem, i) => 
                
                  <ProductItem 
                      productItem = { productItem } 
                      pmid = { product[productItem.pmid] }
                      productSubHandle = { this.productSubHandle.bind(this) }
                      productUnSubHandle = { this.productUnSubHandle.bind(this) }
                      key={i}  
                      index = {i} 
                      length={product.results.length}
                      userinfo = {userinfo.results ? userinfo.results[0] : {}}/>
                   
                )
                :
                <div className={this.showNoMessage? "text-center padding-lg product-no-message" : "hide"}>
                  暂无产品信息
                </div>   
          }
          <div className="blank100"></div>
          <CopyRight />
        </Content>
    );
  }
}

export default connect(state => ({
  product : state.product, 
  userinfo : state.userinfo
}), dispatch => ({ 
  productAction : bindActionCreators(ProductAction, dispatch),
  userinfoAction : bindActionCreators(UserinfoAction, dispatch)
}))(ProductApp);

