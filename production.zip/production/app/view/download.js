import React from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import * as util from '../common/util';
import * as apis from '../config/api';
import Content from '../component/content';
import { resourceURI } from '../config/api';
import { wxshare } from '../common/wxshare';

class DownloadApp extends React.Component {

  constructor () {
    super();

    this.state = {
      isWechatMaks : false
    };
  }

  componentDidMount(){
    this.refreshBodyStyle("body-download hide");
    this.initPageDownload();
    wxshare({hideAll:false});
  }

  initPageDownload(){
    let deviceInfo = util.getDeviceType();
    let isWeChat = deviceInfo.isWeChat,
        isIOS = deviceInfo.isIOS;
    
    if(isWeChat === true){
        this.refreshBodyStyle();
    }else{
        if(isIOS === true){
            window.location = apis.hxaccount_download_ios_url;
        }else{
            window.location = apis.hxaccount_download_android_url;
        }
    }
  }

  refreshBodyStyle( style = 'body-download'){
    let thisBody = document.body;
    thisBody.className = style;
  }

  renderMainContent(){
      return (
          <div id="content">
              <div className="header">
                  <img src={`${resourceURI}img/logo.png`} alt="" className="img-responsive" />
              </div>
              <div className="content">
                  <p>
                  成为华西证券客户
                  </p>
                  <p>
                  尊享赢财富服务
                  </p>
              </div>
              <div className="footer">
                  <a href="javascript:void(0);"
                    onClick = { this.handleDownloadClick.bind(this) }
                    className="btn btn-block btn-warning" id="btn-account">
                    立即开户
                  </a>
              </div>
          </div>
      );
  }

  renderWechatMask(){
    let deviceInfo = util.getDeviceType();
    return (
      <div id="wechat-mask" onClick={ this.handleWechatMaskClick.bind(this) }>
          <div className="wechat-content">
              <div>
                  {
                    deviceInfo.isIOS === true ?
                    <img src={`${resourceURI}img/wechat-ios.png`} id="img-device"/>
                    :
                    <img src={`${resourceURI}img/wechat-android.png`} id="img-device"/>
                  }
              </div>
              {
                /*
                  下面这种写法是有问题的
                */
              }
              <img src={`${resourceURI}img/wechat-arrow.png`} />
          </div>
      </div>
    );
  }

  renderCopyright(){
    return (
      <div className="copyright bottomest">
          <p className="text-center">
          <small>
              华西证券股份有限公司
          </small>
          </p>
      </div>
    );
  }

  handleWechatMaskClick(){
    this.setState({
      isWechatMaks : false
    });
  }

  handleDownloadClick(){
    this.setState({
      isWechatMaks : true
    });
  }

  render() {

    return (
         <div>
            { this.renderMainContent() }
            { this.renderCopyright() }
            {
                this.state.isWechatMaks === true?
                this.renderWechatMask()
                : null
            }
        </div>
    );
  }
}

export default connect(state => ({

}), dispatch => ({

}))(DownloadApp);
