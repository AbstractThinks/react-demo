import React from 'react';
import * as apis from '../config/api';
import * as formater from '../common/formater';
import * as MessageAction from '../action/message';
import Content from '../component/content';
import Loader from 'halogen/BounceLoader';
import StrategyFooter from '../component/footer';
import { auth } from '../common/util';
import { wxshare } from '../common/wxshare';
import {
  bindActionCreators
} from 'redux';
import {
  connect
} from 'react-redux';
import {
  Link
} from 'react-router';

class MessageDetailApp extends React.Component {

  constructor(props) {
    super(props);
    this.showNoMessage = false;
    document.body.className = "";
  }
  /**
   * 真实的DOM被渲染出来后调用
   * @return {[type]}
   */
  componentDidMount() {
    let { id, type } = this.props.location.query;
    this.props.messageAction.fetchMessage({ id, type });
    
    wxshare(); 
  }
  /**
   * 完成渲染新的props或者state后调用
   * @return {[type]}
   */
  componentDidUpdate() {

    if (this.props.messagedetail.status === 401) {
        let { id = 0, type = 0 } = this.props.location.query;
        auth({ go: 'messagedetail', id: id, type: type });
    } else {
        this.showNoMessage = true; 
    }
  }
  /**
   * 消息头部信息结构
   * @return {[type]}
   */
  renderMessageTitle() {
    let {
      messagedetail
    } = this.props;

    let title = "";

    if (messagedetail && messagedetail.results && messagedetail.results.length > 0) {
      let messageType = Number(messagedetail.results[0].type);
      if (messageType === 1 || messageType === 4) {
        title = "点评消息";
      } else if (messageType === 2) {
        title = "调入消息";
      } else {
        title = "调出消息";
      }
    }

    return ( 

      < h4 className = "message-title" > 
        { title } 
      </h4>);
  }
  /**
   * 消息类容结构
   * @return {[type]}
   */
  renderMessageContent() {
    let {
      messagedetail
    } = this.props;

    let messageInfo = formater.messageItemFormater(messagedetail.results[0]);
    let messageType = Number(messageInfo.type);
    let stockInfoApi = String.format(apis.stock_info_api, messageInfo.stockcode, messageInfo.stockarea);
    let messageOpText = '',
      messageOpLink = '';
    if (messageType === 2) {
      messageOpText = '快捷买入';
      messageOpLink = String.format(apis.stock_buy_api, messageInfo.stockcode, messageInfo.stockarea);
    } else if(messageType === 3) {
      messageOpText = '快捷卖出';
      messageOpLink = String.format(apis.stock_sell_api, messageInfo.stockcode, messageInfo.stockarea);
    }

    return ( 

      < div className = "message-content" >
          {
            messageInfo.stockcode !== '' ?
              <div className="content-title">
                <a
                  className = "title-link"
                  href = {
                    stockInfoApi
                  } >
                  { messageInfo.stockname }
                  <span>&nbsp;({ messageInfo.stockcode })</span>
                </a>
                <label>{ messageInfo.createtime }</label>
              </div>
              :
              null
          }
        < p 
          dangerouslySetInnerHTML = {
          {
            __html: messageInfo.content
          }
        } >
        </p>
        {
          messageType === 4 ? 
            <div>
              < label className='no-margin-bottom'> 
                {`华西证券${messageInfo.dwmc}${messageInfo.sendtype == '3' ? `投顾${messageInfo.cname}` : ''}`}
              < /label>
              < label className='no-margin-bottom'> 
                {`${messageInfo.sendtype == '3' ? `执业证书编号：${messageInfo.tzzxnum}` : ''}`}
              < /label>
            </div>
          : 
          null
        }

        {
          messageType === 3 || messageType === 2 ?
            < a
              id = "btn-op"
              href = { messageOpLink }
              className = "btn btn-block btn-dark"
              >

              {
                messageOpText
              }

            </a>
            :
            null
        }

      </div>

    );
  }
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {

    let {
      messagedetail
    } = this.props;
    return ( 

      < Content 
        className = { "message-container message-detail" }
        isMenubar = { false } >
        {
          messagedetail.loader ?
            <div className = "loader-container" >

              { <Loader color="#e1bf6d" size="48px" /> } 

           </div>
          : 
          messagedetail.results && messagedetail.results.length>0 ?
            < div > 
              { this.renderMessageTitle() } 
              { this.renderMessageContent()} 
              < div className = "blank30" > </div>
              < div className = "blank100" > </div>
              {
                messagedetail.results[0].type == '4' && messagedetail.results[0].sdwmc!=='' ? 
                  <div className="data-source text-center">
                    <p>{`本信息来源华西证券${messagedetail.results[0].sdwmc}`}</p>
                  </div>
                  :
                  null
              }
              <StrategyFooter /> 
            </div>
            :
            <div
              className = {
                this.showNoMessage ? "text-center padding-lg message-gray" : "hide"
              }>
              < div className = "blank40" >  </div>
              暂无消息信息 
            </div>
        } 
      </Content>
    );
  }
}

export default connect(state => ({
  messagedetail: state.messagedetail
}), dispatch => ({
  messageAction: bindActionCreators(MessageAction, dispatch)
}))(MessageDetailApp);