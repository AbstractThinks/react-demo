import React from 'react';
import Content from '../component/content';
import Notify from '../common/notification';
import Loader from 'halogen/BounceLoader';
import ServerItem from '../component/serverItem';
import PushChoiceItem from '../component/pushChoiceItem';
import Modal from 'boron/ScaleModal';
import ProtocalUse from '../component/modal/protocalUse';
import ProtocolSF from '../component/modal/protocolsf';
import ProtocolRisk from '../component/modal/protocolrisk';
import ModalStockConfirmModify from '../component/modal/stockconfirmmodify';
import ModalStockConfirmUnsub from '../component/modal/stockconfirmunsub';
import ShadowFollowFooter from '../component/shadowFollowFooter';
import { connect } from 'react-redux';
import * as StockAction from '../action/stock';
import * as UserAction from '../action/user';
import { bindActionCreators } from 'redux';
import { auth, getUrl } from '../common/util';
import { wxshare } from '../common/wxshare';
import * as types from './../constant/actiontype';

import ModalRiskNotMatch from '../component/modal/risknotmatch';
import ModalReVisit from '../view/revisit';

import { checkRiskLevel,reVisit } from '../config/common';

class StockModifyApp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            protocolStatus : true,
	        tipSureDanger : false,
            active : 0,
            modalBackdrop: true,
            modalClass: "modal-container",
            modalContent: null,
            modalProtocalBackdrop: false,
            modalProtocalContent: null,
            modalProtocalClass: "modal-container-full modal-protocal",
            fee : 0,
            isSendSMS : false
	    };
        this.pkgIndex = 0;
        this.showUnSubMessage = false;
        this.showModifyMessage = false;
        this.enabledClick = true;
        this.enabledUnsubClick = true;
        this.firstRender = true;
	    document.body.className = "strategy-bg";
    }
    /**
    * 真实的DOM被渲染出来后调用
    * @return {[type]}
    */
    componentDidMount() {
        let { stockId = 0 } = this.props.location.query; 
        let { userinfo } = this.props;
        if (!userinfo.flag || !userinfo.results || (userinfo.results && userinfo.results.length === 0)) {
          this.props.userAction.getUserInfo({reset:300000, resetSource:types.RESET_USER_INFO});
        }
        // this.props.userAction.getUserInfo({});
        this.props.stockAction.fetchStockServers({stockId: stockId, opt: 3}); 
        wxshare();
    }
    /**
    * 完成渲染新的props或者state后调用
    * @return {[type]}
    */
    componentDidUpdate() {
        if (this.props.stockservers.status === 401 || this.props.stock.status === 401) {
            let { stockId = 0 } = this.props.location.query;
            auth({ go: 'stockmodify', stockId: stockId });
        } else {
            let { stock } = this.props;
            let { stockId = 0 } = this.props.location.query;
            let pmid = stock[stockId];
            if (typeof pmid!=='undefined' && pmid.unsub_status && this.showUnSubMessage) {
                if(pmid.unsub_status !== 1) {
                    Notify.makeNotify(pmid.message, 1.5);
                    this.showUnSubMessage = false;
                }
                //退签成功
                if(pmid.unsub_status === 2) {
                    this.props.history.go(-2);
                }
                //退签失败
                if(pmid.unsub_status === 3) {
                    this.enabledUnsubClick = true;
                }
            }
            if (typeof pmid!=='undefined' && pmid.modify_status && this.showModifyMessage) {
                if(pmid.modify_status !== 1) {
                    Notify.makeNotify(pmid.message, 1.5);
                    this.showModifyMessage = false;
                }
                //修改成功
                if(pmid.modify_status === 2) {
                    this.props.history.go(-1);
                }
                //修改失败
                if(pmid.modify_status === 3) {
                    this.enabledClick = true;
                }
            }
        }
    }
    componentWillReceiveProps(nextProps) {
        //首次加载初始化签约状态
        let { stockservers } = nextProps;
        if(stockservers.loader === false && typeof stockservers.extraInfo!='undefined' && stockservers.results.length > 0 && this.firstRender) {
            this.firstRender = false;
            this.setState(
            {
                active: stockservers.extraInfo.packageid,
                fee: parseFloat(stockservers.extraInfo.feevalue),
                isSendSMS: stockservers.extraInfo.issendsms === "1" ? true : false
            }); 
        }
    }

    /**
     * 确认协议信息修改
     * @return {[type]}
     */
    handleProtocolChange(){
	    let currentStatus = !this.state.protocolStatus;
	    this.setState({
	        protocolStatus:currentStatus
	    });
	    if (currentStatus) {
	        this.setState({tipSureDanger:false});
	    }
    }
    /**
     * 点击修改
     * @return {[type]}
     */
    handleSure(e){
        e.preventDefault();
        e.stopPropagation();
        if(this.enabledClick && this.enabledUnsubClick) {
            let { stockservers,userinfo } = this.props;
            if(checkRiskLevel){
                let clientrisklevel = userinfo.results[0].clientrisklevel;
                let rinklevel = stockservers.extraInfo.rinklevel;
                let riskMatch = clientrisklevel >= rinklevel ? true : false;
                if(!riskMatch) {
                  let modalContent = 
                  <ModalRiskNotMatch 
                    onCloseClick = { this.onModalClose.bind(this) } />;
                  this.setState({
                    modalBackdrop : true,
                    modalClass : "modal-container",
                    modalContent : modalContent
                  });
                  this.refs.modalStock.show();
                  return;
                }
            }
            if(stockservers.results && stockservers.results.length > 0 && this.state.protocolStatus) {

                let modalContent = null;
                modalContent = 
                    <ModalStockConfirmModify 
                        onSureClick = { this.onSureClick.bind(this) }
                        onCloseClick = { this.onModalClose.bind(this) } />

                this.setState({
                    modalBackdrop : true,
                    modalClass : "modal-container",
                    modalContent : modalContent
                });

                this.refs.modalStock.show();
            }
            if(!this.state.protocolStatus) {
              this.setState({tipSureDanger:true});
            }      
        }
    }
    /**
     * 点击退订
     * @return {[type]}
     */
    handleUnsubSure(e){
        e.preventDefault();
        e.stopPropagation();
        if(this.enabledUnsubClick && this.enabledClick && this.state.protocolStatus) {

            let modalContent = null;
            modalContent = 
                <ModalStockConfirmUnsub 
                    onSureClick = { this.onSureUnsubClick.bind(this) }
                    onCloseClick = { this.onModalClose.bind(this) } />

            this.setState({
                modalBackdrop : true,
                modalClass : "modal-container",
                modalContent : modalContent
            });

            this.refs.modalStock.show();
        }
        if(!this.state.protocolStatus) {
          this.setState({tipSureDanger:true});
        }
    }
    /**
     * 确认修改
     * @return {[type]}
     */
    onSureClick() {
        if (this.state.protocolStatus) {
            let {stockservers} = this.props;
            let isrevisit = stockservers.extraInfo.isrevisit;
            if(reVisit && isrevisit!=1){
                let modalContent = null;
                modalContent = <ModalReVisit 
                  onSuccessHandler = { this.onSuccessHandler.bind(this) }
                  isNewUser = { true }
                  pmid = {"1588021"}/> 
                
                this.setState({
                  modalProtocalContent : modalContent
                });

                this.refs.modalStock.hide();
                this.refs.modalProtocal.show();

                return;
            } else {
                this.enabledClick = false;
                let { stockId = 0 } = this.props.location.query;
                this.props.stockAction.modifyStock({stockId:stockId, pkgId:this.state.active, isSendSMS:this.state.isSendSMS ? 1 : 0});
                this.showModifyMessage = true;
                this.refs.modalStock.hide();
            }
        }

    }
    //回访成功后的操作
    onSuccessHandler() {
        this.enabledClick = false;
        let { stockId = 0 } = this.props.location.query;
        this.props.stockAction.modifyStock({stockId:stockId, pkgId:this.state.active, isSendSMS:this.state.isSendSMS ? 1 : 0});
        this.showModifyMessage = true;
        this.refs.modalProtocal.hide();
    }
    /**
     * 确认退订
     * @return {[type]}
     */
    onSureUnsubClick() {
        this.enabledUnsubClick = false;
        let { stockId = 0 } = this.props.location.query;
        this.props.stockAction.unSubStock(stockId);
        this.showUnSubMessage = true;
        this.refs.modalStock.hide();

    }
    /**
     * 关闭modal
     * @return {[type]}
     */
    handleClose(){
        this.refs.modalProtocal.hide();
    }
    /**
     * 打开协议modal
     * @return {[type]}
     */
    handleOpenProtocal({protocolType, showDate=true, btnText="确认并同意以上规则"}={}){
        let { userinfo } = this.props;
        let modalContent = 
            protocolType === "use" ? 
                <ProtocalUse 
                    onCloseClick = { this.handleClose.bind(this) } 
                    userinfo = { userinfo.results ? userinfo.results[0] : {} } 
                    showDate = { showDate }
                    btnText = { btnText }/> 
                : 
                protocolType === "sf" ? 
                    <ProtocolSF 
                        onCloseClick = { this.handleClose.bind(this) } 
                        userinfo = { userinfo.results ? userinfo.results[0] : {} } 
                        showDate = { showDate }
                        btnText = { btnText }/>
                    : 
                    protocolType === "risk" ? 
                        <ProtocolRisk 
                            onCloseClick = { this.handleClose.bind(this) } 
                            userinfo = { userinfo.results ? userinfo.results[0] : {} } 
                            showDate = { showDate }
                            btnText = { btnText }/>
                        : 
                        null
        this.setState({
            modalProtocalContent: modalContent
        });
        this.refs.modalProtocal.show();  
    }
    /**
    * 关闭弹出框
    * @return {[type]}
    */
    onModalClose(){
        this.refs.modalStock.hide();
    }

    handleChoice(i) {
      this.setState(
        {
            active: this.props.stockservers.results[i].id,
            fee: this.state.isSendSMS ? parseFloat(this.props.stockservers.results[i].feevalue) + parseFloat(this.props.stockservers.results[i].smsvalue) : parseFloat(this.props.stockservers.results[i].feevalue)
        });
      this.pkgIndex = i;
    }
    handlePushChoice(i) {
      this.setState(
        {
            isSendSMS: !this.state.isSendSMS,
            fee: !this.state.isSendSMS ? parseFloat(this.props.stockservers.results[this.pkgIndex].feevalue) + parseFloat(this.props.stockservers.results[this.pkgIndex].smsvalue) : parseFloat(this.props.stockservers.results[this.pkgIndex].feevalue)
        });
    }
    renderStockServer(serverItem, i, length){
        return (
            <li key = { i } onClick = { this.handleChoice.bind(this, i) }>
                <ServerItem
                    serverItem = { serverItem } 
                    index = { serverItem.id } 
                    active = { this.state.active }
                    single = { length === 1 ? true : false }  
                    opt = { "unsub" } />
            </li>
        )
    }

    renderStockServers(){
        let { stockservers } = this.props;
        if (stockservers.results && stockservers.results.length > 0) {
            return (
                    <ul className = { stockservers.results.length ===1 ? "single-server-item-chioces" : "server-item-chioces" }>
                        {
                            stockservers.results.map((serverItem, i) =>
                                
                                this.renderStockServer(serverItem, i, stockservers.results.length)
                                
                            )
                        }   
                        <div></div>
                    </ul>
                );
            
        }else {
            return null
        }
    }

    renderMainContent(){
        let { stockservers } = this.props;
    	return (
          typeof stockservers.extraInfo != 'undefined' ? 
    	      <div className="shadow-follow-intro-card stocksubscribe-modal strategy-modal stock-modify animated zoomIn">
    	        {/*
                    <h2 className = {'stock-sub-modal-header'}>
                        请选择相关服务包
                    </h2>
                    <div className = "blank20"> </div>
                */}
                <div className = {'modal-content'}>
                    { this.renderStockServers() }
                    {/*
                        <ul className = "push-item-chioces">
                            <li key = { 0 } >
                                <PushChoiceItem text = { `微信推送(必选)` } index = { 0 } isMustChoice = { true }/>
                            </li>
                            <li key = { 1 } onClick = { this.handlePushChoice.bind(this, 1) } >
                                <PushChoiceItem text = { `短信推送(另收费)` } index = { 1 } isMustChoice = { false } isChoiced = { this.state.isSendSMS } />
                            </li>
                            <div></div>
                        </ul>
                    */}
                    <p className="money-notice">服务费用：<span className="money-number">{`${this.state.fee}元`}</span>/月</p>
                    <p className="text-center">(微信推送)</p>
                    <div className="blank10"></div>
                    <p>
                      <input 
                        type="checkbox" 
                        className="check-protocol" 
                        checked={this.state.protocolStatus}
                        onChange = { this.handleProtocolChange.bind(this) }/>
                      <small>
                        &nbsp;我已阅读并同意
                      </small>
                      <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocal.bind(this, {protocolType: "use"})}>
                        《华西证券股份有限公司证券投资咨询产品使用协议》
                      </a>
                      &nbsp;<small>、</small>&nbsp;
                      <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocal.bind(this, {protocolType: "sf"})}>
                        《“赢财富如影随形”证券投资咨询产品服务协议》
                      </a>
                      &nbsp;<small>及</small>&nbsp;
                      <a href="javascript:void(0)" className="link-protocol" onClick = {this.handleOpenProtocal.bind(this, {protocolType: "risk"})}>
                        《“赢财富”风险揭示》
                      </a>
                    </p>
                    <p ref="tipSureDanger" className={this.state.tipSureDanger?"text-danger":"hide"}>
                      请先确认阅读并同意
                    </p>
                </div>
                {/*   
                    <div className = "blank20"> </div>
                    <div className={'modal-footer'}>
                      <button className={'btn btn-block btn-dark'} onClick={ this.handleSure.bind(this) }>修改服务内容</button>
                    </div>
                */}
                <div className = "blank20"> </div>
                <div className="stock-cancel">
                    <a className="text-underline text-stock-cancel" onClick={ this.handleUnsubSure.bind(this) }>退订内容</a>
                </div>
    	      </div>
              :
              null
	    );
    }
    /**
     * 页面渲染
     * @return {[type]}
     */
    render() {
        let { stockservers } = this.props;
        return (
        	<Content 
	          className = { "product-strategy-container" }
	          isMenubar = { false } >
              
                <div>
                    <div className = "blank30"> </div>
                    {
                        typeof stockservers.loader === 'undefined' || stockservers.loader === true ? 
                            <div className = "loader-container"> 
                              { <Loader color = "#e1bf6d" size = "48px" /> } 
                            </div>
                            :
                            this.renderMainContent()
                    }
                    <div className="blank50"></div>
                    <ShadowFollowFooter /> 

                    <Modal ref="modalStock" 
                        backdrop = { this.state.modalBackdrop }
                        className= { this.state.modalClass }>
                            { this.state.modalContent }
                    </Modal>
                    <Modal ref = "modalProtocal"
                        backdrop = {
                            this.state.modalProtocalBackdrop
                        }
                        className = {
                            this.state.modalProtocalClass
                        } > {
                            this.state.modalProtocalContent
                        } 
                    </Modal>
                </div>
              
	        </Content>
        )
    }
}

export default connect(state => ({
      stockservers: state.stockservers,
      stockMessages: state.stockmessages,
      userinfo: state.userinfo,
      stock: state.stock
    }), dispatch => ({
      stockAction: bindActionCreators(StockAction, dispatch),
      userAction: bindActionCreators(UserAction, dispatch)
    }))(StockModifyApp);
