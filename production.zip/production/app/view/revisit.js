import React from 'react';
import * as UserAction from '../action/user';
import Content from '../component/content';
import QuestionItem from '../component/questionItem';
import Loader from 'halogen/BounceLoader';
import { auth } from '../common/util';
import { wxshare } from '../common/wxshare';
import Notify from '../common/notification';
import {
  bindActionCreators
} from 'redux';
import {
  connect
} from 'react-redux';
import {
  Link
} from 'react-router';

class ReVisitApp extends React.Component {

  constructor(props) {
    super(props);
    this.showNoMessage = false;
    this.showNotify = false;
    document.body.className = "";
    this.results = [];
    this.optionCheck = [];
    this.firstRender = true;
    this.state = {
      btnEnabled : false
    };
  }
  static contextTypes = {
    router: React.PropTypes.object.isRequired
  }
  /**
   * 真实的DOM被渲染出来后调用
   * @return {[type]}
   */
  componentDidMount() {
    this.props.userAction.getReVisit();
    let {isNewUser=false} = this.props;
    if(!isNewUser) {
      wxshare();
    }
  }
  /**
   * 完成渲染新的props或者state后调用
   * @return {[type]}
   */
  componentDidUpdate() {
    if (this.props.revisit.status === 401) {
      let {isNewUser=false} = this.props;
      if(!isNewUser) {
        auth({ go: 'revisit' });
      }else {
        auth({ go: 'product' });
      }
    } else {
      this.showNoMessage = true; 
      let {revisit} = this.props;
      let {status, message} = revisit;
      if(status && status!==0 && this.showNotify) {
        if(status!==1){
          Notify.makeNotify(message, 1.5);
        }
        if(status===1) {
          let {onSuccessHandler} = this.props;
          if(typeof onSuccessHandler !== 'undefined'){
            onSuccessHandler();
            return;
          }
          this.context.router.push("/Product");
        }
        this.showNotify = false;
        this.setState({
          btnEnabled: true
        });
      }
    }
  }
  // 初始化选择结果
  componentWillReceiveProps(nextProps) {
    let { revisit } = nextProps;
    if(revisit.results && revisit.results.length > 0 && this.firstRender) {
      this.results = new Array(revisit.results.length).fill("C");
      this.optionCheck = new Array(revisit.results.length).fill(false);
      this.firstRender = false;
    }
  }
  // 记录选择结果
  changeChoice(i,value,optionCheck) {
    this.results[i]=value;
    this.optionCheck[i]=optionCheck;
    if(this.optionCheck.indexOf(false)<0) {
      this.setState({
        btnEnabled: true
      });
    }else {
      this.setState({
        btnEnabled: false
      });
    }
  }
  // 提交问卷
  submitHandler() {
    if(this.state.btnEnabled) {
      this.setState({
        btnEnabled: false
      });
      this.showNotify = true;
      let pmid = this.props.pmid;
      let resultString = this.results.toString().replace(/,/g,"");
      this.props.userAction.commitReVisit({ pmid: pmid, results: resultString });

    }
  }
  /**
   * 头部信息结构
   * @return {[type]}
   */
  renderTitle() {
    return(
      <div className = "revisit-header">
        <div className = "revisit-header-title text-center" >
          <h5 > 
            <b>投资咨询产品客户回访</b>
          </h5 >
        </div>
      </div>
    );
  }
  /**
   * 问题内容结构
   * @return {[type]}
   */
  renderContent() {
    let { revisit, isNewUser=false } = this.props;

    return ( 
      <div className = "question-content">
        {
          revisit.results && revisit.results.length > 0 ?
            revisit.results.map((node, i) => 
              <QuestionItem 
                key = { i } 
                questionItem = { node } 
                changeChoice = {this.changeChoice.bind(this, i) } 
                  warn = { isNewUser }
                />)
            : 
            null
        }
      </div>

    );
  }
  /**
   * 提交按钮结构
   * @return {[type]}
   */
  renderButton() {
    return(
      <a className={`btn btn-block btn-dark btn-bottom ${this.state.btnEnabled&&!this.showNotify?"":"disabled"}`} onClick={this.submitHandler.bind(this)}>
         提交
      </a>
    );
  }
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {
    let { revisit } = this.props;
    return ( 
      <div className = "full-height">
        <div className = "message-container revisit-container">
          {
            revisit.loader ?
              <div className = "loader-container">

                { <Loader color="#e1bf6d" size="48px" /> } 

             </div>
            : 
            revisit.results && revisit.results.length>0 ?
              <div> 
                { this.renderTitle() } 
                { this.renderContent() }
                <div className = "blank50"> </div>
                { this.renderButton() }
              </div>
              :
              <div
                className = {
                  this.showNoMessage ? "text-center padding-lg message-gray" : "hide"
                }>
                < div className = "blank40" >  </div>
                暂无回访信息 
              </div>
          } 
        </div>  
      </div>
    );
  }
}

export default connect(state => ({
  revisit: state.revisit
}), dispatch => ({
  userAction: bindActionCreators(UserAction, dispatch)
}))(ReVisitApp);