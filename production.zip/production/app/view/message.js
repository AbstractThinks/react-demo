import React from 'react';
import ReactDOM from 'react-dom';
import * as formater from '../common/formater';
import * as MessageAction from '../action/message';
import Content from '../component/content';
import MessageItem from '../component/messageItem';
import Loader from 'halogen/BounceLoader';
import Notify from '../common/notification';
import { auth } from '../common/util';
import { wxshare } from '../common/wxshare';
import {
  bindActionCreators
} from 'redux';
import {
  connect
} from 'react-redux';
import {
  Link
} from 'react-router';
import {
    localStorageService
} from '../common/Storage';
import * as types from './../constant/actiontype';


class MessageApp extends React.Component {

  constructor(props) {

    super(props);
    this.showNoMessage = true;
    this.state = {
      msg:"上拉加载更多数据"
    }
    document.body.className = " message-container-bg";
  }
  /**
   * 真实的DOM被渲染出来后调用
   * @return {[type]}
   */
  componentDidMount() {

    let { message } = this.props;

    if (!message.flag || !message.results || (message.results && message.results.length === 0)) {
      this.props.messageAction.fetchMessages({reset:300000, resetSource:types.RESET_MESSAGES});
    }

    let node = ReactDOM.findDOMNode(this);
    node.addEventListener('touchend', this._scrollLoad.bind(this), false);
    //node.addEventListener('touchmove', this._scrollMove.bind(this), false);
    this.afterComponentCompleteUpdate = true;
      
    let currentUserSubCount = localStorageService.get("subcount");
    if(currentUserSubCount) {
      this.showNoMessage = true;
    }else {
      this.showNoMessage = false;
    }
    wxshare();
  }
  componentWillUnmount() {
      let node = ReactDOM.findDOMNode(this);
      node.removeEventListener('touchend', this._scrollLoad.bind(this), false);
  }
  /**
   * 完成渲染新的props或者state后调用
   * @return {[type]}
   */
  componentDidUpdate() {

    if (this.props.message.status === 401) {
      auth({ go: 'message' });
    } else {
      this.afterComponentCompleteUpdate = true;
    }

  }
  _scrollMove() {
    let clientHeight = document.body.clientHeight;
    let scrollHeight = document.body.scrollHeight - document.body.scrollTop;
    if (clientHeight === scrollHeight) {
      this.setState({
        msg:"松手加载"
      });
    }
  }
  /**
   * 下拉加载
   * @return {[type]}
   */
  _scrollLoad() {
    
    let clientHeight = document.body.clientHeight;
    let scrollHeight = document.body.scrollHeight - document.body.scrollTop;
    if (!this.props.message.page || ((this.props.message.page.nextPage === this.props.message.page.pageNo) && (clientHeight >= scrollHeight ))) {
      // Notify.makeNotify('当前已是最后一页');
       this.setState({
          msg:""
        })
       return;
    }
    if (this.afterComponentCompleteUpdate && (clientHeight >= scrollHeight)) {

      this.props.messageAction.fetchMessages({
        pageIndex: this.props.message.page.nextPage
      });
      this.setState({
        msg:"上拉加载更多数据"
      })
      this.afterComponentCompleteUpdate = false;

    }

  }
  /**
   * [productsubscribe description]
   * @return {[type]} [description]
   */
  productsubscribe(){
    this.props.history.pushState(null, "/Product");
  }
  /**
   * 消息列表背景样式
   * @return {[type]}
   */
  getContainerBgClass() {

    let {
      message
    } = this.props;

    let defaultClass = "message-container";
    if ( message.results && message.results.length > 0 ) {
      return `${defaultClass}`;
    }
    return defaultClass;

  }
  /**
   * 页面渲染
   * @return {[type]}
   */
  render() {

    let {
      message
    } = this.props;

    let bgClass = this.getContainerBgClass();

    let messageItems = formater.messageListFormater(message.results);
    // let messageItems = message.results;
    return ( 
      < Content className = {
        bgClass
      }
      menuIndex = {
        1
      }
      isMenubar = {
        true
      } >
      

        {

          message.loader && !(messageItems && messageItems.length > 0) ?

            <div className = "loader-container"> 

              { <Loader color = "#e1bf6d" size = "48px" /> } 

            </div> 

            :

            messageItems && messageItems.length > 0 ?

              messageItems.map((messageItem, i) =>
                <MessageItem messageItem = {
                  messageItem
                }
                key = {
                  i
                }/>) 

              :
              this.showNoMessage ? 
                <div 
                  className = "text-center padding-lg" >
                  <div className = "blank30" > < /div>
                  暂无消息信息 
                </div>
                : 
                <div className= "vertical-middle message-empty">
                  <p className="message-empty-text">您暂时还未签约任何产品</p>
                  <div className="message-empty-op">
                    <a href="javascript:void(0)" className="btn btn-dark btn-block" onClick={this.productsubscribe.bind(this)}>立即签约</a>
                  </div>
                </div>

        } 

        <div　 
          className = 'text-center padding-lg page-loading'>
          {
            (!this.props.message.page || (this.props.message.page && (this.props.message.page.nextPage === this.props.message.page.pageNo))) ? 
            ""
            :
            this.state.msg
          }
        </div>

      </Content>
    );
  }
}

export default connect(state => ({
  message: state.message
}), dispatch => ({
  messageAction: bindActionCreators(MessageAction, dispatch)
}))(MessageApp);
