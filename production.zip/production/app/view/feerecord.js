import React from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import * as StockAction from '../action/stock';
import { bindActionCreators } from 'redux';
import Content from '../component/content';
import ShadowFollowFooter from '../component/shadowFollowFooter';
import { auth, getUrl } from '../common/util';
import { wxshare } from '../common/wxshare';
import Loader from 'halogen/BounceLoader';

class FeeRecordApp extends React.Component {

  constructor() {
    super();
    document.body.className = "strategy-bg";
    this.state = {
      msg:"上拉加载更多数据"
    };
  }
  componentDidMount(){
    let { recordType = "deduct" } = this.props.location.query;
    this.props.stockAction.fetchStockCostDetail({pmid: recordType, loader: true});
    let node = ReactDOM.findDOMNode(this);
    node.addEventListener('touchend', this._scrollLoad.bind(this), false);
    //node.addEventListener('touchmove', this._scrollMove.bind(this), false);
    this.afterComponentCompleteUpdate = true;
    wxshare();
  }

  componentWillUnmount() {
    let node = ReactDOM.findDOMNode(this);
    node.removeEventListener('touchend', this._scrollLoad.bind(this), false);
  }

  /**
   * 完成渲染新的props或者state后调用
   * @return {[type]}
   */
  componentDidUpdate() {
    let { recordType = "deduct" } = this.props.location.query;
    if (this.props.stockCost[recordType].status === 401) {
      auth({ go: 'feerecord', recordType: recordType });
    } else {
      this.afterComponentCompleteUpdate = true;
    }
  }

  /**
   * 下拉加载
   * @return {[type]}
   */
  _scrollLoad() {
    let { recordType = "deduct" } = this.props.location.query;
    let clientHeight = document.body.clientHeight;
    let scrollHeight = document.body.scrollHeight - document.body.scrollTop;
    if (!this.props.stockCost[recordType].page || ((this.props.stockCost[recordType].page.nextPage === this.props.stockCost[recordType].page.pageNo) && (clientHeight >= scrollHeight ))) {
      // Notify.makeNotify('当前已是最后一页');
       this.setState({
          msg:""
        })
       return;
    }
    if (this.afterComponentCompleteUpdate && (clientHeight >= scrollHeight)) {
      let { recordType = "deduct" } = this.props.location.query;
      this.props.stockAction.fetchStockCostDetail({
        pmid: recordType,
        pageIndex: this.props.stockCost[recordType].page.nextPage
      });
      this.setState({
        msg:"上拉加载更多数据"
      })
      this.afterComponentCompleteUpdate = false;
    }

  }

  renderHeader(recordType,amount) {
    return (
      <div>
        <div className = "record-header color-title-bg" >
          <div className = "text-center">
            <span className="font-16 color-text-common">
              {
                recordType === "deduct" ? 
                  "扣费额：" 
                  : recordType === "consume" ?
                    "消费额：" 
                    : "***："
              }
            
            </span>
            <span className="font-28 color-text-gold">
              { recordType === "deduct" || recordType === "consume" ? amount || "***.**" : "***.**"} 
            </span>
          </div>
        </div>
        <div className="blank30"></div>
      </div>  
      );
  }

  renderDeductList(list){
    return (
      <div className = "table-item">
        <div className = "table-row-tr row font-16">
          <div className = "table-row-th col-xs-4 text-left">扣费类型</div>
          <div className = "table-row-th col-xs-4 text-center">扣费额</div>
          <div className = "table-row-th col-xs-4 text-right">扣费时间</div>
        </div>
        {
          list.results && list.results.length > 0 ?
            list.results.map((deductListItem, i) =>
                <div className = "table-row-tr row font-14 color-text-notice border-bottom" key = { i }>
                  <div className = "table-row-tb col-xs-4 text-left">{deductListItem.paytype}</div>
                  <div className = "table-row-tb col-xs-4 text-center">{deductListItem.feevalue}</div>
                  <div className = "table-row-tb col-xs-4 text-right">{deductListItem.dateint}</div>
                </div>) 
              :
              <div className = "text-center padding-lg" >
                <div className = "blank30"> < /div>
                暂无明细信息 
              </div>
        }
      </div>
    );
  }

  renderConsumeList(list){
    return (
      <div className = "table-item">
        <div className = "table-row-tr row font-16">
          <div className = "table-row-th col-xs-3 text-left">产品</div>
          <div className = "table-row-th col-xs-3 text-center">消费额</div>
          <div className = "table-row-th col-xs-3 text-right">收费类型</div>
          <div className = "table-row-th col-xs-3 text-right">时间</div>
        </div>
        {
          list.results && list.results.length > 0 ?
            list.results.map((consumeListItem, i) =>
              <div className = "table-row-tr row font-14 color-text-notice border-bottom" key = { i }>
                <div className = "table-row-tb col-xs-3 text-left">{consumeListItem.name}</div>
                <div className = "table-row-tb col-xs-3 text-center">{consumeListItem.feeamt}</div>
                <div className = "table-row-tb col-xs-3 text-center">{consumeListItem.feetype}</div>
                <div className = "table-row-tb col-xs-3 text-right">{consumeListItem.updatetime}</div>
              </div>) 
              :
              <div className = "text-center padding-lg" >
                <div className = "blank30"> < /div>
                暂无明细信息 
              </div>
        }
      </div>
    );
  }

  renderContent(recordType,amount,list) {
    return(
      <div>
        { this.renderHeader(recordType,amount) }
        {
          recordType === "deduct" ? 
            this.renderDeductList(list) 
            : recordType === "consume" ? 
              this.renderConsumeList(list) 
              : null
        }
      </div>
      );
  }

  render() {
    let { recordType = "deduct" } = this.props.location.query;
    let list  = this.props.stockCost[recordType] || {};
    let amount = (list.results ? list.results.length>0 ? list.results[0].amount : "0.0" : "***.**");
    return (
      < Content 
          className = { "product-strategy-container" }
          isMenubar = { false } >
          {
            list.loader ? 
              <div className = "loader-container"> 
                { <Loader color = "#e1bf6d" size = "48px" /> } 
              </div>
              : 
              this.renderContent(recordType,amount,list) 
          }
        <div 
          className = {
            (!list.loader && list.results && list.results.length > 0) ? "" : "hide"
          } >
          <div className="text-center page-loading">
            {
              (!list.page || (list.page && (list.page.nextPage === list.page.pageNo))) ? 
              ""
              :
              this.state.msg
            }
          </div>

        </div>
        <div className="blank30"></div>
        <div className = "blank50"> </div>
        <ShadowFollowFooter />   
      </Content>
    );
  }
}

export default connect(state => ({
    stockCost: state.stockcost
  }), dispatch => ({
    stockAction: bindActionCreators(StockAction, dispatch)
  }))(FeeRecordApp);
