import React from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import * as StockAction from '../action/stock';
import * as UserAction from '../action/user';
import Content from '../component/content';
import StockItem from '../component/stockItem';
import { bindActionCreators } from 'redux';
import * as types from './../constant/actiontype';
import Loader from 'halogen/BounceLoader';
import Notify from '../common/notification';
import ShadowFollowFooter from '../component/shadowFollowFooter';
import { wxshare } from '../common/wxshare';

import { auth, getUrl } from '../common/util';
import { Link } from 'react-router';

class StockSearchApp extends React.Component {

  constructor() {
    super();
    this.enableClick = true;
    this.showNoMessage = false;
    this.state = {
      msg:"上拉加载更多数据"
    }
    document.body.className = "strategy-bg";
  }

  /**
   * 真实的DOM被渲染出来后调用
   * @return {[type]}
   */
  componentDidMount() {
    let { userinfo } = this.props;
    this.props.stockAction.fetchStockServers({opt: 1});
    if (!userinfo.flag || !userinfo.results || (userinfo.results && userinfo.results.length === 0)) {
      this.props.userAction.getUserInfo({reset:300000, resetSource:types.RESET_USER_INFO});
    }
    // let { stocksearch } = this.props;

    let node = ReactDOM.findDOMNode(this);
    node.addEventListener('touchend', this._scrollLoad.bind(this), false);
    //node.addEventListener('touchmove', this._scrollMove.bind(this), false);
    this.afterComponentCompleteUpdate = true;
    wxshare();
  }
  componentWillUnmount() {
    let node = ReactDOM.findDOMNode(this);
    node.removeEventListener('touchend', this._scrollLoad.bind(this), false);
    // this.props.stockAction.resetSearchStocks();
  }
  /**
   * 完成渲染新的props或者state后调用
   * @return {[type]}
   */
  componentDidUpdate() {
    if (this.props.stocksearch.status === 401) {
      auth({ go: 'stocklist' });
    } else {
      let { stocksearch } = this.props;
      if(stocksearch.loader===false) {
        this.enableClick = true;
      }
      this.afterComponentCompleteUpdate = true;
    }
  }
  /**
   * 下拉加载
   * @return {[type]}
   */
  _scrollLoad(e) {
    //防止搜索时触发
    if(e.target.className === "ion-ios-search" || e.target.className === "ion-ios-search-label") {
      return;
    }
    let clientHeight = document.body.clientHeight;
    let scrollHeight = document.body.scrollHeight - document.body.scrollTop;
    if (!this.props.stocksearch.page || ((this.props.stocksearch.page.nextPage === this.props.stocksearch.page.pageNo) && (clientHeight >= scrollHeight ))) {
      // Notify.makeNotify('当前已是最后一页');
       // this.setState({
       //    msg:""
       //  })
       return;
    }
    if (this.afterComponentCompleteUpdate && (clientHeight >= scrollHeight)) {
      this.props.stockAction.fetchSearchStocks({loader : false, queryStr : this.props.stocksearch.queryStr, pageIndex: this.props.stocksearch.page.nextPage, searchFlag: true});
      // this.setState({
      //   msg:"上拉加载更多数据"
      // })
      this.afterComponentCompleteUpdate = false;

    }

  }
  subStock(stockId, pkgId, isSendSMS) {
    this.props.stockAction.subSearchStock({stockId:stockId, pkgId:pkgId, isSendSMS:isSendSMS});
  }
  renderReportList(){
    let { stocksearch, stockservers, userinfo } = this.props;
    return (
      <div> 
        {
          stocksearch.loader ? 
            <div className = "loader-container"> 
              { <Loader color = "#e1bf6d" size = "48px" /> } 
            </div>
            : 
            stocksearch.results && stocksearch.results.length > 0 && stocksearch.searchFlag ?
              stocksearch.results.map((stockItem, i) =>
                <StockItem 
                  stockItem = { stockItem }  
                  stockId = { stocksearch[stockItem.id] }
                  subStock = { this.subStock.bind(this)} 
                  stockservers = { stockservers } 
                  userinfo = { userinfo.results ? userinfo.results[0] : {} }
                  key = { i }/>) 
                :
                <div className = "text-center padding-lg" >
                  <div className = "blank30"> </div>
                    { stocksearch.searchFlag ? "暂无搜索股票" : "" }
                </div>
        }
        <div 
          className = {
            (!stocksearch.loader && stocksearch.results && stocksearch.results.length > 0) ? "" : "hide"
          } >
          <div className="text-center page-loading">
            {
              (!this.props.stocksearch.page || (this.props.stocksearch.page && (this.props.stocksearch.page.nextPage === this.props.stocksearch.page.pageNo))) ? 
              ""
              :
              this.state.msg
            }
          </div>

        </div>
        
      </div>
    );
  }

  researchStock() { 
    if(this.enableClick) {
      let queryStr = this.refs.searchInput.value;
      if (queryStr === '') {
        Notify.makeNotify("请输入股票代码/名称");
        return false;
      }
      this.enableClick = false;
      this.props.stockAction.fetchSearchStocks({loader : true, queryStr : queryStr});
    }
  }

  _preventDefualtEvent(event) {
    event.stopPropagation();
  }

  render() {

    return (
      
      < Content 
          className = { "product-strategy-container" }
          isMenubar = { false } >
          <div className = "search-box">
            <div className = "search-content">
              <div className="search-area">
                <input className="search-input" ref="searchInput" placeholder="输入股票代码/名称" maxLength="10"/>
              </div>
              <lable className="ion-ios-search-label" onClick={ this.researchStock.bind(this) }>
                <i className="ion-ios-search"></i>
              </lable>
            </div>
          </div>
        <div className = "blank30"> </div>
        <div className = "blank30"> </div>
        { this.renderReportList() }
        <div className="blank30"></div>
        <div className="blank50"></div>
        <ShadowFollowFooter />  
      </Content>
    );
  }
}

export default connect(state => ({
      stocksearch: state.stocksearch,
      stockservers: state.stockservers,
      userinfo: state.userinfo
    }), dispatch => ({
      stockAction: bindActionCreators(StockAction, dispatch),
      userAction: bindActionCreators(UserAction, dispatch)
    }))(StockSearchApp);
