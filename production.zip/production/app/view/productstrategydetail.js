import * as ProductStrategyAction from '../action/productStrategy';
import * as UserAction from '../action/user';
import Loader from 'halogen/BounceLoader';
import UnlockBox from '../component/unlockBox';
import React from 'react';
import Notify from '../common/notification';
import StrategyFooter from '../component/footer';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { formatDate } from '../common/formater';
import { localStorageService } from '../common/Storage';
import { getUrl, auth } from '../common/util';
import { wxshare } from '../common/wxshare';
import * as types from './../constant/actiontype';

class ProductStrategyDetailApp extends React.Component {
    constructor(props) {
        super(props);
        this.displayName = 'ProductStrategyDetailApp';
        this.showNoMessage = false;
        this.showToastMessage = false;
        this.showLoader = true;
        this.firstRender = true;
        this.clickCount = 0;
        this.closeTimer = null;
        this.canSub = true;
        this.state = {
            enabledClick : true,
            btnText : "点击解锁"
        }
        document.body.className = "";
    }
    /**
     * 真实的DOM被渲染出来后调用
     * @return {[type]}
     */
    componentDidMount() {
        let {id = 0, articleid = 0, preview} = this.props.location.query;
        // this.props.userAction.getUserInfo({});
        let { userinfo } = this.props;
        if (!userinfo.flag || !userinfo.results || (userinfo.results && userinfo.results.length === 0)) {
          this.props.userAction.getUserInfo({reset:300000, resetSource:types.RESET_USER_INFO});
        }
        this.props.productStrategyAction.fetchProductsStrategy({id : id, preview : preview});
        this.props.productStrategyAction.fetchProductsStrategyComments({articleid : articleid, preview : preview});
    }

    /**
     * 真实dom更新后被调用
     * @return {[type]}
     */
    componentDidUpdate() {
        if ( 401 === this.props.productStrategyDetail.status ) {
            this.showNoMessage = false;
            let params = this.props.location.query;
            auth({ go: 'productstrategydetail', ...params });
        } else {
            this.showNoMessage = true;
            let {
                productStrategyDetail, 
                productStrategyComments
                } = this.props;
            if (productStrategyDetail.unlockStatus !== 0 && productStrategyDetail.unlockStatus !== 1 && this.showToastMessage) {
                Notify.makeNotify(productStrategyDetail.message);
                this.showToastMessage = false;
            }
            if(this.refs.privateContent && productStrategyDetail.unlockStatus === 2 && productStrategyComments && productStrategyComments.results.length > 0) {
                this.refs.privateContent.scrollIntoView();
            }
            if(productStrategyDetail.loader === false && productStrategyComments.loader === false) {
                this.saveCurrentTime();
                this.showLoader = false;
            }
        }

    }
    componentWillReceiveProps(nextProps) {
        let { productStrategyDetail } = nextProps;
        if(!productStrategyDetail.loader && this.firstRender && typeof productStrategyDetail.results!=='undefined' && typeof productStrategyDetail.results[0]!=='undefined') {
            wxshare({
                link: getUrl({go: 'productstrategydetail', id: productStrategyDetail.results[0].id, articleid: productStrategyDetail.results[0].articleid, isShare: 1}),
                msgTitle: `赢财富-热点追击：${productStrategyDetail.results[0].name}`,
                msgContent: productStrategyDetail.results[0].abstract
            });
            this.firstRender = false;
        }
        if(productStrategyDetail.unlockStatus === 3) {
            this.setState({
                enabledClick : true,
                btnText : "点击解锁"
            });
            this.canSub = true;
        }
    }
    /**
     * 存储当前时间，以判断是否查看更新
     * @return {[type]}
     */
    saveCurrentTime() {
        let { id = 0 } = this.props.location.query;
        let date = new Date();
        let currentCacheVal = formatDate(date, "yyyy-MM-dd hh:mm:ss");
        localStorageService.set(`NOTIFY_LINK_${id}`, currentCacheVal);
    }

    clickControl() { 
        this.clickCount++;  //记录点击次数
        if(this.clickCount === 1){
            this.setState({
                enabledClick : false,
                btnText : "解锁中"
            });
            this.closeTimer = setTimeout(this.setOut.bind(this), 100);
        }
    }
    setOut() {  //点击执行事件
        clearTimeout(this.closeTimer);  //清除延时函数
        this.closeTimer = null;  //设置延时寄存为null
        this.onSubscribeClick();
        this.clickCount = 0;  //重置点击次数为0
    }
    /**
     * 确认解锁
     * @return {[type]}
     */
    onSubscribeClick() {
        let { id = 0, articleid = 0 } = this.props.location.query;
        if (this.canSub) {
            this.props.productStrategyAction.subProductStrategy({pid : id,
                resolved: ()=>{
                  this.props.productStrategyAction.fetchProductsStrategyComments(articleid);
                }});
            this.canSub = false;
            this.showToastMessage = true;
        }
    }
    /**
     * 是否显示隐藏内容
     * @return {[type]}
     */
    handleUnlockStatus() {
        let { productStrategyDetail } = this.props;
        let isprivate = productStrategyDetail.results[0].isprivate,
            islock = productStrategyDetail.results[0].islock,
            isend = productStrategyDetail.results[0].isend;

        if(isend === '1' || (isprivate === '1' && islock === '1')) {
            return 'show';
        } else if(isprivate === '1' && islock !== '1') {
            return 'hide';
        }
        return 'none';
    }
    /**
     * 点评更新时间渲染
     * @return {[type]}
     */
    renderUpdateTime(updatetime = "") {
        let renderUpdateTime = formatDate(updatetime, "yyyy年MM月dd hh:mm") || "";
        renderUpdateTime = `-${renderUpdateTime} 更新-`;
        return renderUpdateTime;
    }
    renderHeader() {
        let {
            productStrategyDetail
        } = this.props;
        let shcreatetime = productStrategyDetail.results[0].shcreatetime.substring(0, productStrategyDetail.results[0].shcreatetime.length-3)
        
        return(
            <div className = "strategy-header">
                <div className = "strategy-detail-title" >

                    <h5 > 
                        <b > {
                            productStrategyDetail.results[0].name
                        } </b>
                    </h5 >

                </div> 
                <div className = "strategy-shcreatetime" >

                    <small className = 'text-muted' > 
                        { `${shcreatetime} 发布` } 
                    </small>     

                </div> 
                <div className = "strategy-abstract" >
                    {`摘 要: ${ productStrategyDetail.results[0].abstract }`} 
                </div>
            </div>
            );
    }
    renderComments() {
        let { productStrategyComments } = this.props;
        let unlockStatus = this.handleUnlockStatus();
        return(
        <div>
            {
                unlockStatus === 'show' ?

                    productStrategyComments.results && productStrategyComments.results.length > 0 ?  
                        productStrategyComments.results.map((productStrategyComment, i) =>  
                        <div className = 'strategy-content' >
                            <div className = 'strategy-update-title' > 
                                <div className = 'strategy-update-title-text text-center' >{this.renderUpdateTime(productStrategyComment.createtime)}</div> 
                            </div>
                            <div className = "text-indent" dangerouslySetInnerHTML = {{__html: productStrategyComment.content}}></div> 
                        </div>)
                        :
                        null 
                    :
                    null
            }
        </div>
        );
    }

    renderFreeContent() {
        let { productStrategyDetail, productStrategyComments } = this.props;
        let unlockStatus = this.handleUnlockStatus();
        return(
            <div>
                {
                    unlockStatus === 'show' ?

                        productStrategyComments.results && productStrategyComments.results.length > 0 ?  
                            <div className = 'strategy-unlock-title' >
                                <div className = 'strategy-unlock-title-line'> </div> 
                                <div className = 'strategy-unlock-title-text text-center' >以下为原文内容</div> 
                            </div>
                            :
                            null 
                        :
                        null
                }
                
                <div className = "strategy-content" dangerouslySetInnerHTML = {{__html: productStrategyDetail.results[0].descript}}></div>

            </div>

        );
    }
    renderPrivateContent() {
        let { productStrategyDetail } = this.props;

        let unlockStatus = this.handleUnlockStatus();
        return(
            <div>
                {
                    unlockStatus === 'show' ?

                        <div className = 'strategy-content' ref="privateContent">
                            <div className = 'strategy-unlock-title' >
                                <div className = 'strategy-unlock-title-line'> </div> 
                                <div className = 'strategy-unlock-title-text text-center' >以下为解锁内容</div> 
                            </div>
                            <div className = "" dangerouslySetInnerHTML = {{__html: productStrategyDetail.results[0].private}}></div>
                        </div>
                        :
                        unlockStatus === 'hide' ?
                            <UnlockBox 
                                  detail = { this.props.productStrategyDetail } 
                                  userinfo = { this.props.userinfo.results ? this.props.userinfo.results[0] : {} }
                                  onSubscribeClick = { this.clickControl.bind(this) } 
                                  enabledClick = { this.state.enabledClick } 
                                  btnText = { this.state.btnText }
                                  noticeText = { `-更多核心内容， 需要解锁后查看-` } 
                                  unlockNum = { `${ productStrategyDetail.results[0].unlocknum }人已解锁` }
                                  lockType = { `Strategy` }/>
                            : 
                            null
                } 
            </div>
        );
    }
    /**
     * 页面渲染
     * @return {[type]}
     */
    render() {

        let { productStrategyDetail, productStrategyComments } = this.props;

        return(
            <div> 
                { 
                    (productStrategyDetail.loader || productStrategyComments.loader) && this.showLoader ?
                        <div className = "loader-container" > 
                            { <Loader color = "#e1bf6d" size = "48px" /> } 
                        </div>  
                        : 
                        productStrategyDetail.results && productStrategyDetail.results.length > 0 ?
                            <div className = "strategy-product" >
                                <div className = "card content-strategy-detail">
                                    { this.renderHeader() }
                                    { this.renderComments() }
                                    { this.renderFreeContent() }
                                    { this.renderPrivateContent() }
                                </div> 
                                <div className = "blank30" > </div> 
                                <div className = "blank100" > </div> 
                                <StrategyFooter />
                                
                            </div>
                            :
                            <div className = "strategy-product">
                                <div className = "blank30"> </div>
                                <div className = "blank30"> </div> 
                                <div className = {this.showNoMessage ? "text-center padding-lg" : "hide"} >
                                    暂无策略详情
                                </div>
                            </div>
                } 
            < /div>    
        ) 
    }
}

export default connect(state => ({
    productStrategyDetail: state.productstrategydetail,
    productStrategyComments: state.productstrategycomments,
    userinfo: state.userinfo
}), dispatch => ({
    productStrategyAction: bindActionCreators(ProductStrategyAction, dispatch),
    userAction: bindActionCreators(UserAction, dispatch)
}))(ProductStrategyDetailApp);

