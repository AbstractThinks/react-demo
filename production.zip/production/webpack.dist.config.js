var webpack = require('webpack');
var path = require('path');
var ExtractTextPlugin = require('extract-text-webpack-plugin');

module.exports = {
    entry: {
        bundle:'./app/app.js'
        // app: "./app/app.js",
        // vendor: ["boron", "classnames", "halogen",  
        //         "rc-notification", "react", 
        //          "react-dom", "react-redux", "react-router", 
        //          "redux", "redux-thunk", "whatwg-fetch"]
    },
    output: {
        publicPath: './',
        path: __dirname + '/asset/js/',
        filename: '[name].min.js'
    },
    resolve: {
        extensions: ['', '.js', '.jsx', '.json']
    },
    module: {
        loaders: [{
            test: /\.js$/,
            loader: 'babel',
            exclude: /node_modules/,
            query: {
                presets: ['es2015', 'react', 'stage-0', 'stage-1']
            }
        }, {
            test: /\.(png|jpg)$/,
            loader: 'url-loader?limit=8192&name=../../asset/img/[name].[ext]'
        },{
            test: /\.scss$/,
            loader:ExtractTextPlugin.extract("css!sass")
          }]
    },
    plugins: [
        new webpack.DefinePlugin({
            'process.env': {
              'NODE_ENV': JSON.stringify('production')
            }
        }),
        // new webpack.optimize.CommonsChunkPlugin(/* chunkName= */"vendor", /* filename= */"vendor.bundle.min.js"),
        new ExtractTextPlugin('../../asset/css/app.css')
    ]
};